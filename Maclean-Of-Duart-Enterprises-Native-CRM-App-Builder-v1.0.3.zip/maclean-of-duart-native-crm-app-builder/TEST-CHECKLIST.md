# Native CRM test checklist

Use a test device and fictitious data.

## Branding and company actions

- [ ] Logo appears without a black rectangle.
- [ ] Tartan appears as a restrained header and lock-screen accent.
- [ ] Company colors remain readable in light and dark sections.
- [ ] The compact header shows the website, phone number, and office email.
- [ ] Header website, phone, and email details open the correct external app.
- [ ] Dashboard office-call button opens the dialer with 717-500-6202.
- [ ] Company screen email button targets
      office@macleanofduartenterprises.com.
- [ ] Website button opens macleanofduartenterprises.com.
- [ ] Scheduling button opens cal.com/macleanofduartenterprises.

## Access

- [ ] First launch creates and confirms a six-digit PIN.
- [ ] Incorrect PIN is rejected.
- [ ] Five incorrect attempts trigger a timed lockout.
- [ ] Lock and inactivity return to the PIN screen.
- [ ] Android screenshots work on the PIN screen and throughout the CRM.
- [ ] Redact all private customer and company information before sharing a capture.

## Contacts and pipeline

- [ ] Create a customer with service, representative, source, value, and next action.
- [ ] Search by name, email, phone, service, and source.
- [ ] Edit the record and confirm persistence after relaunch.
- [ ] Add a note and linked task.
- [ ] Move the record through all five stages.
- [ ] Archive it and find it with “Include archived contacts.”

## Tasks, consultations, and inquiries

- [ ] Create, complete, reopen, and edit tasks.
- [ ] Confirm overdue tasks are labeled and counted.
- [ ] Create/edit a consultation and hand it to the device calendar.
- [ ] Create an inquiry, change its status, and convert it to a New lead.

## Backup and removal

- [ ] Export with a unique passphrase of at least 10 characters.
- [ ] Confirm the wrong passphrase cannot open the file.
- [ ] Restore and confirm that the backed-up state returns.
- [ ] Confirm restore replaces rather than merges current data.
- [ ] Type `ERASE` and verify all records and the old PIN are removed.
- [ ] Build any release with the company's own keystore.
