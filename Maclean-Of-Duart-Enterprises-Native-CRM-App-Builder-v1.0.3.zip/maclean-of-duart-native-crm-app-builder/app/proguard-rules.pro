# The project currently uses no reflection-based models or third-party SDKs.
# Keep this file for App Builder II or Android Studio release builds.
