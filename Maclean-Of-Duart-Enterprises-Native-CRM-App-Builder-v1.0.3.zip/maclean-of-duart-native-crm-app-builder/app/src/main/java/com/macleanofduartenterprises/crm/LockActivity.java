package com.macleanofduartenterprises.crm;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.macleanofduartenterprises.crm.security.PinManager;
import com.macleanofduartenterprises.crm.security.SessionGuard;

import java.util.Arrays;
import java.util.Locale;

public final class LockActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private PinManager pinManager;
    private EditText pinInput;
    private EditText pinConfirmInput;
    private TextView title;
    private TextView subtitle;
    private TextView error;
    private Button actionButton;
    private boolean setupMode;

    private final Runnable lockoutTicker = new Runnable() {
        @Override
        public void run() {
            updateLockoutState();
            if (pinManager != null && pinManager.isLockedOut()) {
                handler.postDelayed(this, 500);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pinManager = new PinManager(this);
        if (pinManager.hasPin() && SessionGuard.isUnlocked(this)) {
            openCrm();
            return;
        }

        setContentView(R.layout.activity_lock);
        pinInput = findViewById(R.id.pinInput);
        pinConfirmInput = findViewById(R.id.pinConfirmInput);
        title = findViewById(R.id.lockTitle);
        subtitle = findViewById(R.id.lockSubtitle);
        error = findViewById(R.id.lockError);
        actionButton = findViewById(R.id.unlockButton);

        setupMode = !pinManager.hasPin();
        configureMode();
        actionButton.setOnClickListener(view -> submit());
        pinInput.setOnEditorActionListener((view, actionId, event) -> {
            if (!setupMode && actionId == EditorInfo.IME_ACTION_DONE) {
                submit();
                return true;
            }
            return false;
        });
        pinConfirmInput.setOnEditorActionListener((view, actionId, event) -> {
            if (setupMode && actionId == EditorInfo.IME_ACTION_DONE) {
                submit();
                return true;
            }
            return false;
        });
        updateLockoutState();
        if (pinManager.isLockedOut()) {
            handler.postDelayed(lockoutTicker, 500);
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(lockoutTicker);
        super.onDestroy();
    }

    private void configureMode() {
        if (setupMode) {
            title.setText(R.string.setup_title);
            subtitle.setText("Create a six-digit PIN for local CRM access.");
            pinConfirmInput.setVisibility(View.VISIBLE);
            pinInput.setImeOptions(EditorInfo.IME_ACTION_NEXT);
            pinConfirmInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
            actionButton.setText(R.string.create_pin);
        } else {
            title.setText(R.string.unlock_title);
            subtitle.setText("Enter your app PIN to continue.");
            pinConfirmInput.setVisibility(View.GONE);
            pinInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
            actionButton.setText(R.string.unlock);
        }
    }

    private void submit() {
        hideError();
        char[] pin = pinInput.getText().toString().toCharArray();
        try {
            if (setupMode) {
                char[] confirmation = pinConfirmInput.getText().toString().toCharArray();
                try {
                    if (!Arrays.equals(pin, confirmation)) {
                        showError("The PINs do not match.");
                        return;
                    }
                    pinManager.createOrChangePin(pin);
                    SessionGuard.unlock();
                    openCrm();
                } finally {
                    Arrays.fill(confirmation, '\0');
                }
                return;
            }

            if (pinManager.isLockedOut()) {
                updateLockoutState();
                handler.removeCallbacks(lockoutTicker);
                handler.postDelayed(lockoutTicker, 500);
                return;
            }
            if (pinManager.verify(pin)) {
                SessionGuard.unlock();
                openCrm();
            } else {
                pinInput.setText("");
                if (pinManager.isLockedOut()) {
                    updateLockoutState();
                    handler.removeCallbacks(lockoutTicker);
                    handler.postDelayed(lockoutTicker, 500);
                } else {
                    showError("Incorrect PIN.");
                }
            }
        } catch (IllegalArgumentException exception) {
            showError(exception.getMessage());
        } finally {
            Arrays.fill(pin, '\0');
        }
    }

    private void updateLockoutState() {
        if (pinManager == null || setupMode || !pinManager.isLockedOut()) {
            if (actionButton != null) {
                actionButton.setEnabled(true);
            }
            return;
        }
        long seconds = Math.max(1, (pinManager.getLockoutRemainingMillis() + 999) / 1000);
        actionButton.setEnabled(false);
        showError(String.format(
                Locale.US,
                "Too many attempts. Try again in %d seconds.",
                seconds
        ));
    }

    private void showError(String message) {
        error.setText(message == null ? "Unable to continue." : message);
        error.setVisibility(View.VISIBLE);
    }

    private void hideError() {
        error.setVisibility(View.GONE);
        error.setText("");
    }

    private void openCrm() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}
