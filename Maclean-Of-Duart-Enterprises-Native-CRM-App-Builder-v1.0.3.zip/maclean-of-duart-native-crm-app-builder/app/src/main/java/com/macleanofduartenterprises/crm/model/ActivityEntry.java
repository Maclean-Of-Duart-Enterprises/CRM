package com.macleanofduartenterprises.crm.model;

public final class ActivityEntry {
    public long id;
    public String action = "";
    public String entityType = "";
    public long entityId;
    public String summary = "";
    public String createdAt = "";
}
