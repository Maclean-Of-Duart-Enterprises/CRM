package com.macleanofduartenterprises.crm.model;

public final class TaskItem {
    public static final String[] PRIORITIES = {"Low", "Normal", "High", "Urgent"};

    public long id;
    public long contactId;
    public String title = "";
    public String dueDate = "";
    public String priority = "Normal";
    public String status = "Open";
    public String assignee = "";
    public String details = "";
    public String createdAt = "";
    public String updatedAt = "";
}
