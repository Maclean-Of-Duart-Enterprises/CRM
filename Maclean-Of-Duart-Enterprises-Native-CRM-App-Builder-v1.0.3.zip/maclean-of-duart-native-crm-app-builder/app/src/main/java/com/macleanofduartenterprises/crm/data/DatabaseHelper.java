package com.macleanofduartenterprises.crm.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.macleanofduartenterprises.crm.model.ActivityEntry;
import com.macleanofduartenterprises.crm.model.Appointment;
import com.macleanofduartenterprises.crm.model.Contact;
import com.macleanofduartenterprises.crm.model.Inquiry;
import com.macleanofduartenterprises.crm.model.NoteItem;
import com.macleanofduartenterprises.crm.model.TaskItem;
import com.macleanofduartenterprises.crm.security.CryptoManager;
import com.macleanofduartenterprises.crm.util.AppDate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "maclean_of_duart_crm.db";
    private static final int DATABASE_VERSION = 1;

    private static final String CONTACTS = "contacts";
    private static final String NOTES = "notes";
    private static final String TASKS = "tasks";
    private static final String APPOINTMENTS = "appointments";
    private static final String INQUIRIES = "inquiries";
    private static final String ACTIVITIES = "activities";

    private final CryptoManager crypto;
    private boolean suppressActivity;

    public DatabaseHelper(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
        crypto = new CryptoManager(context);
    }

    @Override
    public void onConfigure(SQLiteDatabase database) {
        super.onConfigure(database);
        database.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(
                "CREATE TABLE " + CONTACTS + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "first_name TEXT NOT NULL DEFAULT '',"
                        + "last_name TEXT NOT NULL DEFAULT '',"
                        + "household TEXT NOT NULL DEFAULT '',"
                        + "email TEXT NOT NULL DEFAULT '',"
                        + "phone TEXT NOT NULL DEFAULT '',"
                        + "stage TEXT NOT NULL,"
                        + "service TEXT NOT NULL DEFAULT '',"
                        + "source TEXT NOT NULL DEFAULT '',"
                        + "advisor TEXT NOT NULL DEFAULT '',"
                        + "estimated_value TEXT NOT NULL DEFAULT '',"
                        + "next_action TEXT NOT NULL DEFAULT '',"
                        + "consent INTEGER NOT NULL DEFAULT 0,"
                        + "status TEXT NOT NULL DEFAULT 'Active',"
                        + "created_at TEXT NOT NULL,"
                        + "updated_at TEXT NOT NULL"
                        + ")"
        );
        database.execSQL(
                "CREATE TABLE " + NOTES + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "contact_id INTEGER NOT NULL,"
                        + "category TEXT NOT NULL DEFAULT 'General',"
                        + "body TEXT NOT NULL,"
                        + "created_at TEXT NOT NULL,"
                        + "FOREIGN KEY(contact_id) REFERENCES " + CONTACTS + "(id) ON DELETE CASCADE"
                        + ")"
        );
        database.execSQL(
                "CREATE TABLE " + TASKS + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "contact_id INTEGER NOT NULL DEFAULT 0,"
                        + "title TEXT NOT NULL,"
                        + "due_date TEXT NOT NULL DEFAULT '',"
                        + "priority TEXT NOT NULL DEFAULT 'Normal',"
                        + "status TEXT NOT NULL DEFAULT 'Open',"
                        + "assignee TEXT NOT NULL DEFAULT '',"
                        + "details TEXT NOT NULL DEFAULT '',"
                        + "created_at TEXT NOT NULL,"
                        + "updated_at TEXT NOT NULL"
                        + ")"
        );
        database.execSQL(
                "CREATE TABLE " + APPOINTMENTS + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "contact_id INTEGER NOT NULL DEFAULT 0,"
                        + "title TEXT NOT NULL,"
                        + "start_time INTEGER NOT NULL,"
                        + "duration_minutes INTEGER NOT NULL DEFAULT 60,"
                        + "meeting_type TEXT NOT NULL DEFAULT 'Office',"
                        + "status TEXT NOT NULL DEFAULT 'Tentative',"
                        + "details TEXT NOT NULL DEFAULT '',"
                        + "created_at TEXT NOT NULL,"
                        + "updated_at TEXT NOT NULL"
                        + ")"
        );
        database.execSQL(
                "CREATE TABLE " + INQUIRIES + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "name TEXT NOT NULL DEFAULT '',"
                        + "email TEXT NOT NULL DEFAULT '',"
                        + "phone TEXT NOT NULL DEFAULT '',"
                        + "type TEXT NOT NULL DEFAULT 'Contact form',"
                        + "service TEXT NOT NULL DEFAULT '',"
                        + "message TEXT NOT NULL DEFAULT '',"
                        + "status TEXT NOT NULL DEFAULT 'New',"
                        + "consent INTEGER NOT NULL DEFAULT 0,"
                        + "received_at INTEGER NOT NULL,"
                        + "updated_at TEXT NOT NULL"
                        + ")"
        );
        database.execSQL(
                "CREATE TABLE " + ACTIVITIES + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + "action TEXT NOT NULL,"
                        + "entity_type TEXT NOT NULL,"
                        + "entity_id INTEGER NOT NULL DEFAULT 0,"
                        + "summary TEXT NOT NULL,"
                        + "created_at TEXT NOT NULL"
                        + ")"
        );
        database.execSQL("CREATE INDEX idx_contacts_stage ON " + CONTACTS + "(stage, status)");
        database.execSQL("CREATE INDEX idx_tasks_status_due ON " + TASKS + "(status, due_date)");
        database.execSQL("CREATE INDEX idx_appointments_start ON " + APPOINTMENTS + "(start_time)");
        database.execSQL("CREATE INDEX idx_inquiries_status ON " + INQUIRIES + "(status, received_at)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        // Add explicit, non-destructive migrations here when DATABASE_VERSION increases.
        throw new IllegalStateException(
                "No database migration exists from version " + oldVersion + " to " + newVersion
        );
    }

    public long saveContact(Contact contact) {
        SQLiteDatabase database = getWritableDatabase();
        String now = AppDate.nowStamp();
        boolean creating = contact.id <= 0;
        if (contact.createdAt == null || contact.createdAt.isEmpty()) {
            contact.createdAt = now;
        }
        contact.updatedAt = now;
        ContentValues values = contactValues(contact, false);
        if (creating) {
            contact.id = database.insertOrThrow(CONTACTS, null, values);
        } else {
            int updated = database.update(
                    CONTACTS,
                    values,
                    "id=?",
                    new String[]{String.valueOf(contact.id)}
            );
            if (updated == 0) {
                values.put("id", contact.id);
                database.insertOrThrow(CONTACTS, null, values);
            }
        }
        logActivity(
                creating ? "Created" : "Updated",
                "contact",
                contact.id,
                contact.displayName() + (creating ? " added" : " updated")
        );
        return contact.id;
    }

    public Contact getContact(long id) {
        try (Cursor cursor = getReadableDatabase().query(
                CONTACTS,
                null,
                "id=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        )) {
            return cursor.moveToFirst() ? readContact(cursor) : null;
        }
    }

    public List<Contact> getContacts(String search, boolean includeArchived) {
        List<Contact> result = new ArrayList<>();
        String selection = includeArchived ? null : "status<>'Archived'";
        try (Cursor cursor = getReadableDatabase().query(
                CONTACTS,
                null,
                selection,
                null,
                null,
                null,
                "updated_at DESC"
        )) {
            String needle = safe(search).trim().toLowerCase(Locale.US);
            while (cursor.moveToNext()) {
                Contact contact = readContact(cursor);
                if (needle.isEmpty() || matchesContact(contact, needle)) {
                    result.add(contact);
                }
            }
        }
        return result;
    }

    public List<Contact> getContactsByStage(String stage) {
        List<Contact> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                CONTACTS,
                null,
                "stage=? AND status<>'Archived'",
                new String[]{stage},
                null,
                null,
                "next_action ASC, updated_at DESC"
        )) {
            while (cursor.moveToNext()) {
                result.add(readContact(cursor));
            }
        }
        return result;
    }

    public int countContacts(String stage) {
        String selection = "status<>'Archived'";
        List<String> args = new ArrayList<>();
        if (stage != null && !stage.isEmpty()) {
            selection += " AND stage=?";
            args.add(stage);
        }
        try (Cursor cursor = getReadableDatabase().query(
                CONTACTS,
                new String[]{"COUNT(*)"},
                selection,
                args.toArray(new String[0]),
                null,
                null,
                null
        )) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    public double sumOpenOpportunityValue() {
        double sum = 0;
        try (Cursor cursor = getReadableDatabase().query(
                CONTACTS,
                new String[]{"estimated_value"},
                "status<>'Archived' AND stage<>'Client'",
                null,
                null,
                null,
                null
        )) {
            while (cursor.moveToNext()) {
                sum += parseDouble(crypto.decrypt(cursor.getString(0)));
            }
        }
        return sum;
    }

    public void moveContactStage(long contactId, String newStage) {
        Contact contact = getContact(contactId);
        if (contact == null) {
            return;
        }
        contact.stage = newStage;
        saveContact(contact);
        logActivity(
                "Stage changed",
                "contact",
                contactId,
                contact.displayName() + " moved to " + newStage
        );
    }

    public void archiveContact(long contactId) {
        Contact contact = getContact(contactId);
        if (contact == null) {
            return;
        }
        contact.status = "Archived";
        saveContact(contact);
        logActivity("Archived", "contact", contactId, contact.displayName() + " archived");
    }

    public long saveNote(NoteItem note) {
        if (note.createdAt == null || note.createdAt.isEmpty()) {
            note.createdAt = AppDate.nowStamp();
        }
        ContentValues values = new ContentValues();
        values.put("contact_id", note.contactId);
        values.put("category", safe(note.category));
        values.put("body", crypto.encrypt(note.body));
        values.put("created_at", note.createdAt);
        if (note.id <= 0) {
            note.id = getWritableDatabase().insertOrThrow(NOTES, null, values);
        } else {
            values.put("id", note.id);
            getWritableDatabase().insertWithOnConflict(
                    NOTES,
                    null,
                    values,
                    SQLiteDatabase.CONFLICT_REPLACE
            );
        }
        Contact contact = getContact(note.contactId);
        logActivity(
                "Note added",
                "note",
                note.id,
                "Note added for " + (contact == null ? "contact" : contact.displayName())
        );
        return note.id;
    }

    public List<NoteItem> getNotes(long contactId) {
        List<NoteItem> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                NOTES,
                null,
                "contact_id=?",
                new String[]{String.valueOf(contactId)},
                null,
                null,
                "created_at DESC"
        )) {
            while (cursor.moveToNext()) {
                NoteItem note = new NoteItem();
                note.id = longValue(cursor, "id");
                note.contactId = longValue(cursor, "contact_id");
                note.category = stringValue(cursor, "category");
                note.body = crypto.decrypt(stringValue(cursor, "body"));
                note.createdAt = stringValue(cursor, "created_at");
                result.add(note);
            }
        }
        return result;
    }

    public long saveTask(TaskItem task) {
        SQLiteDatabase database = getWritableDatabase();
        String now = AppDate.nowStamp();
        boolean creating = task.id <= 0;
        if (task.createdAt == null || task.createdAt.isEmpty()) {
            task.createdAt = now;
        }
        task.updatedAt = now;
        ContentValues values = taskValues(task, false);
        if (creating) {
            task.id = database.insertOrThrow(TASKS, null, values);
        } else {
            int updated = database.update(
                    TASKS,
                    values,
                    "id=?",
                    new String[]{String.valueOf(task.id)}
            );
            if (updated == 0) {
                values.put("id", task.id);
                database.insertOrThrow(TASKS, null, values);
            }
        }
        logActivity(
                creating ? "Created" : "Updated",
                "task",
                task.id,
                (creating ? "Task created: " : "Task updated: ") + task.title
        );
        return task.id;
    }

    public TaskItem getTask(long id) {
        try (Cursor cursor = getReadableDatabase().query(
                TASKS,
                null,
                "id=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        )) {
            return cursor.moveToFirst() ? readTask(cursor) : null;
        }
    }

    public List<TaskItem> getTasks(boolean openOnly) {
        List<TaskItem> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                TASKS,
                null,
                openOnly ? "status<>'Complete'" : null,
                null,
                null,
                null,
                "CASE WHEN due_date='' THEN 1 ELSE 0 END, due_date ASC, updated_at DESC"
        )) {
            while (cursor.moveToNext()) {
                result.add(readTask(cursor));
            }
        }
        return result;
    }

    public List<TaskItem> getTasksForContact(long contactId) {
        List<TaskItem> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                TASKS,
                null,
                "contact_id=?",
                new String[]{String.valueOf(contactId)},
                null,
                null,
                "due_date ASC"
        )) {
            while (cursor.moveToNext()) {
                result.add(readTask(cursor));
            }
        }
        return result;
    }

    public int countOpenTasks() {
        return countWhere(TASKS, "status<>'Complete'", null);
    }

    public int countOverdueTasks() {
        return countWhere(
                TASKS,
                "status<>'Complete' AND due_date<>'' AND due_date<?",
                new String[]{AppDate.today()}
        );
    }

    public void setTaskComplete(long taskId, boolean complete) {
        TaskItem task = getTask(taskId);
        if (task == null) {
            return;
        }
        task.status = complete ? "Complete" : "Open";
        saveTask(task);
        logActivity(
                complete ? "Completed" : "Reopened",
                "task",
                taskId,
                task.title + (complete ? " completed" : " reopened")
        );
    }

    public long saveAppointment(Appointment appointment) {
        SQLiteDatabase database = getWritableDatabase();
        String now = AppDate.nowStamp();
        boolean creating = appointment.id <= 0;
        if (appointment.createdAt == null || appointment.createdAt.isEmpty()) {
            appointment.createdAt = now;
        }
        appointment.updatedAt = now;
        ContentValues values = appointmentValues(appointment, false);
        if (creating) {
            appointment.id = database.insertOrThrow(APPOINTMENTS, null, values);
        } else {
            int updated = database.update(
                    APPOINTMENTS,
                    values,
                    "id=?",
                    new String[]{String.valueOf(appointment.id)}
            );
            if (updated == 0) {
                values.put("id", appointment.id);
                database.insertOrThrow(APPOINTMENTS, null, values);
            }
        }
        logActivity(
                creating ? "Created" : "Updated",
                "appointment",
                appointment.id,
                (creating ? "Consultation created: " : "Consultation updated: ")
                        + appointment.title
        );
        return appointment.id;
    }

    public Appointment getAppointment(long id) {
        try (Cursor cursor = getReadableDatabase().query(
                APPOINTMENTS,
                null,
                "id=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        )) {
            return cursor.moveToFirst() ? readAppointment(cursor) : null;
        }
    }

    public List<Appointment> getAppointments(boolean upcomingOnly) {
        List<Appointment> result = new ArrayList<>();
        String selection = upcomingOnly
                ? "start_time>=? AND status<>'Cancelled'"
                : null;
        String[] args = upcomingOnly
                ? new String[]{String.valueOf(System.currentTimeMillis() - 3_600_000L)}
                : null;
        try (Cursor cursor = getReadableDatabase().query(
                APPOINTMENTS,
                null,
                selection,
                args,
                null,
                null,
                "start_time ASC"
        )) {
            while (cursor.moveToNext()) {
                result.add(readAppointment(cursor));
            }
        }
        return result;
    }

    public int countUpcomingAppointments() {
        return countWhere(
                APPOINTMENTS,
                "start_time>=? AND status<>'Cancelled'",
                new String[]{String.valueOf(System.currentTimeMillis())}
        );
    }

    public long saveInquiry(Inquiry inquiry) {
        SQLiteDatabase database = getWritableDatabase();
        boolean creating = inquiry.id <= 0;
        if (inquiry.receivedAt <= 0) {
            inquiry.receivedAt = System.currentTimeMillis();
        }
        inquiry.updatedAt = AppDate.nowStamp();
        ContentValues values = inquiryValues(inquiry, false);
        if (creating) {
            inquiry.id = database.insertOrThrow(INQUIRIES, null, values);
        } else {
            int updated = database.update(
                    INQUIRIES,
                    values,
                    "id=?",
                    new String[]{String.valueOf(inquiry.id)}
            );
            if (updated == 0) {
                values.put("id", inquiry.id);
                database.insertOrThrow(INQUIRIES, null, values);
            }
        }
        logActivity(
                creating ? "Created" : "Updated",
                "inquiry",
                inquiry.id,
                (creating ? "Inquiry added from " : "Inquiry updated for ") + inquiry.name
        );
        return inquiry.id;
    }

    public Inquiry getInquiry(long id) {
        try (Cursor cursor = getReadableDatabase().query(
                INQUIRIES,
                null,
                "id=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        )) {
            return cursor.moveToFirst() ? readInquiry(cursor) : null;
        }
    }

    public List<Inquiry> getInquiries() {
        List<Inquiry> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                INQUIRIES,
                null,
                null,
                null,
                null,
                null,
                "received_at DESC"
        )) {
            while (cursor.moveToNext()) {
                result.add(readInquiry(cursor));
            }
        }
        return result;
    }

    public int countNewInquiries() {
        return countWhere(INQUIRIES, "status='New'", null);
    }

    public void setInquiryStatus(long id, String status) {
        Inquiry inquiry = getInquiry(id);
        if (inquiry == null) {
            return;
        }
        inquiry.status = status;
        saveInquiry(inquiry);
    }

    public List<ActivityEntry> getRecentActivity(int limit) {
        List<ActivityEntry> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                ACTIVITIES,
                null,
                null,
                null,
                null,
                null,
                "id DESC",
                String.valueOf(Math.max(1, limit))
        )) {
            while (cursor.moveToNext()) {
                ActivityEntry entry = new ActivityEntry();
                entry.id = longValue(cursor, "id");
                entry.action = stringValue(cursor, "action");
                entry.entityType = stringValue(cursor, "entity_type");
                entry.entityId = longValue(cursor, "entity_id");
                entry.summary = crypto.decrypt(stringValue(cursor, "summary"));
                entry.createdAt = stringValue(cursor, "created_at");
                result.add(entry);
            }
        }
        return result;
    }

    public JSONObject exportJson() {
        try {
            JSONObject root = new JSONObject();
            root.put("application", "Maclean Of Duart Enterprises CRM");
            root.put("formatVersion", 1);
            root.put("exportedAt", AppDate.nowStamp());
            root.put("contacts", contactsJson());
            root.put("notes", notesJson());
            root.put("tasks", tasksJson());
            root.put("appointments", appointmentsJson());
            root.put("inquiries", inquiriesJson());
            root.put("activities", activitiesJson());
            return root;
        } catch (JSONException exception) {
            throw new IllegalStateException("CRM data could not be prepared for backup.", exception);
        }
    }

    public void importJson(JSONObject root) {
        if (root.optInt("formatVersion", 0) != 1) {
            throw new IllegalArgumentException("Unsupported CRM backup format.");
        }
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        suppressActivity = true;
        try {
            database.delete(NOTES, null, null);
            database.delete(TASKS, null, null);
            database.delete(APPOINTMENTS, null, null);
            database.delete(INQUIRIES, null, null);
            database.delete(ACTIVITIES, null, null);
            database.delete(CONTACTS, null, null);

            importContacts(database, root.optJSONArray("contacts"));
            importNotes(database, root.optJSONArray("notes"));
            importTasks(database, root.optJSONArray("tasks"));
            importAppointments(database, root.optJSONArray("appointments"));
            importInquiries(database, root.optJSONArray("inquiries"));
            importActivities(database, root.optJSONArray("activities"));
            database.setTransactionSuccessful();
        } finally {
            suppressActivity = false;
            database.endTransaction();
        }
        logActivity("Restored", "backup", 0, "Encrypted CRM backup restored");
    }

    public void wipeAllData() {
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        suppressActivity = true;
        try {
            database.delete(NOTES, null, null);
            database.delete(TASKS, null, null);
            database.delete(APPOINTMENTS, null, null);
            database.delete(INQUIRIES, null, null);
            database.delete(ACTIVITIES, null, null);
            database.delete(CONTACTS, null, null);
            database.setTransactionSuccessful();
        } finally {
            suppressActivity = false;
            database.endTransaction();
        }
    }

    public void addSampleData() {
        if (countContacts(null) > 0) {
            throw new IllegalStateException("Sample data can be added only to an empty CRM.");
        }
        suppressActivity = true;
        try {
            Contact contact = new Contact();
            contact.firstName = "Sample";
            contact.lastName = "Household";
            contact.household = "Sample Household";
            contact.email = "sample@example.com";
            contact.phone = "(555) 010-1000";
            contact.stage = "Assessment";
            contact.service = "IT Support & Computer Repair";
            contact.source = "Demonstration";
            contact.estimatedValue = 500_000;
            contact.nextAction = AppDate.today();
            contact.consent = true;
            saveContact(contact);

            TaskItem task = new TaskItem();
            task.contactId = contact.id;
            task.title = "Prepare sample technology assessment";
            task.dueDate = AppDate.today();
            task.priority = "High";
            task.assignee = "Sample Technician";
            saveTask(task);

            Appointment appointment = new Appointment();
            appointment.contactId = contact.id;
            appointment.title = "Sample consultation";
            appointment.startTime = System.currentTimeMillis() + 86_400_000L;
            appointment.durationMinutes = 60;
            appointment.status = "Confirmed";
            saveAppointment(appointment);

            Inquiry inquiry = new Inquiry();
            inquiry.name = "Sample Inquiry";
            inquiry.email = "inquiry@example.com";
            inquiry.type = "Live chat";
            inquiry.service = "Computer Diagnostics";
            inquiry.message = "Fictitious demonstration inquiry.";
            inquiry.consent = true;
            saveInquiry(inquiry);
        } finally {
            suppressActivity = false;
        }
        logActivity("Created", "sample", 0, "Fictitious sample records added");
    }

    public void deleteEncryptionKeyAfterWipe() {
        if (countContacts(null) != 0
                || countOpenTasks() != 0
                || countUpcomingAppointments() != 0
                || !getInquiries().isEmpty()) {
            throw new IllegalStateException("The database must be empty before deleting its key.");
        }
        crypto.deleteKey();
    }

    private void logActivity(String action, String entityType, long entityId, String summary) {
        if (suppressActivity) {
            return;
        }
        ContentValues values = new ContentValues();
        values.put("action", safe(action));
        values.put("entity_type", safe(entityType));
        values.put("entity_id", entityId);
        values.put("summary", crypto.encrypt(summary));
        values.put("created_at", AppDate.nowStamp());
        getWritableDatabase().insertOrThrow(ACTIVITIES, null, values);
    }

    private ContentValues contactValues(Contact contact, boolean includeId) {
        ContentValues values = new ContentValues();
        if (includeId) {
            values.put("id", contact.id);
        }
        values.put("first_name", crypto.encrypt(contact.firstName));
        values.put("last_name", crypto.encrypt(contact.lastName));
        values.put("household", crypto.encrypt(contact.household));
        values.put("email", crypto.encrypt(contact.email));
        values.put("phone", crypto.encrypt(contact.phone));
        values.put("stage", safe(contact.stage));
        values.put("service", safe(contact.service));
        values.put("source", safe(contact.source));
        values.put("advisor", crypto.encrypt(contact.advisor));
        values.put("estimated_value", crypto.encrypt(String.valueOf(contact.estimatedValue)));
        values.put("next_action", safe(contact.nextAction));
        values.put("consent", contact.consent ? 1 : 0);
        values.put("status", safe(contact.status));
        values.put("created_at", safe(contact.createdAt));
        values.put("updated_at", safe(contact.updatedAt));
        return values;
    }

    private ContentValues taskValues(TaskItem task, boolean includeId) {
        ContentValues values = new ContentValues();
        if (includeId) values.put("id", task.id);
        values.put("contact_id", task.contactId);
        values.put("title", crypto.encrypt(task.title));
        values.put("due_date", safe(task.dueDate));
        values.put("priority", safe(task.priority));
        values.put("status", safe(task.status));
        values.put("assignee", crypto.encrypt(task.assignee));
        values.put("details", crypto.encrypt(task.details));
        values.put("created_at", safe(task.createdAt));
        values.put("updated_at", safe(task.updatedAt));
        return values;
    }

    private ContentValues appointmentValues(Appointment appointment, boolean includeId) {
        ContentValues values = new ContentValues();
        if (includeId) values.put("id", appointment.id);
        values.put("contact_id", appointment.contactId);
        values.put("title", crypto.encrypt(appointment.title));
        values.put("start_time", appointment.startTime);
        values.put("duration_minutes", appointment.durationMinutes);
        values.put("meeting_type", safe(appointment.meetingType));
        values.put("status", safe(appointment.status));
        values.put("details", crypto.encrypt(appointment.details));
        values.put("created_at", safe(appointment.createdAt));
        values.put("updated_at", safe(appointment.updatedAt));
        return values;
    }

    private ContentValues inquiryValues(Inquiry inquiry, boolean includeId) {
        ContentValues values = new ContentValues();
        if (includeId) values.put("id", inquiry.id);
        values.put("name", crypto.encrypt(inquiry.name));
        values.put("email", crypto.encrypt(inquiry.email));
        values.put("phone", crypto.encrypt(inquiry.phone));
        values.put("type", safe(inquiry.type));
        values.put("service", safe(inquiry.service));
        values.put("message", crypto.encrypt(inquiry.message));
        values.put("status", safe(inquiry.status));
        values.put("consent", inquiry.consent ? 1 : 0);
        values.put("received_at", inquiry.receivedAt);
        values.put("updated_at", safe(inquiry.updatedAt));
        return values;
    }

    private Contact readContact(Cursor cursor) {
        Contact contact = new Contact();
        contact.id = longValue(cursor, "id");
        contact.firstName = crypto.decrypt(stringValue(cursor, "first_name"));
        contact.lastName = crypto.decrypt(stringValue(cursor, "last_name"));
        contact.household = crypto.decrypt(stringValue(cursor, "household"));
        contact.email = crypto.decrypt(stringValue(cursor, "email"));
        contact.phone = crypto.decrypt(stringValue(cursor, "phone"));
        contact.stage = stringValue(cursor, "stage");
        contact.service = stringValue(cursor, "service");
        contact.source = stringValue(cursor, "source");
        contact.advisor = crypto.decrypt(stringValue(cursor, "advisor"));
        contact.estimatedValue = parseDouble(
                crypto.decrypt(stringValue(cursor, "estimated_value"))
        );
        contact.nextAction = stringValue(cursor, "next_action");
        contact.consent = intValue(cursor, "consent") == 1;
        contact.status = stringValue(cursor, "status");
        contact.createdAt = stringValue(cursor, "created_at");
        contact.updatedAt = stringValue(cursor, "updated_at");
        return contact;
    }

    private TaskItem readTask(Cursor cursor) {
        TaskItem task = new TaskItem();
        task.id = longValue(cursor, "id");
        task.contactId = longValue(cursor, "contact_id");
        task.title = crypto.decrypt(stringValue(cursor, "title"));
        task.dueDate = stringValue(cursor, "due_date");
        task.priority = stringValue(cursor, "priority");
        task.status = stringValue(cursor, "status");
        task.assignee = crypto.decrypt(stringValue(cursor, "assignee"));
        task.details = crypto.decrypt(stringValue(cursor, "details"));
        task.createdAt = stringValue(cursor, "created_at");
        task.updatedAt = stringValue(cursor, "updated_at");
        return task;
    }

    private Appointment readAppointment(Cursor cursor) {
        Appointment appointment = new Appointment();
        appointment.id = longValue(cursor, "id");
        appointment.contactId = longValue(cursor, "contact_id");
        appointment.title = crypto.decrypt(stringValue(cursor, "title"));
        appointment.startTime = longValue(cursor, "start_time");
        appointment.durationMinutes = intValue(cursor, "duration_minutes");
        appointment.meetingType = stringValue(cursor, "meeting_type");
        appointment.status = stringValue(cursor, "status");
        appointment.details = crypto.decrypt(stringValue(cursor, "details"));
        appointment.createdAt = stringValue(cursor, "created_at");
        appointment.updatedAt = stringValue(cursor, "updated_at");
        return appointment;
    }

    private Inquiry readInquiry(Cursor cursor) {
        Inquiry inquiry = new Inquiry();
        inquiry.id = longValue(cursor, "id");
        inquiry.name = crypto.decrypt(stringValue(cursor, "name"));
        inquiry.email = crypto.decrypt(stringValue(cursor, "email"));
        inquiry.phone = crypto.decrypt(stringValue(cursor, "phone"));
        inquiry.type = stringValue(cursor, "type");
        inquiry.service = stringValue(cursor, "service");
        inquiry.message = crypto.decrypt(stringValue(cursor, "message"));
        inquiry.status = stringValue(cursor, "status");
        inquiry.consent = intValue(cursor, "consent") == 1;
        inquiry.receivedAt = longValue(cursor, "received_at");
        inquiry.updatedAt = stringValue(cursor, "updated_at");
        return inquiry;
    }

    private JSONArray contactsJson() throws JSONException {
        JSONArray array = new JSONArray();
        for (Contact contact : getContacts("", true)) {
            JSONObject item = new JSONObject();
            item.put("id", contact.id);
            item.put("firstName", contact.firstName);
            item.put("lastName", contact.lastName);
            item.put("household", contact.household);
            item.put("email", contact.email);
            item.put("phone", contact.phone);
            item.put("stage", contact.stage);
            item.put("service", contact.service);
            item.put("source", contact.source);
            item.put("advisor", contact.advisor);
            item.put("estimatedValue", contact.estimatedValue);
            item.put("nextAction", contact.nextAction);
            item.put("consent", contact.consent);
            item.put("status", contact.status);
            item.put("createdAt", contact.createdAt);
            item.put("updatedAt", contact.updatedAt);
            array.put(item);
        }
        return array;
    }

    private JSONArray notesJson() throws JSONException {
        JSONArray array = new JSONArray();
        try (Cursor cursor = getReadableDatabase().query(
                NOTES, null, null, null, null, null, "id ASC"
        )) {
            while (cursor.moveToNext()) {
                JSONObject item = new JSONObject();
                item.put("id", longValue(cursor, "id"));
                item.put("contactId", longValue(cursor, "contact_id"));
                item.put("category", stringValue(cursor, "category"));
                item.put("body", crypto.decrypt(stringValue(cursor, "body")));
                item.put("createdAt", stringValue(cursor, "created_at"));
                array.put(item);
            }
        }
        return array;
    }

    private JSONArray tasksJson() throws JSONException {
        JSONArray array = new JSONArray();
        for (TaskItem task : getTasks(false)) {
            JSONObject item = new JSONObject();
            item.put("id", task.id);
            item.put("contactId", task.contactId);
            item.put("title", task.title);
            item.put("dueDate", task.dueDate);
            item.put("priority", task.priority);
            item.put("status", task.status);
            item.put("assignee", task.assignee);
            item.put("details", task.details);
            item.put("createdAt", task.createdAt);
            item.put("updatedAt", task.updatedAt);
            array.put(item);
        }
        return array;
    }

    private JSONArray appointmentsJson() throws JSONException {
        JSONArray array = new JSONArray();
        for (Appointment appointment : getAppointments(false)) {
            JSONObject item = new JSONObject();
            item.put("id", appointment.id);
            item.put("contactId", appointment.contactId);
            item.put("title", appointment.title);
            item.put("startTime", appointment.startTime);
            item.put("durationMinutes", appointment.durationMinutes);
            item.put("meetingType", appointment.meetingType);
            item.put("status", appointment.status);
            item.put("details", appointment.details);
            item.put("createdAt", appointment.createdAt);
            item.put("updatedAt", appointment.updatedAt);
            array.put(item);
        }
        return array;
    }

    private JSONArray inquiriesJson() throws JSONException {
        JSONArray array = new JSONArray();
        for (Inquiry inquiry : getInquiries()) {
            JSONObject item = new JSONObject();
            item.put("id", inquiry.id);
            item.put("name", inquiry.name);
            item.put("email", inquiry.email);
            item.put("phone", inquiry.phone);
            item.put("type", inquiry.type);
            item.put("service", inquiry.service);
            item.put("message", inquiry.message);
            item.put("status", inquiry.status);
            item.put("consent", inquiry.consent);
            item.put("receivedAt", inquiry.receivedAt);
            item.put("updatedAt", inquiry.updatedAt);
            array.put(item);
        }
        return array;
    }

    private JSONArray activitiesJson() throws JSONException {
        JSONArray array = new JSONArray();
        try (Cursor cursor = getReadableDatabase().query(
                ACTIVITIES, null, null, null, null, null, "id ASC"
        )) {
            while (cursor.moveToNext()) {
                JSONObject item = new JSONObject();
                item.put("id", longValue(cursor, "id"));
                item.put("action", stringValue(cursor, "action"));
                item.put("entityType", stringValue(cursor, "entity_type"));
                item.put("entityId", longValue(cursor, "entity_id"));
                item.put("summary", crypto.decrypt(stringValue(cursor, "summary")));
                item.put("createdAt", stringValue(cursor, "created_at"));
                array.put(item);
            }
        }
        return array;
    }

    private void importContacts(SQLiteDatabase database, JSONArray array) {
        if (array == null) return;
        for (int index = 0; index < array.length(); index++) {
            JSONObject item = array.optJSONObject(index);
            if (item == null) continue;
            Contact contact = new Contact();
            contact.id = item.optLong("id");
            contact.firstName = item.optString("firstName");
            contact.lastName = item.optString("lastName");
            contact.household = item.optString("household");
            contact.email = item.optString("email");
            contact.phone = item.optString("phone");
            contact.stage = item.optString("stage", Contact.STAGES[0]);
            contact.service = item.optString("service");
            contact.source = item.optString("source");
            contact.advisor = item.optString("advisor");
            contact.estimatedValue = item.optDouble("estimatedValue");
            contact.nextAction = item.optString("nextAction");
            contact.consent = item.optBoolean("consent");
            contact.status = item.optString("status", "Active");
            contact.createdAt = item.optString("createdAt", AppDate.nowStamp());
            contact.updatedAt = item.optString("updatedAt", contact.createdAt);
            database.insertOrThrow(CONTACTS, null, contactValues(contact, true));
        }
    }

    private void importNotes(SQLiteDatabase database, JSONArray array) {
        if (array == null) return;
        for (int index = 0; index < array.length(); index++) {
            JSONObject item = array.optJSONObject(index);
            if (item == null) continue;
            ContentValues values = new ContentValues();
            values.put("id", item.optLong("id"));
            values.put("contact_id", item.optLong("contactId"));
            values.put("category", item.optString("category", "General"));
            values.put("body", crypto.encrypt(item.optString("body")));
            values.put("created_at", item.optString("createdAt", AppDate.nowStamp()));
            database.insertOrThrow(NOTES, null, values);
        }
    }

    private void importTasks(SQLiteDatabase database, JSONArray array) {
        if (array == null) return;
        for (int index = 0; index < array.length(); index++) {
            JSONObject item = array.optJSONObject(index);
            if (item == null) continue;
            TaskItem task = new TaskItem();
            task.id = item.optLong("id");
            task.contactId = item.optLong("contactId");
            task.title = item.optString("title");
            task.dueDate = item.optString("dueDate");
            task.priority = item.optString("priority", "Normal");
            task.status = item.optString("status", "Open");
            task.assignee = item.optString("assignee");
            task.details = item.optString("details");
            task.createdAt = item.optString("createdAt", AppDate.nowStamp());
            task.updatedAt = item.optString("updatedAt", task.createdAt);
            database.insertOrThrow(TASKS, null, taskValues(task, true));
        }
    }

    private void importAppointments(SQLiteDatabase database, JSONArray array) {
        if (array == null) return;
        for (int index = 0; index < array.length(); index++) {
            JSONObject item = array.optJSONObject(index);
            if (item == null) continue;
            Appointment appointment = new Appointment();
            appointment.id = item.optLong("id");
            appointment.contactId = item.optLong("contactId");
            appointment.title = item.optString("title");
            appointment.startTime = item.optLong("startTime");
            appointment.durationMinutes = item.optInt("durationMinutes", 60);
            appointment.meetingType = item.optString("meetingType", "Office");
            appointment.status = item.optString("status", "Tentative");
            appointment.details = item.optString("details");
            appointment.createdAt = item.optString("createdAt", AppDate.nowStamp());
            appointment.updatedAt = item.optString("updatedAt", appointment.createdAt);
            database.insertOrThrow(
                    APPOINTMENTS,
                    null,
                    appointmentValues(appointment, true)
            );
        }
    }

    private void importInquiries(SQLiteDatabase database, JSONArray array) {
        if (array == null) return;
        for (int index = 0; index < array.length(); index++) {
            JSONObject item = array.optJSONObject(index);
            if (item == null) continue;
            Inquiry inquiry = new Inquiry();
            inquiry.id = item.optLong("id");
            inquiry.name = item.optString("name");
            inquiry.email = item.optString("email");
            inquiry.phone = item.optString("phone");
            inquiry.type = item.optString("type", "Contact form");
            inquiry.service = item.optString("service");
            inquiry.message = item.optString("message");
            inquiry.status = item.optString("status", "New");
            inquiry.consent = item.optBoolean("consent");
            inquiry.receivedAt = item.optLong("receivedAt");
            inquiry.updatedAt = item.optString("updatedAt", AppDate.nowStamp());
            database.insertOrThrow(INQUIRIES, null, inquiryValues(inquiry, true));
        }
    }

    private void importActivities(SQLiteDatabase database, JSONArray array) {
        if (array == null) return;
        for (int index = 0; index < array.length(); index++) {
            JSONObject item = array.optJSONObject(index);
            if (item == null) continue;
            ContentValues values = new ContentValues();
            values.put("id", item.optLong("id"));
            values.put("action", item.optString("action"));
            values.put("entity_type", item.optString("entityType"));
            values.put("entity_id", item.optLong("entityId"));
            values.put("summary", crypto.encrypt(item.optString("summary")));
            values.put("created_at", item.optString("createdAt", AppDate.nowStamp()));
            database.insertOrThrow(ACTIVITIES, null, values);
        }
    }

    private int countWhere(String table, String selection, String[] args) {
        try (Cursor cursor = getReadableDatabase().query(
                table,
                new String[]{"COUNT(*)"},
                selection,
                args,
                null,
                null,
                null
        )) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    private static boolean matchesContact(Contact contact, String needle) {
        return contact.displayName().toLowerCase(Locale.US).contains(needle)
                || safe(contact.firstName).toLowerCase(Locale.US).contains(needle)
                || safe(contact.lastName).toLowerCase(Locale.US).contains(needle)
                || safe(contact.email).toLowerCase(Locale.US).contains(needle)
                || safe(contact.phone).toLowerCase(Locale.US).contains(needle)
                || safe(contact.service).toLowerCase(Locale.US).contains(needle)
                || safe(contact.source).toLowerCase(Locale.US).contains(needle);
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static double parseDouble(String value) {
        try {
            return Double.parseDouble(safe(value));
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private static long longValue(Cursor cursor, String column) {
        return cursor.getLong(cursor.getColumnIndexOrThrow(column));
    }

    private static int intValue(Cursor cursor, String column) {
        return cursor.getInt(cursor.getColumnIndexOrThrow(column));
    }

    private static String stringValue(Cursor cursor, String column) {
        String value = cursor.getString(cursor.getColumnIndexOrThrow(column));
        return value == null ? "" : value;
    }
}
