package com.macleanofduartenterprises.crm.security;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PinManager {
    private static final String PREFS = "maclean_crm_secure_access";
    private static final String KEY_SALT = "pin_salt";
    private static final String KEY_HASH = "pin_hash";
    private static final String KEY_ALGORITHM = "pin_algorithm";
    private static final String KEY_FAILURES = "pin_failures";
    private static final String KEY_LOCK_UNTIL = "pin_lock_until";
    private static final int ITERATIONS = 180_000;
    private static final int HASH_BITS = 256;
    private static final int MAX_ATTEMPTS = 5;
    private static final long LOCKOUT_MILLIS = 30_000L;

    private final SharedPreferences preferences;

    public PinManager(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean hasPin() {
        return !preferences.getString(KEY_HASH, "").isEmpty()
                && !preferences.getString(KEY_SALT, "").isEmpty();
    }

    public boolean isLockedOut() {
        return getLockoutRemainingMillis() > 0;
    }

    public long getLockoutRemainingMillis() {
        return Math.max(0, preferences.getLong(KEY_LOCK_UNTIL, 0) - System.currentTimeMillis());
    }

    public void createOrChangePin(char[] pin) {
        validatePin(pin);
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        HashResult result = hash(pin, salt, null);
        preferences.edit()
                .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString(KEY_HASH, Base64.encodeToString(result.hash, Base64.NO_WRAP))
                .putString(KEY_ALGORITHM, result.algorithm)
                .putInt(KEY_FAILURES, 0)
                .remove(KEY_LOCK_UNTIL)
                .apply();
    }

    public boolean verify(char[] pin) {
        if (!hasPin() || isLockedOut()) {
            return false;
        }
        try {
            byte[] salt = Base64.decode(
                    preferences.getString(KEY_SALT, ""),
                    Base64.NO_WRAP
            );
            byte[] expected = Base64.decode(
                    preferences.getString(KEY_HASH, ""),
                    Base64.NO_WRAP
            );
            String algorithm = preferences.getString(
                    KEY_ALGORITHM,
                    "PBKDF2WithHmacSHA256"
            );
            byte[] actual = hash(pin, salt, algorithm).hash;
            boolean valid = MessageDigest.isEqual(expected, actual);
            if (valid) {
                resetFailures();
            } else {
                recordFailure();
            }
            return valid;
        } catch (RuntimeException exception) {
            recordFailure();
            return false;
        }
    }

    public void removePin() {
        preferences.edit().clear().apply();
    }

    private void resetFailures() {
        preferences.edit()
                .putInt(KEY_FAILURES, 0)
                .remove(KEY_LOCK_UNTIL)
                .apply();
    }

    private void recordFailure() {
        int attempts = preferences.getInt(KEY_FAILURES, 0) + 1;
        SharedPreferences.Editor editor = preferences.edit().putInt(KEY_FAILURES, attempts);
        if (attempts >= MAX_ATTEMPTS) {
            editor.putInt(KEY_FAILURES, 0)
                    .putLong(KEY_LOCK_UNTIL, System.currentTimeMillis() + LOCKOUT_MILLIS);
        }
        editor.apply();
    }

    private static void validatePin(char[] pin) {
        if (pin == null || pin.length != 6) {
            throw new IllegalArgumentException("PIN must contain exactly six digits.");
        }
        for (char character : pin) {
            if (character < '0' || character > '9') {
                throw new IllegalArgumentException("PIN must contain digits only.");
            }
        }
    }

    private static HashResult hash(char[] pin, byte[] salt, String preferredAlgorithm) {
        String[] algorithms = preferredAlgorithm == null
                ? new String[]{"PBKDF2WithHmacSHA256", "PBKDF2WithHmacSHA1"}
                : new String[]{preferredAlgorithm};
        RuntimeException lastError = null;
        for (String algorithm : algorithms) {
            PBEKeySpec spec = new PBEKeySpec(pin, salt, ITERATIONS, HASH_BITS);
            try {
                SecretKeyFactory factory = SecretKeyFactory.getInstance(algorithm);
                return new HashResult(algorithm, factory.generateSecret(spec).getEncoded());
            } catch (Exception exception) {
                lastError = new IllegalStateException("PIN protection is unavailable.", exception);
            } finally {
                spec.clearPassword();
            }
        }
        throw lastError == null
                ? new IllegalStateException("PIN protection is unavailable.")
                : lastError;
    }

    private static final class HashResult {
        final String algorithm;
        final byte[] hash;

        HashResult(String algorithm, byte[] hash) {
            this.algorithm = algorithm;
            this.hash = hash;
        }
    }
}
