package com.macleanofduartenterprises.crm.security;

import android.content.Context;
import android.os.SystemClock;

public final class SessionGuard {
    private static volatile boolean unlocked;
    private static volatile long lastInteractionElapsed;

    private SessionGuard() {
    }

    public static void unlock() {
        unlocked = true;
        lastInteractionElapsed = SystemClock.elapsedRealtime();
    }

    public static void touch() {
        if (unlocked) {
            lastInteractionElapsed = SystemClock.elapsedRealtime();
        }
    }

    public static void lock() {
        unlocked = false;
        lastInteractionElapsed = 0;
    }

    public static boolean isUnlocked(Context context) {
        if (!unlocked) {
            return false;
        }
        int minutes = context.getApplicationContext()
                .getSharedPreferences("maclean_crm_settings", Context.MODE_PRIVATE)
                .getInt("auto_lock_minutes", 5);
        long timeout = Math.max(1, minutes) * 60_000L;
        if (SystemClock.elapsedRealtime() - lastInteractionElapsed > timeout) {
            lock();
            return false;
        }
        return true;
    }
}
