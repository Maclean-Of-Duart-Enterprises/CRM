package com.macleanofduartenterprises.crm.model;

public final class Inquiry {
    public long id;
    public String name = "";
    public String email = "";
    public String phone = "";
    public String type = "Contact form";
    public String service = "";
    public String message = "";
    public String status = "New";
    public boolean consent;
    public long receivedAt;
    public String updatedAt = "";
}
