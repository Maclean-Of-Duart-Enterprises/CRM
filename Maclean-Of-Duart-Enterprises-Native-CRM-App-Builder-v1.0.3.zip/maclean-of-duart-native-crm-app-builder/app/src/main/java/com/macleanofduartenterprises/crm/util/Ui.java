package com.macleanofduartenterprises.crm.util;

import android.content.Context;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.macleanofduartenterprises.crm.R;

public final class Ui {
    private Ui() {
    }

    public static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    public static ScrollView scrollPage(Context context, LinearLayout page) {
        ScrollView scrollView = new ScrollView(context);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(context.getColor(R.color.ivory));
        scrollView.addView(page, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        return scrollView;
    }

    public static LinearLayout page(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(context, 16), dp(context, 16), dp(context, 16), dp(context, 28));
        return layout;
    }

    public static LinearLayout vertical(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    public static LinearLayout row(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    public static LinearLayout card(Context context) {
        LinearLayout card = vertical(context);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(context, 16), dp(context, 14), dp(context, 16), dp(context, 14));
        card.setClickable(true);
        card.setFocusable(true);
        return card;
    }

    public static TextView heading(Context context, String value) {
        TextView view = text(context, value, 22, R.color.navy_950);
        view.setTypeface(Typeface.SERIF, Typeface.BOLD);
        return view;
    }

    public static TextView section(Context context, String value) {
        TextView view = text(context, value, 18, R.color.navy_950);
        view.setTypeface(Typeface.SERIF, Typeface.BOLD);
        return view;
    }

    public static TextView body(Context context, String value) {
        return text(context, value, 15, R.color.ink);
    }

    public static TextView muted(Context context, String value) {
        return text(context, value, 13, R.color.muted);
    }

    public static TextView smallLabel(Context context, String value) {
        TextView view = text(context, value == null ? "" : value.toUpperCase(), 11, R.color.blue_600);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLetterSpacing(0.08f);
        return view;
    }

    public static TextView text(
            Context context,
            String value,
            int sizeSp,
            int colorResource
    ) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(context.getColor(colorResource));
        view.setLineSpacing(0, 1.08f);
        return view;
    }

    public static Button primaryButton(Context context, String value) {
        Button button = new Button(context);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTextColor(context.getColor(R.color.paper));
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackgroundResource(R.drawable.bg_primary_button);
        button.setMinHeight(dp(context, 48));
        return button;
    }

    public static Button secondaryButton(Context context, String value) {
        Button button = new Button(context);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTextColor(context.getColor(R.color.navy_900));
        button.setBackgroundResource(R.drawable.bg_secondary_button);
        button.setMinHeight(dp(context, 46));
        return button;
    }

    public static Button dangerButton(Context context, String value) {
        Button button = secondaryButton(context, value);
        button.setTextColor(context.getColor(R.color.danger));
        return button;
    }

    public static EditText input(Context context, String hint) {
        EditText input = new EditText(context);
        input.setHint(hint);
        input.setTextSize(15);
        input.setTextColor(context.getColor(R.color.ink));
        input.setHintTextColor(context.getColor(R.color.muted));
        input.setSingleLine(true);
        input.setBackgroundResource(R.drawable.bg_input);
        input.setPadding(dp(context, 12), 0, dp(context, 12), 0);
        input.setMinHeight(dp(context, 52));
        return input;
    }

    public static EditText multiline(Context context, String hint, int lines) {
        EditText input = input(context, hint);
        input.setSingleLine(false);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMinLines(lines);
        input.setPadding(
                dp(context, 12),
                dp(context, 12),
                dp(context, 12),
                dp(context, 12)
        );
        return input;
    }

    public static Spinner spinner(Context context, String[] values) {
        Spinner spinner = new Spinner(context);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                context,
                android.R.layout.simple_spinner_item,
                values
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackgroundResource(R.drawable.bg_input);
        spinner.setPadding(dp(context, 8), 0, dp(context, 8), 0);
        spinner.setMinimumHeight(dp(context, 52));
        return spinner;
    }

    public static LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    public static LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    public static LinearLayout.LayoutParams weight(float weight) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
    }

    public static <T extends View> T topMargin(Context context, T view, int marginDp) {
        LinearLayout.LayoutParams params = match();
        params.topMargin = dp(context, marginDp);
        view.setLayoutParams(params);
        return view;
    }

    public static <T extends View> T bottomMargin(Context context, T view, int marginDp) {
        LinearLayout.LayoutParams params = match();
        params.bottomMargin = dp(context, marginDp);
        view.setLayoutParams(params);
        return view;
    }

    public static void addField(
            Context context,
            LinearLayout parent,
            String label,
            View input
    ) {
        TextView labelView = smallLabel(context, label);
        LinearLayout.LayoutParams labelParams = match();
        labelParams.topMargin = dp(context, 12);
        labelParams.bottomMargin = dp(context, 5);
        parent.addView(labelView, labelParams);
        parent.addView(input, match());
    }

    public static void select(Spinner spinner, String value) {
        if (value == null) {
            return;
        }
        for (int index = 0; index < spinner.getCount(); index++) {
            Object item = spinner.getItemAtPosition(index);
            if (item != null && value.equalsIgnoreCase(String.valueOf(item))) {
                spinner.setSelection(index);
                return;
            }
        }
    }

    public static View spacer(Context context, int heightDp) {
        View spacer = new View(context);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(1, dp(context, heightDp)));
        return spacer;
    }
}
