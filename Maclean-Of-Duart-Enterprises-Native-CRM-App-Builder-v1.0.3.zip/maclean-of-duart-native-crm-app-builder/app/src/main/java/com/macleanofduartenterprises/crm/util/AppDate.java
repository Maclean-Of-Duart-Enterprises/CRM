package com.macleanofduartenterprises.crm.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class AppDate {
    private static final String STORAGE_DATE = "yyyy-MM-dd";
    private static final String STORAGE_STAMP = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

    private AppDate() {
    }

    public static String nowStamp() {
        return new SimpleDateFormat(STORAGE_STAMP, Locale.US).format(new Date());
    }

    public static String today() {
        return new SimpleDateFormat(STORAGE_DATE, Locale.US).format(new Date());
    }

    public static String formatDate(String storedDate) {
        if (storedDate == null || storedDate.trim().isEmpty()) {
            return "Not set";
        }
        try {
            Date parsed = new SimpleDateFormat(STORAGE_DATE, Locale.US).parse(storedDate);
            return new SimpleDateFormat("MMM d, yyyy", Locale.US).format(parsed);
        } catch (ParseException exception) {
            return storedDate;
        }
    }

    public static String formatDateTime(long epochMillis) {
        if (epochMillis <= 0) {
            return "Not set";
        }
        return new SimpleDateFormat("MMM d, yyyy 'at' h:mm a", Locale.US)
                .format(new Date(epochMillis));
    }

    public static String formatTime(long epochMillis) {
        if (epochMillis <= 0) {
            return "—";
        }
        return new SimpleDateFormat("h:mm a", Locale.US).format(new Date(epochMillis));
    }

    public static boolean isPastDate(String storedDate) {
        if (storedDate == null || storedDate.isEmpty()) {
            return false;
        }
        return storedDate.compareTo(today()) < 0;
    }
}
