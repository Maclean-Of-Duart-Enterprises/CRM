package com.macleanofduartenterprises.crm.model;

public final class Contact {
    public static final String[] STAGES = {
            "New lead", "Qualified", "Assessment", "Proposal", "Client"
    };

    public long id;
    public String firstName = "";
    public String lastName = "";
    public String household = "";
    public String email = "";
    public String phone = "";
    public String stage = STAGES[0];
    public String service = "";
    public String source = "";
    public String advisor = "";
    public double estimatedValue;
    public String nextAction = "";
    public boolean consent;
    public String status = "Active";
    public String createdAt = "";
    public String updatedAt = "";

    public String displayName() {
        String namedHousehold = safe(household).trim();
        if (!namedHousehold.isEmpty()) {
            return namedHousehold;
        }
        String fullName = (safe(firstName) + " " + safe(lastName)).trim();
        return fullName.isEmpty() ? "Unnamed contact" : fullName;
    }

    public Contact copy() {
        Contact result = new Contact();
        result.id = id;
        result.firstName = firstName;
        result.lastName = lastName;
        result.household = household;
        result.email = email;
        result.phone = phone;
        result.stage = stage;
        result.service = service;
        result.source = source;
        result.advisor = advisor;
        result.estimatedValue = estimatedValue;
        result.nextAction = nextAction;
        result.consent = consent;
        result.status = status;
        result.createdAt = createdAt;
        result.updatedAt = updatedAt;
        return result;
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }
}
