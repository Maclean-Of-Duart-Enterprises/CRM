package com.macleanofduartenterprises.crm.util;

import java.text.NumberFormat;
import java.util.Locale;

public final class Formatters {
    private Formatters() {
    }

    public static String money(double value) {
        NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
        format.setMaximumFractionDigits(0);
        return format.format(value);
    }

    public static String compactMoney(double value) {
        if (value >= 1_000_000) {
            double millions = value / 1_000_000d;
            return millions >= 10
                    ? String.format(Locale.US, "$%.0fM", millions)
                    : String.format(Locale.US, "$%.1fM", millions);
        }
        if (value >= 1_000) {
            return String.format(Locale.US, "$%.0fK", value / 1_000d);
        }
        return money(value);
    }

    public static double parseMoney(String value) {
        if (value == null) {
            return 0;
        }
        String normalized = value.replaceAll("[^0-9.\\-]", "");
        if (normalized.isEmpty() || "-".equals(normalized) || ".".equals(normalized)) {
            return 0;
        }
        try {
            return Double.parseDouble(normalized);
        } catch (NumberFormatException exception) {
            return 0;
        }
    }
}
