package com.macleanofduartenterprises.crm.model;

public final class NoteItem {
    public long id;
    public long contactId;
    public String category = "General";
    public String body = "";
    public String createdAt = "";
}
