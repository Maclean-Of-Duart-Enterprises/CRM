package com.macleanofduartenterprises.crm.model;

public final class Appointment {
    public long id;
    public long contactId;
    public String title = "";
    public long startTime;
    public int durationMinutes = 60;
    public String meetingType = "Office";
    public String status = "Tentative";
    public String details = "";
    public String createdAt = "";
    public String updatedAt = "";
}
