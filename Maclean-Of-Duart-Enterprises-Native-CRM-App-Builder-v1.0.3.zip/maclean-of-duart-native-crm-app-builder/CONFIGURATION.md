# Configuration map

## Company information

Edit `AppConstants.java` to change:

- Company name
- Phone
- Email
- Website
- Cal.com scheduling URL

Path:

`app/src/main/java/com/macleanofduartenterprises/crm/AppConstants.java`

## Technology services

The same file defines:

- IT Support & Computer Repair
- Computer Diagnostics
- Cybersecurity Services
- Family Technology Safety
- Website Design & Management
- Open-Source Support
- Data Backup & Drive Replacement
- Business Technology Consulting
- Graphic Design

It also defines inquiry sources, inquiry statuses, meeting types, and
appointment statuses.

## Pipeline

Edit `Contact.STAGES` in:

`app/src/main/java/com/macleanofduartenterprises/crm/model/Contact.java`

Current stages:

1. New lead
2. Qualified
3. Assessment
4. Proposal
5. Client

Changing stage names after real data exists requires a controlled database
migration.

## Branding

- Colors: `app/src/main/res/values/colors.xml`
- Transparent logo: `app/src/main/res/drawable-nodpi/maclean_logo.png`
- Ancient dress tartan:
  `app/src/main/res/drawable-nodpi/maclean_tartan.jpg`
- App icon: `app/src/main/res/drawable/ic_app_icon.xml`
- Original and prepared assets: `branding/`

The main CRM header uses only a narrow 6dp tartan accent above a solid
dark pine-green background, keeping the pattern visible without competing with
the company name, screen title, or contact information.

The active interface palette is:

- Logo light blue: `#BFD4F1`
- Heritage gold: `#D4B33D`
- Cool silver: `#B8C0C8`
- Dark pine-needle green: `#0A2B20`

Companion shades in `colors.xml` preserve readable contrast for text, controls,
cards, and pressed states.

## Database

The schema is in `DatabaseHelper.onCreate()`. Increase `DATABASE_VERSION` only
after adding a non-destructive `onUpgrade()` migration.
