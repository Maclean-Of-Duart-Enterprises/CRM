# Serakont App Builder II setup

Use App Builder II's **Java App** example—not a Website Wrapper or WebView
example. Menu labels may vary slightly by App Builder version.

## 1. Create the native project

1. Open App Builder II.
2. Create a new project from **Java App**.
3. Set the app name to `Maclean Of Duart Enterprises CRM`.
4. Set the package/application ID to
   `com.macleanofduartenterprises.crm`.
5. Set minimum API to 23 or newer.
6. Set target/compile API to 36 when available.
7. Do not enable WebView, AdMob, Firebase, or extra permissions.

## 2. Copy the source tree

| Package path | App Builder project location |
|---|---|
| `app/src/main/java/com/macleanofduartenterprises/crm/` | Java source package `com.macleanofduartenterprises.crm` |
| `app/src/main/res/layout/` | `res/layout/` |
| `app/src/main/res/drawable/` | `res/drawable/` |
| `app/src/main/res/drawable-nodpi/` | `res/drawable-nodpi/` |
| `app/src/main/res/values/` | `res/values/` |
| `app/src/main/res/xml/` | `res/xml/` |
| `app/src/main/AndroidManifest.xml` | Project Android manifest |

Preserve the `data`, `model`, `security`, and `util` Java subpackages. Remove
the Java App example's sample activity after copying `MainActivity.java` and
`LockActivity.java`.

## 3. Confirm the manifest

The launcher activity is:

```text
com.macleanofduartenterprises.crm.LockActivity
```

`MainActivity` is not exported. Android backup and cleartext network traffic
are disabled. The app requests no Android permissions:

- Calling opens the dialer without placing a call directly.
- Email opens the user's email app.
- Website and Cal.com links open the browser.
- Calendar integration opens a prefilled event.
- Backup uses Android's system file picker.

## 4. Test

1. Build an APK in App Builder.
2. Install it on a non-production test device.
3. Create the initial six-digit PIN.
4. Open **CRM Tools → Settings & security**.
5. Add the fictitious sample records.
6. Run every item in `TEST-CHECKLIST.md`.
7. Erase sample records before any approved real-data pilot.

The Gradle files are included for Android Studio compatibility. App Builder may
manage the same settings through its own project interface.

## 5. Publishing

Do not publish the included debug APK. Create or import a company-controlled
release keystore, increment `versionCode`, build a signed AAB, retain signing
recovery material securely, and complete privacy/security review first.

