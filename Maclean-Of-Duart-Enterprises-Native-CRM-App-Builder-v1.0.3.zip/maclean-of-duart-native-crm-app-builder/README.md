# Maclean Of Duart Enterprises CRM

A native Android customer relationship management app for Maclean Of Duart
Enterprises, prepared for Serakont App Builder II.

This is CRM software—not a website, WebView, HTML template, or URL wrapper.

## Company edition

The app includes:

- Company name: Maclean Of Duart Enterprises
- Phone: 717-500-6202
- Email: office@macleanofduartenterprises.com
- Website: https://macleanofduartenterprises.com
- Scheduling: https://cal.com/macleanofduartenterprises
- Transparent company logo
- Maclean Of Duart ancient dress tartan
- Logo light blue, heritage gold, cool silver, and dark pine-green palette
- Compact company header with a narrow tartan accent and tappable website,
  phone, and email details

Phone, email, website, and scheduling actions are available from the dashboard
and **CRM Tools → Company & booking**.

## CRM features

- Dashboard with client, lead, pipeline-value, task, and meeting metrics
- Searchable customer, household, and business records
- Five-stage pipeline: New lead, Qualified, Assessment, Proposal, Client
- Maclean Of Duart Enterprises technology-service categories
- Contact notes, follow-up tasks, priorities, due dates, and assignees
- Consultation scheduling and optional device-calendar handoff
- Inquiry intake for contact forms, live chat, phone, email, and referrals
- One-tap conversion of an inquiry into a CRM lead
- Recent-activity history
- Six-digit app PIN, inactivity lock, and failed-attempt lockout
- AES-GCM encryption of sensitive SQLite fields with Android Keystore
- Passphrase-protected encrypted export and full restore
- Native call, email, browser, and Cal.com handoff
- Auto-lock, demonstration-data, and secure-wipe settings

## Project facts

| Item | Value |
|---|---|
| Application ID | `com.macleanofduartenterprises.crm` |
| App name | Maclean Of Duart Enterprises CRM |
| Language | Java |
| UI | Native Android views and XML |
| Local database | SQLite |
| Minimum Android API | 23 |
| Target / compile API | 36 |
| Third-party libraries | None |
| Requested Android permissions | None |
| Version | 1.0.3 |

The included debug APK was compiled from this source against Android API 36
and verified with Android's APK signing and alignment tools. It is for
evaluation only; a published build must use the company's private release key.

## Start here

1. Follow [APP-BUILDER-II-SETUP.md](APP-BUILDER-II-SETUP.md).
2. Review [SECURITY-AND-PRODUCTION.md](SECURITY-AND-PRODUCTION.md).
3. Run [TEST-CHECKLIST.md](TEST-CHECKLIST.md) using fictitious data.

The standard Android source is under `app/src/main`. Important locations:

- `java/com/macleanofduartenterprises/crm/MainActivity.java`
- `java/com/macleanofduartenterprises/crm/data/DatabaseHelper.java`
- `java/com/macleanofduartenterprises/crm/security/`
- `res/layout/`
- `res/drawable/`, `res/drawable-nodpi/`, and `res/values/`
- `AndroidManifest.xml`

Original brand inputs and the transparent logo are retained in `branding/`.

## Functional boundary

This package is a functional, single-device CRM MVP. A secure backend is still
required for multiple employee accounts, permissions, cross-device sync,
automatic website/live-chat intake, centralized retention, managed backups,
remote revocation, and company-wide reporting.
