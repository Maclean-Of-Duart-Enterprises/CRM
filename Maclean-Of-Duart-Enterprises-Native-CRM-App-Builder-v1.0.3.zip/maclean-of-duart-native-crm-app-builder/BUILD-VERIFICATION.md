# Build verification

Validated July 29, 2026.

## Successful checks

- Android XML and raster resources compiled and linked with AAPT2
- Java sources compiled with Android API 36
- Bytecode converted to DEX with minimum API 23
- APK alignment passed
- APK signature verified with v1, v2, and v3 schemes
- Package: `com.macleanofduartenterprises.crm`
- Version: `1.0.3` / version code `4`
- Minimum API 23; target and compile API 36
- Launcher: `com.macleanofduartenterprises.crm.LockActivity`
- Permission dump contains no requested permissions
- Source contains no WebView or website-wrapper implementation

## Debug APK

File:

`Maclean-Of-Duart-Enterprises-CRM-v1.0.3-debug.apk`

SHA-256:

```text
5773616729e43db7cf296eb4dbc3f331e7d560d21014be33fd630a0f3706b9cc
```

The APK uses a temporary debug certificate and must not be uploaded to Google
Play.
