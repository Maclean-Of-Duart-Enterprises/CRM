# Security and production boundaries

## Implemented controls

- Six-digit application PIN stored as a salted PBKDF2 hash
- Failed-attempt lockout and configurable inactivity lock
- AES-GCM encryption for sensitive SQLite fields
- Non-exportable AES key generated in Android Keystore
- Android cloud/device backup disabled
- Cleartext network traffic disabled

Screenshots and screen recordings are allowed throughout the app at the
company owner's direction. The person creating or sharing a capture is
responsible for redacting customer and company information.
- No requested Android permissions
- Passphrase-encrypted AES-256-GCM backups
- Typed confirmation before destructive erase
- No advertising, analytics SDK, or third-party library

## Boundaries

The PIN gates this local interface; it is not a managed employee identity or
server-side authorization system. The Keystore key is not derived from the app
PIN.

This local edition does not provide multiple identities, role-based access,
cross-device sync, immutable centralized audit storage, managed backup
recovery, remote wipe, automatic website/live-chat ingestion, penetration
testing, or formal certification.

## Before real customer information

Maclean Of Duart Enterprises should decide and test:

1. Which customer information may be stored.
2. Which managed devices and people may access it.
3. Retention, deletion, export, and backup requirements.
4. Lost-device, incident-response, recovery, and key-custody procedures.
5. Privacy notices, communication consent, and vendor terms.
6. Applicable Pennsylvania, federal, contractual, and industry obligations.

Use fictitious data until that review is complete.

## Backend path

A future multi-user edition should use an authenticated API with MFA/SSO,
least-privilege roles, tenant isolation, encrypted transport/storage,
append-only audit events, monitored backups, rate limiting, remote revocation,
and validated website/live-chat webhook ingestion.
