# CRM 1.1.0

**A client relations management application**

CRM is a native Android client-relations workspace built with Java, Android
views, and SQLite. It is not a website, WebView, or HTML wrapper.

## Application identity

| Item | Value |
| --- | --- |
| App name | CRM |
| Motto | A client relations management application |
| Package ID | `com.macleanofduartenterprises.crm` |
| Version | `1.1.0` (`versionCode` 2) |
| Minimum Android | Android 6.0 / API 23 |
| Target Android | Android 15 / API 35 |

## Features

- Dashboard with client, lead, pipeline-value, task, appointment, and activity summaries
- Contact and household records with encrypted sensitive fields
- Single-contact merge, permanent delete, VCF share, and VCF export
- Stable manual multi-selection for bulk merge, delete, share, and VCF export
- Multi-file VCF import with a review checklist so only manually selected contacts are added
- Five-stage pipeline and opportunity tracking
- Notes, tasks, inquiries, consultation scheduling, and calendar handoff
- Six-digit local PIN, inactivity auto-lock, and failed-attempt lockout
- AES-256-GCM encrypted local backup and restore
- Fictitious demonstration data and complete local-data erasure
- Screenshots and screen recording enabled
- No `INTERNET` permission and no remote analytics

## Developer contact and licensing

Maclean Of Duart Enterprises contact and booking details appear only in
**Settings > Company & Booking**, except for the required license attribution
in the footer and License screen. The footer opens the same offline license
screen available through **Settings > License**.

The complete, unmodified GNU Affero General Public License version 3 is in
`LICENSE.txt` and is embedded in `app/src/main/res/raw/agpl_3_0.txt` for offline
reading inside the installed app. See `NOTICE.txt` for the application notice.

## Contact management behavior

Open **Contacts > Select contacts** to create a manual bulk set. Selections
remain active while searching, and **Select visible** only adds records in the
current filtered list. Bulk actions never automatically select or merge records
based on similar names.

During a merge, the user explicitly chooses the primary record. Its populated
fields and stable contact ID are retained; blank fields are filled from the
selected source records, the larger opportunity value is retained, linked
notes, tasks, and consultations are moved, and differing values are preserved
in an encrypted Merge note. Source contact records are deleted only after the
primary record and relationships are saved successfully.

VCF import accepts one or more files and presents every parsed contact as an
unchecked review list. Only checked contacts are added, and existing CRM
records are not modified. Imported fields that do not have a dedicated CRM
field are retained in an encrypted **Imported VCF** note. VCF export uses the
Android document picker, and sharing uses a temporary read-only content URI;
neither requires broad storage access.

Permanent delete removes the selected contact records, their linked notes, and
their contact/note activity history in one transaction. Related tasks and
consultations are retained but unlinked so operational work is not silently
lost.

## Build

The verified build uses JDK 17, Gradle 8.10.2, Android Gradle Plugin 8.7.3,
Android SDK 35, and Build Tools 35.0.1.

```bash
gradle --offline clean assembleRelease
```

For a signed release, place the private key at
`signature/release.keystore` and supply the three `CRM_*` environment
variables documented in `signature/README.md`. The private publishing key is
not part of this source distribution.

## Scope

This is a single-device CRM. Multi-user accounts, remote synchronization,
organization-wide reporting, and centralized administration require a secure
backend and an appropriate privacy, retention, and access-control design.
