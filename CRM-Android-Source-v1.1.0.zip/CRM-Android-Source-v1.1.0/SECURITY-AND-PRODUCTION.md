# Security and production notes

## Included protections

- Six-digit local PIN with PBKDF2 derivation
- Short lockout after repeated failed attempts
- Inactivity auto-lock
- AES-GCM encryption for selected database fields using Android Keystore
- AES-256-GCM encrypted export/restore with a user-supplied passphrase
- Android backup disabled
- Cleartext traffic disabled
- No `INTERNET` permission

Screenshots and screen recording are intentionally permitted. The user is
responsible for redacting private information before sharing a capture.

## Operational responsibilities

Before storing real client data, the deploying organization should define and
test device encryption, device loss response, access revocation, retention,
backup custody, restore testing, incident response, consent, and privacy
procedures. A local PIN does not replace managed-device controls.

## Current boundary

The application is single-device and local-first. It does not provide staff
accounts, centralized revocation, server-side auditing, remote synchronization,
or organization-wide reporting. Those functions require a trusted backend and
separate security review.

## Publishing

Distribute the corresponding source and preserve the copyright, notice, and
complete GNU AGPLv3 license. Never distribute the private publishing key.
