package com.macleanofduartenterprises.crm.contacts;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

/** Read-only, non-exported provider for temporary user-initiated VCF shares. */
public final class VCardProvider extends ContentProvider {
    private static final String DIRECTORY = "shared_vcards";

    public static Uri createShareUri(Context context, String requestedName, byte[] bytes)
            throws IOException {
        File directory = new File(context.getCacheDir(), DIRECTORY);
        if (!directory.exists() && !directory.mkdirs()) {
            throw new IOException("The temporary sharing directory could not be created.");
        }
        cleanOldFiles(directory);
        String name = safeName(requestedName);
        File destination = new File(directory, name);
        try (FileOutputStream output = new FileOutputStream(destination, false)) {
            output.write(bytes);
            output.flush();
            output.getFD().sync();
        }
        return new Uri.Builder()
                .scheme("content")
                .authority(context.getPackageName() + ".vcards")
                .appendPath(name)
                .build();
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public String getType(Uri uri) {
        return "text/vcard";
    }

    @Override
    public Cursor query(
            Uri uri,
            String[] projection,
            String selection,
            String[] selectionArgs,
            String sortOrder
    ) {
        File file;
        try {
            file = resolve(uri);
        } catch (FileNotFoundException exception) {
            return null;
        }
        String[] columns = projection == null
                ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}
                : projection;
        MatrixCursor cursor = new MatrixCursor(columns, 1);
        MatrixCursor.RowBuilder row = cursor.newRow();
        for (String column : columns) {
            if (OpenableColumns.DISPLAY_NAME.equals(column)) row.add(file.getName());
            else if (OpenableColumns.SIZE.equals(column)) row.add(file.length());
            else row.add(null);
        }
        return cursor;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) {
            throw new FileNotFoundException("VCF shares are read-only.");
        }
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("VCF shares are read-only.");
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("VCF shares are read-only.");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("VCF shares are read-only.");
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        Context context = getContext();
        String name = uri == null ? null : uri.getLastPathSegment();
        if (context == null || name == null || !safeName(name).equals(name)) {
            throw new FileNotFoundException("Invalid VCF share.");
        }
        try {
            File directory = new File(context.getCacheDir(), DIRECTORY).getCanonicalFile();
            File file = new File(directory, name).getCanonicalFile();
            if (!file.getPath().startsWith(directory.getPath() + File.separator)
                    || !file.isFile()) {
                throw new FileNotFoundException("VCF share not found.");
            }
            return file;
        } catch (IOException exception) {
            throw new FileNotFoundException("VCF share could not be opened.");
        }
    }

    private static String safeName(String requested) {
        String clean = requested == null ? "crm-contacts.vcf" : requested.trim();
        clean = clean.replaceAll("[^A-Za-z0-9._-]", "-");
        while (clean.contains("..")) clean = clean.replace("..", ".");
        if (clean.isEmpty() || clean.startsWith(".")) clean = "crm-contacts.vcf";
        if (!clean.toLowerCase(Locale.ROOT).endsWith(".vcf")) clean += ".vcf";
        return clean;
    }

    private static void cleanOldFiles(File directory) {
        File[] files = directory.listFiles();
        if (files == null) return;
        long cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
        for (File file : files) {
            if (file.isFile() && file.lastModified() < cutoff) {
                // Best effort only; a currently shared file may remain until cache cleanup.
                file.delete();
            }
        }
    }
}
