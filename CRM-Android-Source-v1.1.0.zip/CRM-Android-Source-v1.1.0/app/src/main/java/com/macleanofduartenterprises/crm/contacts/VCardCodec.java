package com.macleanofduartenterprises.crm.contacts;

import com.macleanofduartenterprises.crm.model.Contact;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Encodes and decodes interoperable vCard 3.0 contact files without network access. */
public final class VCardCodec {
    private static final int MAX_CARDS = 1000;

    private VCardCodec() {
    }

    public static byte[] encode(List<Contact> contacts) {
        StringBuilder output = new StringBuilder();
        if (contacts == null) {
            return new byte[0];
        }
        for (Contact contact : contacts) {
            if (contact == null) continue;
            appendLine(output, "BEGIN:VCARD");
            appendLine(output, "VERSION:3.0");
            appendLine(output, "PRODID:-//Maclean Of Duart Enterprises//CRM 1.1.0//EN");
            appendLine(
                    output,
                    "N:" + escape(contact.lastName) + ";" + escape(contact.firstName) + ";;;"
            );
            appendLine(output, "FN:" + escape(formattedName(contact)));
            appendIfPresent(output, "ORG:", contact.household);
            appendIfPresent(output, "EMAIL;TYPE=INTERNET:", contact.email);
            appendIfPresent(output, "TEL;TYPE=CELL:", contact.phone);
            appendIfPresent(output, "CATEGORIES:", contact.service);
            appendIfPresent(output, "X-CRM-STAGE:", contact.stage);
            appendIfPresent(output, "X-CRM-SERVICE:", contact.service);
            appendIfPresent(output, "X-CRM-SOURCE:", contact.source);
            appendIfPresent(output, "X-CRM-ADVISOR:", contact.advisor);
            if (contact.estimatedValue != 0) {
                appendLine(
                        output,
                        "X-CRM-ESTIMATED-VALUE:"
                                + String.format(Locale.US, "%.2f", contact.estimatedValue)
                );
            }
            appendIfPresent(output, "X-CRM-NEXT-ACTION:", contact.nextAction);
            appendLine(output, "X-CRM-CONSENT:" + (contact.consent ? "TRUE" : "FALSE"));
            appendIfPresent(output, "X-CRM-STATUS:", contact.status);
            appendLine(output, "END:VCARD");
        }
        return output.toString().getBytes(StandardCharsets.UTF_8);
    }

    public static List<ImportedContact> decode(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return new ArrayList<>();
        }
        String source = new String(bytes, StandardCharsets.UTF_8);
        if (!source.isEmpty() && source.charAt(0) == '\uFEFF') {
            source = source.substring(1);
        }
        List<String> lines = unfold(source);
        List<ImportedContact> result = new ArrayList<>();
        CardBuilder current = null;
        for (String line : lines) {
            String upper = line.trim().toUpperCase(Locale.US);
            if ("BEGIN:VCARD".equals(upper)) {
                current = new CardBuilder();
                continue;
            }
            if ("END:VCARD".equals(upper)) {
                if (current != null) {
                    ImportedContact parsed = current.build();
                    if (parsed != null) {
                        result.add(parsed);
                        if (result.size() > MAX_CARDS) {
                            throw new IllegalArgumentException(
                                    "A maximum of " + MAX_CARDS + " contacts can be imported at once."
                            );
                        }
                    }
                }
                current = null;
                continue;
            }
            if (current != null) {
                current.accept(line);
            }
        }
        return result;
    }

    private static void appendIfPresent(StringBuilder output, String prefix, String value) {
        if (value != null && !value.trim().isEmpty()) {
            appendLine(output, prefix + escape(value.trim()));
        }
    }

    private static String formattedName(Contact contact) {
        String person = ((contact.firstName == null ? "" : contact.firstName) + " "
                + (contact.lastName == null ? "" : contact.lastName)).trim();
        return person.isEmpty() ? contact.displayName() : person;
    }

    private static void appendLine(StringBuilder output, String line) {
        if (line.isEmpty()) {
            output.append("\r\n");
            return;
        }
        int offset = 0;
        int byteLimit = 75;
        while (offset < line.length()) {
            int end = offset;
            int byteCount = 0;
            while (end < line.length()) {
                int codePoint = line.codePointAt(end);
                int encodedBytes = utf8Length(codePoint);
                if (byteCount + encodedBytes > byteLimit && end > offset) break;
                byteCount += encodedBytes;
                end += Character.charCount(codePoint);
            }
            if (offset > 0) output.append(' ');
            output.append(line, offset, end).append("\r\n");
            offset = end;
            // A continuation line's leading space counts toward the 75-octet limit.
            byteLimit = 74;
        }
    }

    private static int utf8Length(int codePoint) {
        if (codePoint <= 0x7F) return 1;
        if (codePoint <= 0x7FF) return 2;
        if (codePoint <= 0xFFFF) return 3;
        return 4;
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value
                .replace("\\", "\\\\")
                .replace("\r\n", "\\n")
                .replace("\n", "\\n")
                .replace("\r", "\\n")
                .replace(";", "\\;")
                .replace(",", "\\,");
    }

    private static String unescape(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;
        for (int index = 0; index < value.length(); index++) {
            char current = value.charAt(index);
            if (escaped) {
                result.append(current == 'n' || current == 'N' ? '\n' : current);
                escaped = false;
            } else if (current == '\\') {
                escaped = true;
            } else {
                result.append(current);
            }
        }
        if (escaped) result.append('\\');
        return result.toString();
    }

    private static List<String> unfold(String source) {
        String normalized = source.replace("\r\n", "\n").replace('\r', '\n');
        String[] physical = normalized.split("\n", -1);
        List<String> result = new ArrayList<>();
        StringBuilder current = null;
        for (String line : physical) {
            if (current != null
                    && current.toString().toUpperCase(Locale.US)
                    .contains("ENCODING=QUOTED-PRINTABLE")
                    && current.length() > 0
                    && current.charAt(current.length() - 1) == '=') {
                current.deleteCharAt(current.length() - 1);
                current.append(line);
            } else if (current != null && (line.startsWith(" ") || line.startsWith("\t"))) {
                current.append(line.substring(1));
            } else {
                if (current != null) result.add(current.toString());
                current = new StringBuilder(line);
            }
        }
        if (current != null) result.add(current.toString());
        return result;
    }

    private static List<String> splitEscaped(String value, char delimiter) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean escaped = false;
        for (int index = 0; index < value.length(); index++) {
            char item = value.charAt(index);
            if (escaped) {
                current.append('\\').append(item);
                escaped = false;
            } else if (item == '\\') {
                escaped = true;
            } else if (item == delimiter) {
                result.add(unescape(current.toString()).trim());
                current.setLength(0);
            } else {
                current.append(item);
            }
        }
        if (escaped) current.append('\\');
        result.add(unescape(current.toString()).trim());
        return result;
    }

    private static String decodedValue(String header, String value) {
        if (!header.toUpperCase(Locale.US).contains("ENCODING=QUOTED-PRINTABLE")) {
            return unescape(value).trim();
        }
        return unescape(decodeQuotedPrintable(header, value)).trim();
    }

    private static String decodeQuotedPrintable(String header, String value) {
        Charset charset = StandardCharsets.UTF_8;
        String upper = header.toUpperCase(Locale.US);
        int marker = upper.indexOf("CHARSET=");
        if (marker >= 0) {
            int start = marker + "CHARSET=".length();
            int end = header.indexOf(';', start);
            String name = header.substring(start, end < 0 ? header.length() : end).trim();
            try {
                charset = Charset.forName(name);
            } catch (RuntimeException ignored) {
                charset = StandardCharsets.UTF_8;
            }
        }
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        for (int index = 0; index < value.length(); index++) {
            char item = value.charAt(index);
            if (item == '=' && index + 2 < value.length()) {
                int high = Character.digit(value.charAt(index + 1), 16);
                int low = Character.digit(value.charAt(index + 2), 16);
                if (high >= 0 && low >= 0) {
                    output.write((high << 4) | low);
                    index += 2;
                    continue;
                }
            }
            byte[] encoded = String.valueOf(item).getBytes(StandardCharsets.UTF_8);
            output.write(encoded, 0, encoded.length);
        }
        return new String(output.toByteArray(), charset).trim();
    }

    private static boolean validStage(String stage) {
        for (String candidate : Contact.STAGES) {
            if (candidate.equalsIgnoreCase(stage)) return true;
        }
        return false;
    }

    public static final class ImportedContact {
        public final Contact contact;
        public final String importedNote;

        ImportedContact(Contact contact, String importedNote) {
            this.contact = contact;
            this.importedNote = importedNote == null ? "" : importedNote.trim();
        }

        public String label() {
            String detail = !contact.email.isEmpty() ? contact.email : contact.phone;
            return detail.isEmpty() ? contact.displayName() : contact.displayName() + " — " + detail;
        }
    }

    private static final class CardBuilder {
        private final Contact contact = new Contact();
        private final List<String> extraDetails = new ArrayList<>();
        private String formattedName = "";

        void accept(String line) {
            int separator = line.indexOf(':');
            if (separator <= 0) return;
            String header = line.substring(0, separator);
            String value = line.substring(separator + 1);
            String property = header;
            int parameters = property.indexOf(';');
            if (parameters >= 0) property = property.substring(0, parameters);
            int group = property.lastIndexOf('.');
            if (group >= 0) property = property.substring(group + 1);
            property = property.toUpperCase(Locale.US);
            String decoded = decodedValue(header, value);

            switch (property) {
                case "N":
                    List<String> names = splitEscaped(structuredValue(header, value), ';');
                    if (!names.isEmpty()) contact.lastName = names.get(0);
                    if (names.size() > 1) contact.firstName = names.get(1);
                    break;
                case "FN":
                    formattedName = decoded;
                    break;
                case "ORG":
                    List<String> organization = splitEscaped(structuredValue(header, value), ';');
                    contact.household = joinParts(organization, " / ");
                    break;
                case "EMAIL":
                    addPrimaryOrAlternate("Email", decoded, true);
                    break;
                case "TEL":
                    addPrimaryOrAlternate("Phone", decoded, false);
                    break;
                case "CATEGORIES":
                    if (contact.service.isEmpty()) contact.service = decoded;
                    break;
                case "NOTE":
                    if (!decoded.isEmpty()) extraDetails.add(decoded);
                    break;
                case "ADR":
                    String address = joinParts(
                            splitEscaped(structuredValue(header, value), ';'),
                            ", "
                    );
                    if (!address.isEmpty()) extraDetails.add("Address: " + address);
                    break;
                case "URL":
                    if (!decoded.isEmpty()) extraDetails.add("Website: " + decoded);
                    break;
                case "TITLE":
                    if (!decoded.isEmpty()) extraDetails.add("Title: " + decoded);
                    break;
                case "X-CRM-STAGE":
                    if (validStage(decoded)) contact.stage = decoded;
                    break;
                case "X-CRM-SERVICE":
                    contact.service = decoded;
                    break;
                case "X-CRM-SOURCE":
                    contact.source = decoded;
                    break;
                case "X-CRM-ADVISOR":
                    contact.advisor = decoded;
                    break;
                case "X-CRM-ESTIMATED-VALUE":
                    try {
                        contact.estimatedValue = Double.parseDouble(decoded);
                    } catch (NumberFormatException ignored) {
                        contact.estimatedValue = 0;
                    }
                    break;
                case "X-CRM-NEXT-ACTION":
                    contact.nextAction = decoded;
                    break;
                case "X-CRM-CONSENT":
                    contact.consent = "TRUE".equalsIgnoreCase(decoded)
                            || "YES".equalsIgnoreCase(decoded)
                            || "1".equals(decoded);
                    break;
                case "X-CRM-STATUS":
                    contact.status = decoded.isEmpty() ? "Active" : decoded;
                    break;
                default:
                    break;
            }
        }

        ImportedContact build() {
            if (contact.firstName.trim().isEmpty()
                    && contact.lastName.trim().isEmpty()
                    && contact.household.trim().isEmpty()) {
                applyFormattedName();
            }
            if (contact.firstName.trim().isEmpty()
                    && contact.lastName.trim().isEmpty()
                    && contact.household.trim().isEmpty()) {
                return null;
            }
            if (contact.source.trim().isEmpty()) contact.source = "VCF import";
            if (contact.status.trim().isEmpty()) contact.status = "Active";
            return new ImportedContact(contact, joinParts(extraDetails, "\n"));
        }

        private void applyFormattedName() {
            String value = formattedName.trim();
            if (value.isEmpty()) return;
            int split = value.lastIndexOf(' ');
            if (split > 0) {
                contact.firstName = value.substring(0, split).trim();
                contact.lastName = value.substring(split + 1).trim();
            } else {
                contact.firstName = value;
            }
        }

        private void addPrimaryOrAlternate(String label, String value, boolean email) {
            if (value.isEmpty()) return;
            String current = email ? contact.email : contact.phone;
            if (current.isEmpty()) {
                if (email) contact.email = value;
                else contact.phone = value;
            } else if (!current.equalsIgnoreCase(value)) {
                extraDetails.add("Alternate " + label.toLowerCase(Locale.US) + ": " + value);
            }
        }
    }

    private static String structuredValue(String header, String value) {
        if (header.toUpperCase(Locale.US).contains("ENCODING=QUOTED-PRINTABLE")) {
            return decodeQuotedPrintable(header, value);
        }
        return value;
    }

    private static String joinParts(List<String> parts, String separator) {
        StringBuilder result = new StringBuilder();
        for (String part : parts) {
            String clean = part == null ? "" : part.trim();
            if (clean.isEmpty()) continue;
            if (result.length() > 0) result.append(separator);
            result.append(clean);
        }
        return result.toString();
    }
}
