package com.macleanofduartenterprises.crm.security;

import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public final class BackupCodec {
    private static final String FORMAT = "CRM-BACKUP";
    private static final int VERSION = 1;
    private static final int ITERATIONS = 240_000;
    private static final byte[] AAD = "CRMBackupV1".getBytes(StandardCharsets.UTF_8);

    private BackupCodec() {
    }

    public static byte[] encrypt(JSONObject data, char[] passphrase) {
        validatePassphrase(passphrase);
        try {
            byte[] salt = randomBytes(16);
            byte[] iv = randomBytes(12);
            KeyResult key = derive(passphrase, salt, null);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key.key, new GCMParameterSpec(128, iv));
            cipher.updateAAD(AAD);
            byte[] encrypted = cipher.doFinal(
                    data.toString().getBytes(StandardCharsets.UTF_8)
            );

            JSONObject envelope = new JSONObject();
            envelope.put("format", FORMAT);
            envelope.put("version", VERSION);
            envelope.put("algorithm", "AES-256-GCM");
            envelope.put("kdf", key.kdf);
            envelope.put("iterations", ITERATIONS);
            envelope.put("salt", Base64.encodeToString(salt, Base64.NO_WRAP));
            envelope.put("iv", Base64.encodeToString(iv, Base64.NO_WRAP));
            envelope.put("payload", Base64.encodeToString(encrypted, Base64.NO_WRAP));
            return envelope.toString().getBytes(StandardCharsets.UTF_8);
        } catch (Exception exception) {
            throw new IllegalStateException("The encrypted backup could not be created.", exception);
        }
    }

    public static JSONObject decrypt(byte[] encodedBackup, char[] passphrase) {
        validatePassphrase(passphrase);
        try {
            JSONObject envelope = new JSONObject(
                    new String(encodedBackup, StandardCharsets.UTF_8)
            );
            if (!FORMAT.equals(envelope.optString("format"))
                    || envelope.optInt("version") != VERSION) {
                throw new IllegalArgumentException("This is not a supported CRM backup.");
            }
            byte[] salt = Base64.decode(envelope.getString("salt"), Base64.NO_WRAP);
            byte[] iv = Base64.decode(envelope.getString("iv"), Base64.NO_WRAP);
            byte[] payload = Base64.decode(envelope.getString("payload"), Base64.NO_WRAP);
            String kdf = envelope.getString("kdf");
            int iterations = envelope.optInt("iterations", 0);
            if (iterations != ITERATIONS) {
                throw new IllegalArgumentException("Unsupported backup key settings.");
            }

            KeyResult key = derive(passphrase, salt, kdf);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key.key, new GCMParameterSpec(128, iv));
            cipher.updateAAD(AAD);
            byte[] clear = cipher.doFinal(payload);
            return new JSONObject(new String(clear, StandardCharsets.UTF_8));
        } catch (IllegalArgumentException exception) {
            throw exception;
        } catch (Exception exception) {
            throw new IllegalArgumentException(
                    "The backup could not be opened. Check the passphrase and file.",
                    exception
            );
        }
    }

    private static KeyResult derive(char[] passphrase, byte[] salt, String preferredKdf) {
        String[] algorithms = preferredKdf == null
                ? new String[]{"PBKDF2WithHmacSHA256", "PBKDF2WithHmacSHA1"}
                : new String[]{preferredKdf};
        Exception last = null;
        for (String algorithm : algorithms) {
            PBEKeySpec spec = new PBEKeySpec(passphrase, salt, ITERATIONS, 256);
            try {
                byte[] bytes = SecretKeyFactory.getInstance(algorithm)
                        .generateSecret(spec)
                        .getEncoded();
                return new KeyResult(algorithm, new SecretKeySpec(bytes, "AES"));
            } catch (Exception exception) {
                last = exception;
            } finally {
                spec.clearPassword();
            }
        }
        throw new IllegalStateException("Backup key derivation is unavailable.", last);
    }

    private static byte[] randomBytes(int length) {
        byte[] value = new byte[length];
        new SecureRandom().nextBytes(value);
        return value;
    }

    private static void validatePassphrase(char[] passphrase) {
        if (passphrase == null || passphrase.length < 10) {
            throw new IllegalArgumentException(
                    "Use a backup passphrase containing at least 10 characters."
            );
        }
    }

    private static final class KeyResult {
        final String kdf;
        final SecretKeySpec key;

        KeyResult(String kdf, SecretKeySpec key) {
            this.kdf = kdf;
            this.key = key;
        }
    }
}
