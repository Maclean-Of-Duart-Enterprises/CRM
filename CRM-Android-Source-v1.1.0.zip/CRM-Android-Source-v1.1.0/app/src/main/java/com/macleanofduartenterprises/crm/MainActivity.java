package com.macleanofduartenterprises.crm;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.macleanofduartenterprises.crm.contacts.VCardCodec;
import com.macleanofduartenterprises.crm.contacts.VCardProvider;
import com.macleanofduartenterprises.crm.data.DatabaseHelper;
import com.macleanofduartenterprises.crm.model.ActivityEntry;
import com.macleanofduartenterprises.crm.model.Appointment;
import com.macleanofduartenterprises.crm.model.Contact;
import com.macleanofduartenterprises.crm.model.Inquiry;
import com.macleanofduartenterprises.crm.model.NoteItem;
import com.macleanofduartenterprises.crm.model.TaskItem;
import com.macleanofduartenterprises.crm.security.BackupCodec;
import com.macleanofduartenterprises.crm.security.PinManager;
import com.macleanofduartenterprises.crm.security.SessionGuard;
import com.macleanofduartenterprises.crm.util.AppDate;
import com.macleanofduartenterprises.crm.util.Formatters;
import com.macleanofduartenterprises.crm.util.Ui;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class MainActivity extends Activity {
    private static final int REQUEST_CREATE_BACKUP = 8101;
    private static final int REQUEST_OPEN_BACKUP = 8102;
    private static final int REQUEST_CREATE_VCARD = 8201;
    private static final int REQUEST_OPEN_VCARD = 8202;
    private static final int MAX_BACKUP_BYTES = 25 * 1024 * 1024;
    private static final int MAX_VCARD_BYTES = 10 * 1024 * 1024;

    private enum Screen {
        DASHBOARD,
        CONTACTS,
        CONTACT_DETAIL,
        PIPELINE,
        TASKS,
        MORE,
        APPOINTMENTS,
        INQUIRIES,
        COMPANY,
        BACKUP,
        SETTINGS,
        LICENSE
    }

    private DatabaseHelper database;
    private SharedPreferences settings;
    private FrameLayout contentFrame;
    private TextView screenTitle;
    private TextView screenSubtitle;
    private Button topAddButton;
    private Button navDashboard;
    private Button navContacts;
    private Button navPipeline;
    private Button navTasks;
    private Button navMore;
    private Screen currentScreen = Screen.DASHBOARD;
    private long currentContactId;
    private byte[] pendingExportBytes;
    private byte[] pendingImportBytes;
    private byte[] pendingVCardExportBytes;
    private final Set<Long> selectedContactIds = new LinkedHashSet<>();
    private boolean contactSelectionMode;
    private String contactSearchQuery = "";
    private boolean includeArchivedContacts;
    private TextView contactSelectionSummary;
    private Button contactMergeButton;
    private Button contactShareButton;
    private Button contactExportButton;
    private Button contactDeleteButton;
    private boolean routingToLock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!SessionGuard.isUnlocked(this)) {
            routeToLock();
            return;
        }

        setContentView(R.layout.activity_main);
        database = new DatabaseHelper(this);
        settings = getSharedPreferences("crm_settings", Context.MODE_PRIVATE);
        contentFrame = findViewById(R.id.contentFrame);
        screenTitle = findViewById(R.id.screenTitle);
        screenSubtitle = findViewById(R.id.screenSubtitle);
        topAddButton = findViewById(R.id.topAddButton);
        navDashboard = findViewById(R.id.navDashboard);
        navContacts = findViewById(R.id.navContacts);
        navPipeline = findViewById(R.id.navPipeline);
        navTasks = findViewById(R.id.navTasks);
        navMore = findViewById(R.id.navMore);

        TextView licenseFooter = findViewById(R.id.licenseFooter);
        licenseFooter.setPaintFlags(
                licenseFooter.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG
        );
        licenseFooter.setOnClickListener(view -> showScreen(Screen.LICENSE));

        navDashboard.setOnClickListener(view -> showScreen(Screen.DASHBOARD));
        navContacts.setOnClickListener(view -> showScreen(Screen.CONTACTS));
        navPipeline.setOnClickListener(view -> showScreen(Screen.PIPELINE));
        navTasks.setOnClickListener(view -> showScreen(Screen.TASKS));
        navMore.setOnClickListener(view -> showScreen(Screen.MORE));
        topAddButton.setOnClickListener(view -> handleTopAdd());
        findViewById(R.id.topLockButton).setOnClickListener(view -> {
            SessionGuard.lock();
            routeToLock();
        });

        showScreen(Screen.DASHBOARD);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (database != null && !routingToLock && !SessionGuard.isUnlocked(this)) {
            routeToLock();
        }
    }

    @Override
    protected void onDestroy() {
        clearBytes(pendingExportBytes);
        clearBytes(pendingImportBytes);
        clearBytes(pendingVCardExportBytes);
        if (database != null) {
            database.close();
        }
        super.onDestroy();
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        SessionGuard.touch();
    }

    @Override
    public void onBackPressed() {
        switch (currentScreen) {
            case CONTACT_DETAIL:
                showScreen(Screen.CONTACTS);
                return;
            case APPOINTMENTS:
            case INQUIRIES:
            case COMPANY:
            case BACKUP:
                showScreen(Screen.MORE);
                return;
            case SETTINGS:
                showScreen(Screen.MORE);
                return;
            case LICENSE:
                showScreen(Screen.SETTINGS);
                return;
            case CONTACTS:
                if (contactSelectionMode) {
                    contactSelectionMode = false;
                    selectedContactIds.clear();
                    showContacts();
                    return;
                }
            case PIPELINE:
            case TASKS:
            case MORE:
                showScreen(Screen.DASHBOARD);
                return;
            default:
                super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) {
            if (requestCode == REQUEST_CREATE_BACKUP) {
                clearBytes(pendingExportBytes);
                pendingExportBytes = null;
            } else if (requestCode == REQUEST_CREATE_VCARD) {
                clearBytes(pendingVCardExportBytes);
                pendingVCardExportBytes = null;
            }
            return;
        }
        Uri selected = data.getData();
        if (requestCode == REQUEST_CREATE_BACKUP && selected != null) {
            writePendingBackup(selected);
        } else if (requestCode == REQUEST_OPEN_BACKUP && selected != null) {
            loadBackupForImport(selected);
        } else if (requestCode == REQUEST_CREATE_VCARD && selected != null) {
            writePendingVCard(selected);
        } else if (requestCode == REQUEST_OPEN_VCARD) {
            loadVCardImport(data);
        } else if (requestCode == REQUEST_CREATE_VCARD) {
            clearBytes(pendingVCardExportBytes);
            pendingVCardExportBytes = null;
        }
    }

    private void routeToLock() {
        if (routingToLock) {
            return;
        }
        routingToLock = true;
        startActivity(new Intent(this, LockActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        finish();
    }

    private void showScreen(Screen screen) {
        currentScreen = screen;
        topAddButton.setVisibility(View.VISIBLE);
        switch (screen) {
            case DASHBOARD:
                configureHeader("Dashboard", Screen.DASHBOARD);
                showDashboard();
                break;
            case CONTACTS:
                configureHeader("Contacts", Screen.CONTACTS);
                showContacts();
                break;
            case PIPELINE:
                configureHeader("Pipeline", Screen.PIPELINE);
                showPipeline();
                break;
            case TASKS:
                configureHeader("Tasks", Screen.TASKS);
                showTasks();
                break;
            case MORE:
                configureHeader("CRM Tools", Screen.MORE);
                topAddButton.setVisibility(View.GONE);
                showMore();
                break;
            case APPOINTMENTS:
                configureHeader("Consultations", Screen.MORE);
                showAppointments();
                break;
            case INQUIRIES:
                configureHeader("Inquiries", Screen.MORE);
                showInquiries();
                break;
            case COMPANY:
                configureHeader("Company & Booking", Screen.MORE);
                topAddButton.setVisibility(View.GONE);
                showCompany();
                break;
            case BACKUP:
                configureHeader("Backup & Restore", Screen.MORE);
                topAddButton.setVisibility(View.GONE);
                showBackup();
                break;
            case SETTINGS:
                configureHeader("Settings", Screen.MORE);
                topAddButton.setVisibility(View.GONE);
                showSettings();
                break;
            case LICENSE:
                configureHeader("License", Screen.MORE);
                topAddButton.setVisibility(View.GONE);
                showLicense();
                break;
            case CONTACT_DETAIL:
                configureHeader("Contact", Screen.CONTACTS);
                showContactDetail(currentContactId);
                break;
        }
    }

    private void configureHeader(String title, Screen selectedNav) {
        screenTitle.setText(R.string.app_name);
        screenSubtitle.setText(R.string.app_motto);
        setNavSelected(navDashboard, selectedNav == Screen.DASHBOARD);
        setNavSelected(navContacts, selectedNav == Screen.CONTACTS);
        setNavSelected(navPipeline, selectedNav == Screen.PIPELINE);
        setNavSelected(navTasks, selectedNav == Screen.TASKS);
        setNavSelected(navMore, selectedNav == Screen.MORE);
    }

    private void setNavSelected(Button button, boolean selected) {
        if (selected) {
            button.setBackgroundResource(R.drawable.bg_nav_selected);
            button.setTextColor(getColor(R.color.navy_900));
        } else {
            button.setBackgroundColor(Color.TRANSPARENT);
            button.setTextColor(getColor(R.color.muted));
        }
    }

    private void handleTopAdd() {
        switch (currentScreen) {
            case DASHBOARD:
            case CONTACTS:
            case PIPELINE:
                showContactDialog(null);
                break;
            case CONTACT_DETAIL:
                Contact contact = database.getContact(currentContactId);
                if (contact != null) {
                    showContactDialog(contact);
                }
                break;
            case TASKS:
                showTaskDialog(null, 0);
                break;
            case APPOINTMENTS:
                showAppointmentDialog(null);
                break;
            case INQUIRIES:
                showInquiryDialog(null);
                break;
            default:
                break;
        }
    }

    private void setContent(View view) {
        contentFrame.removeAllViews();
        contentFrame.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    private void refreshCurrentScreen() {
        showScreen(currentScreen);
    }

    private void showDashboard() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.smallLabel(this, "Dashboard"), Ui.match());
        page.addView(Ui.heading(this, "Good work starts with a clear next action."), margin(0, 5));
        page.addView(
                Ui.muted(
                        this,
                        "Keep clients, opportunities, consultations, tasks, and follow-up in one local workspace."
                ),
                margin(0, 6)
        );

        LinearLayout metricRowOne = Ui.row(this);
        metricRowOne.addView(
                metricCard("CLIENTS", String.valueOf(database.countContacts("Client")), "Active relationships"),
                weightedMargin(1, 0, 6, 0, 0)
        );
        metricRowOne.addView(
                metricCard(
                        "OPEN LEADS",
                        String.valueOf(Math.max(
                                0,
                                database.countContacts(null) - database.countContacts("Client")
                        )),
                        "Across the pipeline"
                ),
                weightedMargin(1, 6, 0, 0, 0)
        );
        page.addView(metricRowOne, margin(0, 16));

        LinearLayout metricRowTwo = Ui.row(this);
        metricRowTwo.addView(
                metricCard(
                        "PIPELINE VALUE",
                        Formatters.compactMoney(database.sumOpenOpportunityValue()),
                        "Estimated open work"
                ),
                weightedMargin(1, 0, 6, 0, 0)
        );
        metricRowTwo.addView(
                metricCard(
                        "OPEN TASKS",
                        String.valueOf(database.countOpenTasks()),
                        database.countOverdueTasks() + " overdue"
                ),
                weightedMargin(1, 6, 0, 0, 0)
        );
        page.addView(metricRowTwo, margin(0, 10));

        page.addView(Ui.section(this, "Quick actions"), margin(0, 20));
        LinearLayout actions = Ui.row(this);
        Button addContact = Ui.primaryButton(this, "Add contact");
        Button addTask = Ui.secondaryButton(this, "Add task");
        Button addMeeting = Ui.secondaryButton(this, "Consultation");
        actions.addView(addContact, weightedMargin(1, 0, 4, 0, 0));
        actions.addView(addTask, weightedMargin(1, 4, 4, 0, 0));
        actions.addView(addMeeting, weightedMargin(1, 4, 0, 0, 0));
        page.addView(actions, margin(0, 8));
        addContact.setOnClickListener(view -> showContactDialog(null));
        addTask.setOnClickListener(view -> showTaskDialog(null, 0));
        addMeeting.setOnClickListener(view -> showAppointmentDialog(null));

        page.addView(Ui.section(this, "Upcoming consultations"), margin(0, 24));
        List<Appointment> appointments = database.getAppointments(true);
        if (appointments.isEmpty()) {
            page.addView(emptyCard(
                    "No upcoming consultations",
                    "Create a consultation here, then optionally add it to the device calendar."
            ), margin(0, 8));
        } else {
            for (int index = 0; index < Math.min(3, appointments.size()); index++) {
                Appointment appointment = appointments.get(index);
                LinearLayout card = Ui.card(this);
                card.addView(Ui.smallLabel(this, appointment.status), Ui.match());
                card.addView(Ui.body(this, appointment.title), margin(0, 5));
                card.addView(
                        Ui.muted(this, AppDate.formatDateTime(appointment.startTime)
                                + " · " + appointment.durationMinutes + " min"),
                        margin(0, 4)
                );
                card.setOnClickListener(view -> {
                    showAppointmentDialog(appointment);
                });
                page.addView(card, margin(0, 8));
            }
            Button all = Ui.secondaryButton(this, "View all consultations");
            all.setOnClickListener(view -> showScreen(Screen.APPOINTMENTS));
            page.addView(all, margin(0, 8));
        }

        page.addView(Ui.section(this, "Recent activity"), margin(0, 24));
        List<ActivityEntry> activity = database.getRecentActivity(7);
        if (activity.isEmpty()) {
            page.addView(emptyCard(
                    "No CRM activity yet",
                    "Add a contact, inquiry, task, or consultation to begin."
            ), margin(0, 8));
        } else {
            for (ActivityEntry entry : activity) {
                LinearLayout row = Ui.card(this);
                row.addView(Ui.smallLabel(this, entry.action), Ui.match());
                row.addView(Ui.body(this, entry.summary), margin(0, 4));
                row.addView(Ui.muted(this, readableStamp(entry.createdAt)), margin(0, 3));
                page.addView(row, margin(0, 7));
            }
        }
        setContent(Ui.scrollPage(this, page));
    }

    private LinearLayout metricCard(String label, String value, String detail) {
        LinearLayout card = Ui.card(this);
        card.setClickable(false);
        card.setFocusable(false);
        card.addView(Ui.smallLabel(this, label), Ui.match());
        TextView number = Ui.heading(this, value);
        number.setTextSize(25);
        card.addView(number, margin(0, 7));
        card.addView(Ui.muted(this, detail), margin(0, 4));
        return card;
    }

    private LinearLayout emptyCard(String title, String description) {
        LinearLayout card = Ui.card(this);
        card.setClickable(false);
        card.setFocusable(false);
        card.addView(Ui.body(this, title), Ui.match());
        card.addView(Ui.muted(this, description), margin(0, 5));
        return card;
    }

    private void showContacts() {
        pruneContactSelection();
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Contacts"), Ui.match());
        page.addView(Ui.body(
                this,
                "Households, prospects, and clients with one record of relationship activity."
        ), margin(0, 7));

        LinearLayout contactActions = Ui.row(this);
        Button manage = Ui.secondaryButton(
                this,
                contactSelectionMode ? "Done selecting" : "Select contacts"
        );
        Button importVcf = Ui.primaryButton(this, "Import VCF");
        contactActions.addView(manage, weightedMargin(1, 0, 4, 0, 0));
        contactActions.addView(importVcf, weightedMargin(1, 4, 0, 0, 0));
        page.addView(contactActions, margin(0, 14));
        manage.setOnClickListener(view -> {
            contactSelectionMode = !contactSelectionMode;
            if (!contactSelectionMode) selectedContactIds.clear();
            showContacts();
        });
        importVcf.setOnClickListener(view -> chooseVCardFiles());

        Button selectVisible = null;
        if (contactSelectionMode) {
            LinearLayout selection = Ui.card(this);
            selection.setClickable(false);
            contactSelectionSummary = Ui.body(this, "0 contacts selected");
            selection.addView(contactSelectionSummary, Ui.match());
            selection.addView(
                    Ui.muted(
                            this,
                            "Selections remain active while searching so you can build a precise bulk set."
                    ),
                    margin(0, 5)
            );

            LinearLayout selectionTools = Ui.row(this);
            selectVisible = Ui.secondaryButton(this, "Select visible");
            Button clear = Ui.secondaryButton(this, "Clear");
            selectionTools.addView(selectVisible, weightedMargin(1, 0, 4, 0, 0));
            selectionTools.addView(clear, weightedMargin(1, 4, 0, 0, 0));
            selection.addView(selectionTools, margin(0, 12));
            clear.setOnClickListener(view -> {
                selectedContactIds.clear();
                showContacts();
            });

            LinearLayout managementOne = Ui.row(this);
            contactMergeButton = Ui.secondaryButton(this, "Merge");
            contactShareButton = Ui.secondaryButton(this, "Share");
            managementOne.addView(contactMergeButton, weightedMargin(1, 0, 4, 0, 0));
            managementOne.addView(contactShareButton, weightedMargin(1, 4, 0, 0, 0));
            selection.addView(managementOne, margin(0, 8));

            LinearLayout managementTwo = Ui.row(this);
            contactExportButton = Ui.secondaryButton(this, "Export VCF");
            contactDeleteButton = Ui.dangerButton(this, "Delete");
            managementTwo.addView(contactExportButton, weightedMargin(1, 0, 4, 0, 0));
            managementTwo.addView(contactDeleteButton, weightedMargin(1, 4, 0, 0, 0));
            selection.addView(managementTwo, margin(0, 8));

            contactMergeButton.setOnClickListener(view -> chooseBulkMergePrimary());
            contactShareButton.setOnClickListener(view -> shareContacts(selectedContacts()));
            contactExportButton.setOnClickListener(view -> exportContacts(selectedContacts()));
            contactDeleteButton.setOnClickListener(
                    view -> confirmDeleteContacts(selectedContacts())
            );
            page.addView(selection, margin(0, 2));
            updateContactSelectionControls();
        } else {
            contactSelectionSummary = null;
            contactMergeButton = null;
            contactShareButton = null;
            contactExportButton = null;
            contactDeleteButton = null;
        }

        EditText search = Ui.input(this, "Search name, email, phone, service…");
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setText(contactSearchQuery);
        search.setSelection(search.length());
        page.addView(search, margin(0, 14));
        CheckBox includeArchived = new CheckBox(this);
        includeArchived.setText("Include archived contacts");
        includeArchived.setTextColor(getColor(R.color.muted));
        includeArchived.setChecked(includeArchivedContacts);
        page.addView(includeArchived, margin(0, 5));

        LinearLayout list = Ui.vertical(this);
        page.addView(list, margin(0, 5));
        Runnable refresh = () -> {
            contactSearchQuery = search.getText().toString();
            includeArchivedContacts = includeArchived.isChecked();
            renderContactList(list);
            updateContactSelectionControls();
        };
        search.addTextChangedListener(new SimpleWatcher(refresh));
        includeArchived.setOnCheckedChangeListener((button, checked) -> refresh.run());
        if (selectVisible != null) {
            selectVisible.setOnClickListener(view -> {
                for (Contact contact : database.getContacts(
                        contactSearchQuery,
                        includeArchivedContacts
                )) {
                    selectedContactIds.add(contact.id);
                }
                renderContactList(list);
                updateContactSelectionControls();
            });
        }
        refresh.run();
        setContent(Ui.scrollPage(this, page));
    }

    private void renderContactList(LinearLayout list) {
        list.removeAllViews();
        List<Contact> contacts = database.getContacts(
                contactSearchQuery,
                includeArchivedContacts
        );
        if (contacts.isEmpty()) {
            list.addView(emptyCard(
                    "No matching contacts",
                    contactSearchQuery.trim().isEmpty()
                            ? "Use + to add the first prospect or client."
                            : "Try a different search."
            ), margin(0, 8));
            return;
        }
        for (Contact contact : contacts) {
            LinearLayout card = contactCard(contact, true);
            if (contactSelectionMode) {
                LinearLayout selectable = Ui.row(this);
                CheckBox selected = new CheckBox(this);
                selected.setChecked(selectedContactIds.contains(contact.id));
                selected.setContentDescription("Select " + contact.displayName());
                selected.setOnCheckedChangeListener((button, checked) -> {
                    if (checked) selectedContactIds.add(contact.id);
                    else selectedContactIds.remove(contact.id);
                    updateContactSelectionControls();
                });
                card.setOnClickListener(view -> selected.toggle());
                selectable.addView(selected, Ui.wrap());
                selectable.addView(card, Ui.weight(1));
                list.addView(selectable, margin(0, 8));
            } else {
                card.setOnClickListener(view -> openContact(contact.id));
                list.addView(card, margin(0, 8));
            }
        }
    }

    private void updateContactSelectionControls() {
        int count = selectedContactIds.size();
        if (contactSelectionSummary != null) {
            contactSelectionSummary.setText(
                    count + (count == 1 ? " contact selected" : " contacts selected")
            );
        }
        if (contactMergeButton != null) contactMergeButton.setEnabled(count >= 2);
        if (contactShareButton != null) contactShareButton.setEnabled(count >= 1);
        if (contactExportButton != null) contactExportButton.setEnabled(count >= 1);
        if (contactDeleteButton != null) contactDeleteButton.setEnabled(count >= 1);
    }

    private void pruneContactSelection() {
        for (Long id : new ArrayList<>(selectedContactIds)) {
            if (id == null || database.getContact(id) == null) selectedContactIds.remove(id);
        }
    }

    private List<Contact> selectedContacts() {
        return database.getContactsByIds(new ArrayList<>(selectedContactIds));
    }

    private LinearLayout contactCard(Contact contact, boolean showContactDetails) {
        LinearLayout card = Ui.card(this);
        LinearLayout top = Ui.row(this);
        TextView name = Ui.body(this, contact.displayName());
        name.setTextSize(16);
        top.addView(name, Ui.weight(1));
        top.addView(Ui.smallLabel(this, contact.stage), Ui.wrap());
        card.addView(top, Ui.match());
        String secondary = firstNonEmpty(
                contact.service,
                joinNonEmpty(contact.email, contact.phone, " · "),
                "No service selected"
        );
        card.addView(Ui.muted(this, secondary), margin(0, 5));
        if (showContactDetails) {
            String detail = Formatters.money(contact.estimatedValue) + " estimated value";
            if (!contact.nextAction.isEmpty()) {
                detail += " · next " + AppDate.formatDate(contact.nextAction);
            }
            if ("Archived".equals(contact.status)) {
                detail += " · archived";
            }
            card.addView(Ui.muted(this, detail), margin(0, 4));
        }
        return card;
    }

    private void openContact(long contactId) {
        contactSelectionMode = false;
        selectedContactIds.clear();
        currentContactId = contactId;
        showScreen(Screen.CONTACT_DETAIL);
    }

    private void showContactDetail(long contactId) {
        Contact contact = database.getContact(contactId);
        if (contact == null) {
            toast("Contact not found.");
            showScreen(Screen.CONTACTS);
            return;
        }
        screenTitle.setText(contact.displayName());
        LinearLayout page = Ui.page(this);
        Button back = Ui.secondaryButton(this, "‹ Back to contacts");
        back.setOnClickListener(view -> showScreen(Screen.CONTACTS));
        page.addView(back, Ui.match());

        LinearLayout summary = Ui.card(this);
        summary.addView(Ui.smallLabel(this, contact.stage + " · " + contact.status), Ui.match());
        summary.addView(Ui.heading(this, contact.displayName()), margin(0, 7));
        addDetail(summary, "Service", blankAsDash(contact.service));
        addDetail(summary, "Email", blankAsDash(contact.email));
        addDetail(summary, "Phone", blankAsDash(contact.phone));
        addDetail(summary, "Assigned representative", blankAsDash(contact.advisor));
        addDetail(summary, "Source", blankAsDash(contact.source));
        addDetail(summary, "Opportunity value", Formatters.money(contact.estimatedValue));
        addDetail(summary, "Next action", AppDate.formatDate(contact.nextAction));
        addDetail(summary, "Contact consent", contact.consent ? "Recorded" : "Not recorded");
        page.addView(summary, margin(0, 14));

        LinearLayout actionOne = Ui.row(this);
        Button edit = Ui.primaryButton(this, "Edit");
        Button note = Ui.secondaryButton(this, "Add note");
        Button task = Ui.secondaryButton(this, "Add task");
        actionOne.addView(edit, weightedMargin(1, 0, 4, 0, 0));
        actionOne.addView(note, weightedMargin(1, 4, 4, 0, 0));
        actionOne.addView(task, weightedMargin(1, 4, 0, 0, 0));
        page.addView(actionOne, margin(0, 10));
        edit.setOnClickListener(view -> showContactDialog(contact));
        note.setOnClickListener(view -> showNoteDialog(contact));
        task.setOnClickListener(view -> showTaskDialog(null, contact.id));

        LinearLayout actionTwo = Ui.row(this);
        Button call = Ui.secondaryButton(this, "Call");
        Button email = Ui.secondaryButton(this, "Email");
        Button archive = Ui.dangerButton(this, "Archive");
        call.setEnabled(!contact.phone.trim().isEmpty());
        email.setEnabled(!contact.email.trim().isEmpty());
        archive.setEnabled(!"Archived".equals(contact.status));
        actionTwo.addView(call, weightedMargin(1, 0, 4, 0, 0));
        actionTwo.addView(email, weightedMargin(1, 4, 4, 0, 0));
        actionTwo.addView(archive, weightedMargin(1, 4, 0, 0, 0));
        page.addView(actionTwo, margin(0, 8));
        call.setOnClickListener(view -> dial(contact.phone));
        email.setOnClickListener(view -> email(contact.email, "CRM follow-up"));
        archive.setOnClickListener(view -> confirmArchive(contact));

        page.addView(Ui.section(this, "Contact management"), margin(0, 22));
        LinearLayout managementOne = Ui.row(this);
        Button merge = Ui.secondaryButton(this, "Merge");
        Button share = Ui.secondaryButton(this, "Share");
        managementOne.addView(merge, weightedMargin(1, 0, 4, 0, 0));
        managementOne.addView(share, weightedMargin(1, 4, 0, 0, 0));
        page.addView(managementOne, margin(0, 8));

        LinearLayout managementTwo = Ui.row(this);
        Button exportVcf = Ui.secondaryButton(this, "Export VCF");
        Button delete = Ui.dangerButton(this, "Delete permanently");
        managementTwo.addView(exportVcf, weightedMargin(1, 0, 4, 0, 0));
        managementTwo.addView(delete, weightedMargin(1, 4, 0, 0, 0));
        page.addView(managementTwo, margin(0, 8));
        merge.setOnClickListener(view -> chooseMergeSources(contact));
        share.setOnClickListener(view -> shareContacts(Arrays.asList(contact)));
        exportVcf.setOnClickListener(view -> exportContacts(Arrays.asList(contact)));
        delete.setOnClickListener(view -> confirmDeleteContacts(Arrays.asList(contact)));

        page.addView(Ui.section(this, "Notes"), margin(0, 24));
        List<NoteItem> notes = database.getNotes(contact.id);
        if (notes.isEmpty()) {
            page.addView(emptyCard("No notes", "Record a meeting note or follow-up context."), margin(0, 8));
        } else {
            for (NoteItem item : notes) {
                LinearLayout noteCard = Ui.card(this);
                noteCard.setClickable(false);
                noteCard.addView(Ui.smallLabel(this, item.category), Ui.match());
                noteCard.addView(Ui.body(this, item.body), margin(0, 5));
                noteCard.addView(Ui.muted(this, readableStamp(item.createdAt)), margin(0, 5));
                page.addView(noteCard, margin(0, 7));
            }
        }

        page.addView(Ui.section(this, "Related tasks"), margin(0, 24));
        List<TaskItem> tasks = database.getTasksForContact(contact.id);
        if (tasks.isEmpty()) {
            page.addView(emptyCard("No related tasks", "Add a follow-up task for this relationship."), margin(0, 8));
        } else {
            for (TaskItem item : tasks) {
                page.addView(taskCard(item, true), margin(0, 7));
            }
        }
        setContent(Ui.scrollPage(this, page));
    }

    private void addDetail(LinearLayout parent, String label, String value) {
        LinearLayout row = Ui.row(this);
        TextView left = Ui.muted(this, label);
        TextView right = Ui.body(this, value);
        right.setGravity(Gravity.END);
        row.addView(left, Ui.weight(1));
        row.addView(right, Ui.weight(1.4f));
        parent.addView(row, margin(0, 8));
    }

    private void showContactDialog(Contact existing) {
        Contact editable = existing == null ? new Contact() : existing.copy();
        LinearLayout form = Ui.page(this);
        form.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 18));
        EditText firstName = Ui.input(this, "First name");
        EditText lastName = Ui.input(this, "Last name");
        EditText household = Ui.input(this, "Household or organization");
        EditText email = Ui.input(this, "name@example.com");
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText phone = Ui.input(this, "(555) 555-5555");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        Spinner stage = Ui.spinner(this, Contact.STAGES);
        Spinner service = Ui.spinner(this, withBlank("Not specified", AppConstants.SERVICES));
        EditText source = Ui.input(this, "Referral, website, event…");
        EditText advisor = Ui.input(this, "Representative or team member");
        EditText assets = Ui.input(this, "$0");
        assets.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText nextAction = dateInput("Next action date", editable.nextAction);
        CheckBox consent = new CheckBox(this);
        consent.setText("Communication consent has been recorded");
        consent.setTextColor(getColor(R.color.ink));

        firstName.setText(editable.firstName);
        lastName.setText(editable.lastName);
        household.setText(editable.household);
        email.setText(editable.email);
        phone.setText(editable.phone);
        Ui.select(stage, editable.stage);
        Ui.select(service, editable.service.isEmpty() ? "Not specified" : editable.service);
        source.setText(editable.source);
        advisor.setText(editable.advisor);
        assets.setText(editable.estimatedValue == 0 ? "" : Formatters.money(editable.estimatedValue));
        consent.setChecked(editable.consent);

        Ui.addField(this, form, "First name", firstName);
        Ui.addField(this, form, "Last name", lastName);
        Ui.addField(this, form, "Household / organization", household);
        Ui.addField(this, form, "Email", email);
        Ui.addField(this, form, "Phone", phone);
        Ui.addField(this, form, "Pipeline stage", stage);
        Ui.addField(this, form, "Primary service", service);
        Ui.addField(this, form, "Lead source", source);
        Ui.addField(this, form, "Assigned representative", advisor);
        Ui.addField(this, form, "Estimated opportunity value", assets);
        Ui.addField(this, form, "Next action", nextAction);
        form.addView(consent, margin(0, 12));

        ScrollView scroll = Ui.scrollPage(this, form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add contact" : "Edit contact")
                .setView(scroll)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    if (firstName.getText().toString().trim().isEmpty()
                            && lastName.getText().toString().trim().isEmpty()
                            && household.getText().toString().trim().isEmpty()) {
                        firstName.setError("Enter a name or household.");
                        return;
                    }
                    String emailValue = email.getText().toString().trim();
                    if (!emailValue.isEmpty() && !android.util.Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) {
                        email.setError("Enter a valid email.");
                        return;
                    }
                    editable.firstName = firstName.getText().toString().trim();
                    editable.lastName = lastName.getText().toString().trim();
                    editable.household = household.getText().toString().trim();
                    editable.email = emailValue;
                    editable.phone = phone.getText().toString().trim();
                    editable.stage = selected(stage);
                    editable.service = valueOrBlank(selected(service), "Not specified");
                    editable.source = source.getText().toString().trim();
                    editable.advisor = advisor.getText().toString().trim();
                    editable.estimatedValue = Formatters.parseMoney(assets.getText().toString());
                    editable.nextAction = nextAction.getText().toString().trim();
                    editable.consent = consent.isChecked();
                    database.saveContact(editable);
                    dialog.dismiss();
                    toast(existing == null ? "Contact added." : "Contact updated.");
                    if (existing != null) {
                        currentContactId = editable.id;
                        currentScreen = Screen.CONTACT_DETAIL;
                    }
                    refreshCurrentScreen();
                }));
        dialog.show();
    }

    private void showNoteDialog(Contact contact) {
        LinearLayout form = Ui.page(this);
        Spinner category = Ui.spinner(this, new String[]{
                "General", "Meeting", "Phone call", "Email", "Planning", "Compliance"
        });
        EditText body = Ui.multiline(this, "Write the note…", 5);
        Ui.addField(this, form, "Category", category);
        Ui.addField(this, form, "Note", body);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Note for " + contact.displayName())
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save note", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String value = body.getText().toString().trim();
                    if (value.isEmpty()) {
                        body.setError("Enter a note.");
                        return;
                    }
                    NoteItem note = new NoteItem();
                    note.contactId = contact.id;
                    note.category = selected(category);
                    note.body = value;
                    database.saveNote(note);
                    dialog.dismiss();
                    refreshCurrentScreen();
                }));
        dialog.show();
    }

    private void confirmArchive(Contact contact) {
        new AlertDialog.Builder(this)
                .setTitle("Archive contact?")
                .setMessage(contact.displayName()
                        + " will leave active lists but remain available through “Include archived.”")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Archive", (dialog, which) -> {
                    database.archiveContact(contact.id);
                    toast("Contact archived.");
                    showScreen(Screen.CONTACTS);
                })
                .show();
    }

    private void chooseBulkMergePrimary() {
        List<Contact> contacts = selectedContacts();
        if (contacts.size() < 2) {
            toast("Select at least two contacts to merge.");
            return;
        }
        CharSequence[] labels = new CharSequence[contacts.size()];
        for (int index = 0; index < contacts.size(); index++) {
            Contact contact = contacts.get(index);
            labels[index] = contact.displayName()
                    + firstNonEmpty(
                    contact.email.isEmpty() ? "" : " — " + contact.email,
                    contact.phone.isEmpty() ? "" : " — " + contact.phone,
                    ""
            );
        }
        int[] selectedPrimary = {0};
        new AlertDialog.Builder(this)
                .setTitle("Choose the primary contact")
                .setMessage("The primary record keeps its populated fields and contact ID.")
                .setSingleChoiceItems(labels, 0, (dialog, which) -> selectedPrimary[0] = which)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", (dialog, which) -> {
                    Contact primary = contacts.get(selectedPrimary[0]);
                    List<Contact> sources = new ArrayList<>(contacts);
                    sources.remove(selectedPrimary[0]);
                    confirmMergeContacts(primary, sources);
                })
                .show();
    }

    private void chooseMergeSources(Contact primary) {
        List<Contact> candidates = database.getContacts("", true);
        for (int index = candidates.size() - 1; index >= 0; index--) {
            if (candidates.get(index).id == primary.id) candidates.remove(index);
        }
        if (candidates.isEmpty()) {
            toast("There are no other contacts to merge.");
            return;
        }
        CharSequence[] labels = new CharSequence[candidates.size()];
        boolean[] checked = new boolean[candidates.size()];
        for (int index = 0; index < candidates.size(); index++) {
            Contact candidate = candidates.get(index);
            labels[index] = candidate.displayName()
                    + firstNonEmpty(
                    candidate.email.isEmpty() ? "" : " — " + candidate.email,
                    candidate.phone.isEmpty() ? "" : " — " + candidate.phone,
                    ""
            );
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Merge into " + primary.displayName())
                .setMessage("Select one or more duplicate records.")
                .setMultiChoiceItems(
                        labels,
                        checked,
                        (ignored, which, value) -> checked[which] = value
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    List<Contact> sources = new ArrayList<>();
                    for (int index = 0; index < candidates.size(); index++) {
                        if (checked[index]) sources.add(candidates.get(index));
                    }
                    if (sources.isEmpty()) {
                        toast("Select at least one contact to merge.");
                        return;
                    }
                    dialog.dismiss();
                    confirmMergeContacts(primary, sources);
                }));
        dialog.show();
    }

    private void confirmMergeContacts(Contact primary, List<Contact> sources) {
        StringBuilder names = new StringBuilder();
        for (int index = 0; index < sources.size() && index < 5; index++) {
            if (names.length() > 0) names.append(", ");
            names.append(sources.get(index).displayName());
        }
        if (sources.size() > 5) names.append(" and ").append(sources.size() - 5).append(" more");
        new AlertDialog.Builder(this)
                .setTitle("Merge selected contacts?")
                .setMessage(
                        "Primary: " + primary.displayName()
                                + "\n\nMerge: " + names
                                + "\n\nThe primary record keeps populated fields. Blank fields are filled, the larger opportunity value is retained, related notes/tasks/consultations are moved, and alternate details are saved in a Merge note. The source contact records are then permanently removed."
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Merge", (dialog, which) -> {
                    List<Long> sourceIds = new ArrayList<>();
                    for (Contact source : sources) sourceIds.add(source.id);
                    try {
                        int count = database.mergeContacts(primary.id, sourceIds);
                        selectedContactIds.clear();
                        contactSelectionMode = false;
                        currentContactId = primary.id;
                        toast(count + (count == 1 ? " contact merged." : " contacts merged."));
                        showScreen(Screen.CONTACT_DETAIL);
                    } catch (RuntimeException exception) {
                        toast("Contacts were not merged: " + messageOf(exception));
                    }
                })
                .show();
    }

    private void confirmDeleteContacts(List<Contact> contacts) {
        if (contacts.isEmpty()) {
            toast("Select at least one contact to delete.");
            return;
        }
        int count = contacts.size();
        String subject = count == 1 ? contacts.get(0).displayName() : count + " selected contacts";
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Delete permanently?")
                .setMessage(
                        subject
                                + " and linked notes and history will be permanently deleted. Related tasks and consultations will be retained but unlinked. This cannot be undone; export a VCF or encrypted backup first if needed."
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete permanently", (ignored, which) -> {
                    List<Long> ids = new ArrayList<>();
                    for (Contact contact : contacts) ids.add(contact.id);
                    try {
                        int deleted = database.deleteContacts(ids);
                        selectedContactIds.clear();
                        contactSelectionMode = false;
                        currentContactId = 0;
                        toast(deleted + (deleted == 1 ? " contact deleted." : " contacts deleted."));
                        showScreen(Screen.CONTACTS);
                    } catch (RuntimeException exception) {
                        toast("Contacts were not deleted: " + messageOf(exception));
                    }
                })
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(getColor(R.color.danger)));
        dialog.show();
    }

    private void shareContacts(List<Contact> contacts) {
        if (contacts.isEmpty()) {
            toast("Select at least one contact to share.");
            return;
        }
        try {
            byte[] bytes = VCardCodec.encode(contacts);
            Uri uri = VCardProvider.createShareUri(this, vCardFileName(contacts), bytes);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/vcard");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.putExtra(
                    Intent.EXTRA_SUBJECT,
                    contacts.size() == 1 ? contacts.get(0).displayName() : "CRM contacts"
            );
            intent.setClipData(ClipData.newRawUri("CRM contacts", uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Share contact VCF"));
        } catch (ActivityNotFoundException exception) {
            toast("No sharing app is available.");
        } catch (Exception exception) {
            toast("Contacts could not be shared: " + messageOf(exception));
        }
    }

    private void exportContacts(List<Contact> contacts) {
        if (contacts.isEmpty()) {
            toast("Select at least one contact to export.");
            return;
        }
        clearBytes(pendingVCardExportBytes);
        pendingVCardExportBytes = VCardCodec.encode(contacts);
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/vcard");
        intent.putExtra(Intent.EXTRA_TITLE, vCardFileName(contacts));
        try {
            startActivityForResult(intent, REQUEST_CREATE_VCARD);
        } catch (ActivityNotFoundException exception) {
            clearBytes(pendingVCardExportBytes);
            pendingVCardExportBytes = null;
            toast("No file-saving app is available.");
        }
    }

    private void writePendingVCard(Uri destination) {
        if (pendingVCardExportBytes == null) {
            toast("The VCF export is no longer available. Try again.");
            return;
        }
        try (OutputStream stream = getContentResolver().openOutputStream(destination, "w")) {
            if (stream == null) {
                throw new IllegalStateException("The selected destination could not be opened.");
            }
            stream.write(pendingVCardExportBytes);
            stream.flush();
            toast("VCF contact file saved.");
        } catch (Exception exception) {
            toast("VCF was not saved: " + messageOf(exception));
        } finally {
            clearBytes(pendingVCardExportBytes);
            pendingVCardExportBytes = null;
        }
    }

    private void chooseVCardFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Some document providers label .vcf files as generic binary data.
        intent.setType("*/*");
        intent.putExtra(
                Intent.EXTRA_MIME_TYPES,
                new String[]{"text/vcard", "text/x-vcard", "text/directory", "application/vcard"}
        );
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(intent, REQUEST_OPEN_VCARD);
        } catch (ActivityNotFoundException exception) {
            toast("No file picker is available.");
        }
    }

    private void loadVCardImport(Intent data) {
        Set<Uri> sources = new LinkedHashSet<>();
        if (data.getData() != null) sources.add(data.getData());
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int index = 0; index < clip.getItemCount(); index++) {
                Uri uri = clip.getItemAt(index).getUri();
                if (uri != null) sources.add(uri);
            }
        }
        if (sources.isEmpty()) {
            toast("No VCF file was selected.");
            return;
        }
        List<VCardCodec.ImportedContact> parsed = new ArrayList<>();
        int failedFiles = 0;
        int totalBytes = 0;
        for (Uri source : sources) {
            try {
                byte[] bytes = readVCardBytes(source, MAX_VCARD_BYTES - totalBytes);
                totalBytes += bytes.length;
                List<VCardCodec.ImportedContact> fromFile = VCardCodec.decode(bytes);
                if (parsed.size() + fromFile.size() > 1000) {
                    throw new IllegalArgumentException(
                            "A maximum of 1000 contacts can be imported at once."
                    );
                }
                parsed.addAll(fromFile);
            } catch (RuntimeException exception) {
                failedFiles++;
            }
        }
        if (parsed.isEmpty()) {
            toast("No readable contacts were found in the selected VCF file(s).");
            return;
        }
        showVCardImportSelection(parsed, failedFiles);
    }

    private byte[] readVCardBytes(Uri source, int remainingLimit) {
        if (remainingLimit <= 0) {
            throw new IllegalArgumentException("The selected VCF files exceed 10 MB.");
        }
        try (InputStream input = getContentResolver().openInputStream(source);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) throw new IllegalStateException("VCF file could not be opened.");
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = input.read(buffer)) != -1) {
                total += count;
                if (total > remainingLimit) {
                    throw new IllegalArgumentException("The selected VCF files exceed 10 MB.");
                }
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        } catch (java.io.IOException exception) {
            throw new IllegalArgumentException("VCF file could not be read.", exception);
        }
    }

    private void showVCardImportSelection(
            List<VCardCodec.ImportedContact> contacts,
            int failedFiles
    ) {
        CharSequence[] labels = new CharSequence[contacts.size()];
        boolean[] checked = new boolean[contacts.size()];
        for (int index = 0; index < contacts.size(); index++) {
            labels[index] = contacts.get(index).label();
        }
        String message = "Manually select the contacts to add. Existing CRM records are not changed.";
        if (failedFiles > 0) {
            message += " " + failedFiles + (failedFiles == 1 ? " file was" : " files were")
                    + " unreadable and skipped.";
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Import VCF contacts")
                .setMessage(message)
                .setMultiChoiceItems(
                        labels,
                        checked,
                        (ignored, which, selected) -> checked[which] = selected
                )
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Select all", null)
                .setPositiveButton("Import selected", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(view -> {
                for (int index = 0; index < checked.length; index++) {
                    checked[index] = true;
                    dialog.getListView().setItemChecked(index, true);
                }
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                List<VCardCodec.ImportedContact> chosen = new ArrayList<>();
                for (int index = 0; index < contacts.size(); index++) {
                    if (checked[index]) chosen.add(contacts.get(index));
                }
                if (chosen.isEmpty()) {
                    toast("Select at least one contact to import.");
                    return;
                }
                int imported = 0;
                int failed = 0;
                for (VCardCodec.ImportedContact entry : chosen) {
                    try {
                        database.importVCardContact(entry.contact, entry.importedNote);
                        imported++;
                    } catch (RuntimeException exception) {
                        failed++;
                    }
                }
                dialog.dismiss();
                String result = imported + (imported == 1 ? " contact imported" : " contacts imported");
                if (failed > 0) result += "; " + failed + " failed";
                toast(result + ".");
                contactSelectionMode = false;
                selectedContactIds.clear();
                showScreen(Screen.CONTACTS);
            });
        });
        dialog.show();
    }

    private String vCardFileName(List<Contact> contacts) {
        if (contacts.size() == 1) {
            String clean = contacts.get(0).displayName()
                    .replaceAll("[^A-Za-z0-9._-]", "-")
                    .replaceAll("-+", "-");
            if (!clean.isEmpty()) return "CRM-" + clean + ".vcf";
        }
        return "CRM-Contacts-"
                + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date())
                + ".vcf";
    }

    private void showPipeline() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Pipeline"), Ui.match());
        page.addView(Ui.body(
                this,
                "Move each opportunity from new lead through client onboarding."
        ), margin(0, 7));
        int total = 0;
        for (int stageIndex = 0; stageIndex < Contact.STAGES.length; stageIndex++) {
            String stage = Contact.STAGES[stageIndex];
            List<Contact> contacts = database.getContactsByStage(stage);
            total += contacts.size();
            LinearLayout header = Ui.row(this);
            header.addView(Ui.section(this, stage), Ui.weight(1));
            header.addView(Ui.smallLabel(this, contacts.size() + " RECORDS"), Ui.wrap());
            page.addView(header, margin(0, stageIndex == 0 ? 18 : 26));

            if (contacts.isEmpty()) {
                page.addView(emptyCard(
                        "No records in " + stage,
                        "Move a contact here when the relationship reaches this step."
                ), margin(0, 8));
                continue;
            }
            for (Contact contact : contacts) {
                LinearLayout card = contactCard(contact, true);
                card.setOnClickListener(view -> openContact(contact.id));
                LinearLayout controls = Ui.row(this);
                Button previous = Ui.secondaryButton(this, "← Back");
                Button next = Ui.primaryButton(
                        this,
                        stageIndex == Contact.STAGES.length - 1 ? "Client ✓" : "Next →"
                );
                previous.setEnabled(stageIndex > 0);
                next.setEnabled(stageIndex < Contact.STAGES.length - 1);
                final int capturedStage = stageIndex;
                previous.setOnClickListener(view -> {
                    database.moveContactStage(contact.id, Contact.STAGES[capturedStage - 1]);
                    showScreen(Screen.PIPELINE);
                });
                next.setOnClickListener(view -> {
                    database.moveContactStage(contact.id, Contact.STAGES[capturedStage + 1]);
                    showScreen(Screen.PIPELINE);
                });
                controls.addView(previous, weightedMargin(1, 0, 5, 0, 0));
                controls.addView(next, weightedMargin(1, 5, 0, 0, 0));
                card.addView(controls, margin(0, 12));
                page.addView(card, margin(0, 8));
            }
        }
        if (total == 0) {
            Button add = Ui.primaryButton(this, "Add first lead");
            add.setOnClickListener(view -> showContactDialog(null));
            page.addView(add, margin(0, 20));
        }
        setContent(Ui.scrollPage(this, page));
    }

    private void showTasks() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Tasks"), Ui.match());
        page.addView(Ui.body(
                this,
                "Track relationship follow-up and the work promised to clients."
        ), margin(0, 7));
        CheckBox openOnly = new CheckBox(this);
        openOnly.setText("Show open tasks only");
        openOnly.setChecked(true);
        openOnly.setTextColor(getColor(R.color.ink));
        page.addView(openOnly, margin(0, 12));
        LinearLayout list = Ui.vertical(this);
        page.addView(list, Ui.match());
        Runnable refresh = () -> renderTaskList(list, openOnly.isChecked());
        openOnly.setOnCheckedChangeListener((button, checked) -> refresh.run());
        refresh.run();
        setContent(Ui.scrollPage(this, page));
    }

    private void renderTaskList(LinearLayout list, boolean openOnly) {
        list.removeAllViews();
        List<TaskItem> tasks = database.getTasks(openOnly);
        if (tasks.isEmpty()) {
            list.addView(emptyCard(
                    openOnly ? "No open tasks" : "No tasks",
                    "Use + to add a follow-up, preparation, or service task."
            ), margin(0, 8));
            return;
        }
        for (TaskItem task : tasks) {
            list.addView(taskCard(task, false), margin(0, 8));
        }
    }

    private LinearLayout taskCard(TaskItem task, boolean compact) {
        LinearLayout card = Ui.card(this);
        LinearLayout top = Ui.row(this);
        CheckBox complete = new CheckBox(this);
        complete.setChecked("Complete".equals(task.status));
        complete.setContentDescription("Mark task complete");
        top.addView(complete, new LinearLayout.LayoutParams(
                Ui.dp(this, 42),
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        LinearLayout text = Ui.vertical(this);
        TextView title = Ui.body(this, task.title);
        if ("Complete".equals(task.status)) {
            title.setAlpha(0.55f);
        }
        text.addView(title, Ui.match());
        String due = task.dueDate.isEmpty() ? "No due date" : AppDate.formatDate(task.dueDate);
        String metadata = task.priority + " · " + due;
        if (AppDate.isPastDate(task.dueDate) && !"Complete".equals(task.status)) {
            metadata += " · OVERDUE";
        }
        text.addView(Ui.muted(this, metadata), margin(0, 4));
        top.addView(text, Ui.weight(1));
        card.addView(top, Ui.match());
        Contact related = task.contactId > 0 ? database.getContact(task.contactId) : null;
        if (related != null) {
            card.addView(Ui.smallLabel(this, related.displayName()), margin(0, 9));
        }
        if (!task.assignee.isEmpty()) {
            card.addView(Ui.muted(this, "Assigned to " + task.assignee), margin(0, 5));
        }
        if (!compact && !task.details.isEmpty()) {
            card.addView(Ui.body(this, task.details), margin(0, 8));
        }
        complete.setOnCheckedChangeListener((button, checked) -> {
            if (button.isPressed()) {
                database.setTaskComplete(task.id, checked);
                refreshCurrentScreen();
            }
        });
        card.setOnClickListener(view -> showTaskDialog(task, task.contactId));
        return card;
    }

    private void showTaskDialog(TaskItem existing, long preselectedContactId) {
        TaskItem editable = existing == null ? new TaskItem() : copyTask(existing);
        LinearLayout form = Ui.page(this);
        EditText title = Ui.input(this, "Task title");
        Spinner contact = contactSpinner(
                this,
                existing == null ? preselectedContactId : editable.contactId
        );
        EditText dueDate = dateInput("Due date", editable.dueDate);
        Spinner priority = Ui.spinner(this, TaskItem.PRIORITIES);
        EditText assignee = Ui.input(this, "Representative or team member");
        EditText details = Ui.multiline(this, "Details and completion criteria…", 4);
        title.setText(editable.title);
        Ui.select(priority, editable.priority);
        assignee.setText(editable.assignee);
        details.setText(editable.details);
        Ui.addField(this, form, "Task", title);
        Ui.addField(this, form, "Related contact", contact);
        Ui.addField(this, form, "Due date", dueDate);
        Ui.addField(this, form, "Priority", priority);
        Ui.addField(this, form, "Assignee", assignee);
        Ui.addField(this, form, "Details", details);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add task" : "Edit task")
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String value = title.getText().toString().trim();
                    if (value.isEmpty()) {
                        title.setError("Enter a task title.");
                        return;
                    }
                    editable.title = value;
                    editable.contactId = selectedContactId(contact);
                    editable.dueDate = dueDate.getText().toString().trim();
                    editable.priority = selected(priority);
                    editable.assignee = assignee.getText().toString().trim();
                    editable.details = details.getText().toString().trim();
                    database.saveTask(editable);
                    dialog.dismiss();
                    toast(existing == null ? "Task added." : "Task updated.");
                    refreshCurrentScreen();
                }));
        dialog.show();
    }

    private void showAppointments() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Consultations"), Ui.match());
        page.addView(Ui.body(
                this,
                "Schedule consultation requests and send a copy to the device calendar when desired."
        ), margin(0, 7));
        CheckBox includePast = new CheckBox(this);
        includePast.setText("Include past and cancelled consultations");
        includePast.setTextColor(getColor(R.color.ink));
        page.addView(includePast, margin(0, 12));
        LinearLayout list = Ui.vertical(this);
        page.addView(list, Ui.match());
        Runnable refresh = () -> renderAppointments(list, !includePast.isChecked());
        includePast.setOnCheckedChangeListener((button, checked) -> refresh.run());
        refresh.run();
        setContent(Ui.scrollPage(this, page));
    }

    private void renderAppointments(LinearLayout list, boolean upcomingOnly) {
        list.removeAllViews();
        List<Appointment> appointments = database.getAppointments(upcomingOnly);
        if (appointments.isEmpty()) {
            list.addView(emptyCard(
                    upcomingOnly ? "No upcoming consultations" : "No consultations",
                    "Use + to create an appointment request."
            ), margin(0, 8));
            return;
        }
        for (Appointment appointment : appointments) {
            LinearLayout card = Ui.card(this);
            LinearLayout top = Ui.row(this);
            TextView title = Ui.body(this, appointment.title);
            top.addView(title, Ui.weight(1));
            top.addView(Ui.smallLabel(this, appointment.status), Ui.wrap());
            card.addView(top, Ui.match());
            card.addView(
                    Ui.muted(
                            this,
                            AppDate.formatDateTime(appointment.startTime)
                                    + " · " + appointment.durationMinutes + " min"
                    ),
                    margin(0, 6)
            );
            Contact contact = appointment.contactId > 0
                    ? database.getContact(appointment.contactId)
                    : null;
            card.addView(
                    Ui.muted(
                            this,
                            (contact == null ? "No linked contact" : contact.displayName())
                                    + " · " + appointment.meetingType
                    ),
                    margin(0, 4)
            );
            if (!appointment.details.isEmpty()) {
                card.addView(Ui.body(this, appointment.details), margin(0, 8));
            }
            LinearLayout actions = Ui.row(this);
            Button edit = Ui.secondaryButton(this, "Edit");
            Button calendar = Ui.primaryButton(this, "Add to calendar");
            actions.addView(edit, weightedMargin(1, 0, 5, 0, 0));
            actions.addView(calendar, weightedMargin(1.5f, 5, 0, 0, 0));
            card.addView(actions, margin(0, 12));
            edit.setOnClickListener(view -> showAppointmentDialog(appointment));
            calendar.setOnClickListener(view -> sendToCalendar(appointment));
            list.addView(card, margin(0, 8));
        }
    }

    private void showAppointmentDialog(Appointment existing) {
        Appointment editable = existing == null ? new Appointment() : copyAppointment(existing);
        if (editable.startTime <= 0) {
            Calendar defaultTime = Calendar.getInstance();
            defaultTime.add(Calendar.DAY_OF_MONTH, 1);
            defaultTime.set(Calendar.HOUR_OF_DAY, 10);
            defaultTime.set(Calendar.MINUTE, 0);
            defaultTime.set(Calendar.SECOND, 0);
            editable.startTime = defaultTime.getTimeInMillis();
        }
        LinearLayout form = Ui.page(this);
        EditText title = Ui.input(this, "Consultation title");
        Spinner contact = contactSpinner(this, editable.contactId);
        EditText starts = Ui.input(this, "Date and time");
        starts.setFocusable(false);
        starts.setClickable(true);
        final long[] selectedStart = {editable.startTime};
        starts.setText(AppDate.formatDateTime(selectedStart[0]));
        starts.setOnClickListener(view -> pickDateTime(starts, selectedStart));
        EditText duration = Ui.input(this, "60");
        duration.setInputType(InputType.TYPE_CLASS_NUMBER);
        Spinner meetingType = Ui.spinner(this, AppConstants.MEETING_TYPES);
        Spinner status = Ui.spinner(this, AppConstants.APPOINTMENT_STATUSES);
        EditText details = Ui.multiline(this, "Agenda, location, or preparation notes…", 4);
        title.setText(editable.title);
        duration.setText(String.valueOf(editable.durationMinutes));
        Ui.select(meetingType, editable.meetingType);
        Ui.select(status, editable.status);
        details.setText(editable.details);

        Ui.addField(this, form, "Title", title);
        Ui.addField(this, form, "Related contact", contact);
        Ui.addField(this, form, "Starts", starts);
        Ui.addField(this, form, "Duration in minutes", duration);
        Ui.addField(this, form, "Meeting type", meetingType);
        Ui.addField(this, form, "Status", status);
        Ui.addField(this, form, "Details", details);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Book consultation" : "Edit consultation")
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String value = title.getText().toString().trim();
                    if (value.isEmpty()) {
                        title.setError("Enter a title.");
                        return;
                    }
                    int minutes;
                    try {
                        minutes = Integer.parseInt(duration.getText().toString().trim());
                    } catch (NumberFormatException exception) {
                        duration.setError("Enter minutes.");
                        return;
                    }
                    if (minutes < 15 || minutes > 480) {
                        duration.setError("Use 15 to 480 minutes.");
                        return;
                    }
                    editable.title = value;
                    editable.contactId = selectedContactId(contact);
                    editable.startTime = selectedStart[0];
                    editable.durationMinutes = minutes;
                    editable.meetingType = selected(meetingType);
                    editable.status = selected(status);
                    editable.details = details.getText().toString().trim();
                    database.saveAppointment(editable);
                    dialog.dismiss();
                    toast(existing == null ? "Consultation created." : "Consultation updated.");
                    refreshCurrentScreen();
                }));
        dialog.show();
    }

    private void sendToCalendar(Appointment appointment) {
        Intent intent = new Intent(Intent.ACTION_INSERT);
        intent.setData(CalendarContract.Events.CONTENT_URI);
        intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, appointment.startTime);
        intent.putExtra(
                CalendarContract.EXTRA_EVENT_END_TIME,
                appointment.startTime + appointment.durationMinutes * 60_000L
        );
        intent.putExtra(CalendarContract.Events.TITLE, appointment.title);
        StringBuilder description = new StringBuilder(appointment.details);
        Contact contact = appointment.contactId > 0
                ? database.getContact(appointment.contactId)
                : null;
        if (contact != null) {
            if (description.length() > 0) {
                description.append("\n\n");
            }
            description.append("CRM contact: ").append(contact.displayName());
        }
        intent.putExtra(CalendarContract.Events.DESCRIPTION, description.toString());
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException exception) {
            toast("No calendar app is available.");
        }
    }

    private void showInquiries() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Inquiries"), Ui.match());
        page.addView(Ui.body(
                this,
                "Capture consultation requests from contact forms, calls, referrals, and live chat."
        ), margin(0, 7));
        page.addView(
                Ui.smallLabel(this, database.countNewInquiries() + " NEW INQUIRIES"),
                margin(0, 14)
        );
        List<Inquiry> inquiries = database.getInquiries();
        if (inquiries.isEmpty()) {
            page.addView(emptyCard(
                    "No inquiries",
                    "Use + to enter a request manually. A future backend can sync website and live-chat submissions here."
            ), margin(0, 10));
        } else {
            for (Inquiry inquiry : inquiries) {
                LinearLayout card = Ui.card(this);
                LinearLayout top = Ui.row(this);
                top.addView(Ui.body(this, blankAsDash(inquiry.name)), Ui.weight(1));
                top.addView(Ui.smallLabel(this, inquiry.status), Ui.wrap());
                card.addView(top, Ui.match());
                card.addView(
                        Ui.muted(
                                this,
                                inquiry.type + " · " + firstNonEmpty(inquiry.service, "No service")
                        ),
                        margin(0, 6)
                );
                card.addView(
                        Ui.muted(
                                this,
                                joinNonEmpty(inquiry.email, inquiry.phone, " · ")
                        ),
                        margin(0, 4)
                );
                if (!inquiry.message.isEmpty()) {
                    card.addView(Ui.body(this, inquiry.message), margin(0, 9));
                }
                card.addView(
                        Ui.muted(this, AppDate.formatDateTime(inquiry.receivedAt)),
                        margin(0, 7)
                );
                LinearLayout actions = Ui.row(this);
                Button edit = Ui.secondaryButton(this, "Edit");
                Button status = Ui.secondaryButton(this, "Status");
                Button convert = Ui.primaryButton(this, "Convert");
                convert.setEnabled(!"Converted".equals(inquiry.status));
                actions.addView(edit, weightedMargin(1, 0, 4, 0, 0));
                actions.addView(status, weightedMargin(1, 4, 4, 0, 0));
                actions.addView(convert, weightedMargin(1, 4, 0, 0, 0));
                card.addView(actions, margin(0, 12));
                edit.setOnClickListener(view -> showInquiryDialog(inquiry));
                status.setOnClickListener(view -> showInquiryStatusDialog(inquiry));
                convert.setOnClickListener(view -> convertInquiry(inquiry));
                page.addView(card, margin(0, 8));
            }
        }
        setContent(Ui.scrollPage(this, page));
    }

    private void showInquiryDialog(Inquiry existing) {
        Inquiry editable = existing == null ? new Inquiry() : copyInquiry(existing);
        LinearLayout form = Ui.page(this);
        EditText name = Ui.input(this, "Name or household");
        EditText email = Ui.input(this, "name@example.com");
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText phone = Ui.input(this, "(555) 555-5555");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        Spinner type = Ui.spinner(this, AppConstants.INQUIRY_TYPES);
        Spinner service = Ui.spinner(this, withBlank("Not specified", AppConstants.SERVICES));
        Spinner status = Ui.spinner(this, AppConstants.INQUIRY_STATUSES);
        EditText message = Ui.multiline(this, "What is the prospect looking for?", 5);
        CheckBox consent = new CheckBox(this);
        consent.setText("Communication consent has been recorded");
        consent.setTextColor(getColor(R.color.ink));
        name.setText(editable.name);
        email.setText(editable.email);
        phone.setText(editable.phone);
        Ui.select(type, editable.type);
        Ui.select(service, editable.service.isEmpty() ? "Not specified" : editable.service);
        Ui.select(status, editable.status);
        message.setText(editable.message);
        consent.setChecked(editable.consent);

        Ui.addField(this, form, "Name", name);
        Ui.addField(this, form, "Email", email);
        Ui.addField(this, form, "Phone", phone);
        Ui.addField(this, form, "Source", type);
        Ui.addField(this, form, "Service interest", service);
        Ui.addField(this, form, "Status", status);
        Ui.addField(this, form, "Message", message);
        form.addView(consent, margin(0, 12));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add inquiry" : "Edit inquiry")
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String nameValue = name.getText().toString().trim();
                    if (nameValue.isEmpty()) {
                        name.setError("Enter a name.");
                        return;
                    }
                    String emailValue = email.getText().toString().trim();
                    if (!emailValue.isEmpty() && !android.util.Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) {
                        email.setError("Enter a valid email.");
                        return;
                    }
                    editable.name = nameValue;
                    editable.email = emailValue;
                    editable.phone = phone.getText().toString().trim();
                    editable.type = selected(type);
                    editable.service = valueOrBlank(selected(service), "Not specified");
                    editable.status = selected(status);
                    editable.message = message.getText().toString().trim();
                    editable.consent = consent.isChecked();
                    database.saveInquiry(editable);
                    dialog.dismiss();
                    toast(existing == null ? "Inquiry added." : "Inquiry updated.");
                    refreshCurrentScreen();
                }));
        dialog.show();
    }

    private void showInquiryStatusDialog(Inquiry inquiry) {
        final int[] selectedIndex = {
                indexOf(AppConstants.INQUIRY_STATUSES, inquiry.status)
        };
        new AlertDialog.Builder(this)
                .setTitle("Inquiry status")
                .setSingleChoiceItems(
                        AppConstants.INQUIRY_STATUSES,
                        selectedIndex[0],
                        (dialog, which) -> selectedIndex[0] = which
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Update", (dialog, which) -> {
                    database.setInquiryStatus(
                            inquiry.id,
                            AppConstants.INQUIRY_STATUSES[selectedIndex[0]]
                    );
                    showScreen(Screen.INQUIRIES);
                })
                .show();
    }

    private void convertInquiry(Inquiry inquiry) {
        new AlertDialog.Builder(this)
                .setTitle("Convert to contact?")
                .setMessage("A new lead will be created from this inquiry. The inquiry will remain in the audit trail.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Convert", (dialog, which) -> {
                    Contact contact = new Contact();
                    String[] nameParts = inquiry.name.trim().split("\\s+", 2);
                    contact.firstName = nameParts.length > 0 ? nameParts[0] : "";
                    contact.lastName = nameParts.length > 1 ? nameParts[1] : "";
                    contact.email = inquiry.email;
                    contact.phone = inquiry.phone;
                    contact.service = inquiry.service;
                    contact.source = inquiry.type;
                    contact.stage = Contact.STAGES[0];
                    contact.consent = inquiry.consent;
                    database.saveContact(contact);
                    database.setInquiryStatus(inquiry.id, "Converted");
                    toast("Inquiry converted to a new lead.");
                    currentContactId = contact.id;
                    showScreen(Screen.CONTACT_DETAIL);
                })
                .show();
    }

    private void showMore() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Settings & tools"), Ui.match());
        page.addView(Ui.body(
                this,
                "Manage consultations, inquiries, backups, local security, developer contact details, and licensing."
        ), margin(0, 7));
        page.addView(
                menuCard(
                        "Company & booking",
                        "Developer contact",
                        "Open the developer’s contact information, website, and Cal.com scheduling.",
                        () -> showScreen(Screen.COMPANY)
                ),
                margin(0, 16)
        );
        page.addView(
                menuCard(
                        "Consultations",
                        database.countUpcomingAppointments() + " upcoming",
                        "Schedule requests and add them to the device calendar.",
                        () -> showScreen(Screen.APPOINTMENTS)
                ),
                margin(0, 9)
        );
        page.addView(
                menuCard(
                        "Inquiries",
                        database.countNewInquiries() + " new",
                        "Capture contact-form, live-chat, phone, email, and referral leads.",
                        () -> showScreen(Screen.INQUIRIES)
                ),
                margin(0, 9)
        );
        page.addView(
                menuCard(
                        "Encrypted backup",
                        "Local export / restore",
                        "Create a passphrase-protected CRM data backup without storage permissions.",
                        () -> showScreen(Screen.BACKUP)
                ),
                margin(0, 9)
        );
        page.addView(
                menuCard(
                        "Settings & security",
                        "PIN · auto-lock · license",
                        "Configure local access and manage demonstration or stored data.",
                        () -> showScreen(Screen.SETTINGS)
                ),
                margin(0, 9)
        );
        LinearLayout notice = Ui.card(this);
        notice.setClickable(false);
        notice.addView(Ui.smallLabel(this, "IMPLEMENTATION BOUNDARY"), Ui.match());
        notice.addView(
                Ui.body(
                        this,
                        "This edition is a single-device native CRM. Live website/chat sync, staff accounts, supervisory retention, and organization-wide reporting require an approved backend."
                ),
                margin(0, 7)
        );
        page.addView(notice, margin(0, 22));
        setContent(Ui.scrollPage(this, page));
    }

    private void showCompany() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Company & Booking"), Ui.match());
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.maclean_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription(AppConstants.COMPANY_NAME);
        page.addView(logo, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 160)
        ));

        LinearLayout contactCard = Ui.card(this);
        contactCard.setClickable(false);
        contactCard.addView(Ui.smallLabel(this, "COMPANY CONTACT"), Ui.match());
        contactCard.addView(Ui.section(this, AppConstants.COMPANY_NAME), margin(0, 8));
        addDetail(contactCard, "Phone", AppConstants.PHONE);
        addDetail(contactCard, "Email", AppConstants.EMAIL);
        addDetail(contactCard, "Website", "macleanofduartenterprises.com");
        page.addView(contactCard, margin(0, 14));

        Button call = Ui.primaryButton(this, "Call " + AppConstants.PHONE);
        call.setOnClickListener(view -> dial(AppConstants.PHONE));
        page.addView(call, margin(0, 10));

        Button email = Ui.secondaryButton(this, "Email the office");
        email.setOnClickListener(view -> email(
                AppConstants.EMAIL,
                "Service request for Maclean Of Duart Enterprises"
        ));
        page.addView(email, margin(0, 9));

        Button website = Ui.secondaryButton(this, "Open company website");
        website.setOnClickListener(view -> openUrl(AppConstants.WEBSITE));
        page.addView(website, margin(0, 9));

        Button schedule = Ui.primaryButton(this, "Schedule with Cal.com");
        schedule.setOnClickListener(view -> openUrl(AppConstants.SCHEDULING_URL));
        page.addView(schedule, margin(0, 9));

        LinearLayout tartanNote = Ui.card(this);
        tartanNote.setClickable(false);
        tartanNote.addView(Ui.smallLabel(this, "VIRTUE · MINE · HONOUR"), Ui.match());
        tartanNote.addView(
                Ui.body(
                        this,
                        "A Maclean Of Duart branded workspace for dependable technology service, careful follow-up, and responsible stewardship of customer information."
                ),
                margin(0, 7)
        );
        page.addView(tartanNote, margin(0, 18));
        setContent(Ui.scrollPage(this, page));
    }

    private void showLicense() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "License"), Ui.match());
        page.addView(Ui.smallLabel(this, "GNU AGPLv3 · OFFLINE COPY"), margin(0, 8));

        LinearLayout notice = Ui.card(this);
        notice.setClickable(false);
        notice.setFocusable(false);
        notice.addView(
                Ui.body(
                        this,
                        "CRM version 1.1.0 — A client relations management application"
                ),
                Ui.match()
        );
        notice.addView(
                Ui.muted(
                        this,
                        "Copyright © 2026 Maclean Of Duart Enterprises. This application is licensed under the GNU Affero General Public License, version 3. The corresponding source code is included with this distribution."
                ),
                margin(0, 8)
        );
        page.addView(notice, margin(0, 12));

        LinearLayout licenseCard = Ui.card(this);
        licenseCard.setClickable(false);
        licenseCard.setFocusable(false);
        TextView licenseText = Ui.body(this, readRawResource(R.raw.agpl_3_0));
        licenseText.setTypeface(Typeface.MONOSPACE);
        licenseText.setTextSize(12);
        licenseText.setTextIsSelectable(true);
        licenseText.setLineSpacing(0, 1.12f);
        licenseCard.addView(licenseText, Ui.match());
        page.addView(licenseCard, margin(0, 10));
        setContent(Ui.scrollPage(this, page));
    }

    private LinearLayout menuCard(
            String title,
            String badge,
            String description,
            Runnable action
    ) {
        LinearLayout card = Ui.card(this);
        LinearLayout top = Ui.row(this);
        top.addView(Ui.section(this, title), Ui.weight(1));
        top.addView(Ui.smallLabel(this, badge), Ui.wrap());
        card.addView(top, Ui.match());
        card.addView(Ui.muted(this, description), margin(0, 7));
        card.setOnClickListener(view -> action.run());
        return card;
    }

    private void showBackup() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Backup & Restore"), Ui.match());
        page.addView(Ui.body(
                this,
                "Export all local CRM records into one AES-256-GCM encrypted file. The passphrase is never stored by the app."
        ), margin(0, 7));
        LinearLayout exportCard = Ui.card(this);
        exportCard.setClickable(false);
        exportCard.addView(Ui.section(this, "Create encrypted backup"), Ui.match());
        exportCard.addView(
                Ui.muted(
                        this,
                        "Choose a unique passphrase of at least 10 characters, then save the .tcrm file somewhere controlled by your organization."
                ),
                margin(0, 7)
        );
        Button export = Ui.primaryButton(this, "Export encrypted backup");
        export.setOnClickListener(view -> requestBackupPassphrase());
        exportCard.addView(export, margin(0, 14));
        page.addView(exportCard, margin(0, 16));

        LinearLayout importCard = Ui.card(this);
        importCard.setClickable(false);
        importCard.addView(Ui.section(this, "Restore encrypted backup"), Ui.match());
        importCard.addView(
                Ui.muted(
                        this,
                        "Restore replaces every record currently stored on this device. Export the current CRM first if it may be needed."
                ),
                margin(0, 7)
        );
        Button restore = Ui.secondaryButton(this, "Choose backup to restore");
        restore.setOnClickListener(view -> chooseBackupFile());
        importCard.addView(restore, margin(0, 14));
        page.addView(importCard, margin(0, 10));

        LinearLayout warning = Ui.card(this);
        warning.setClickable(false);
        warning.addView(Ui.smallLabel(this, "KEEP THE PASSPHRASE SEPARATE"), Ui.match());
        warning.addView(
                Ui.body(
                        this,
                        "A forgotten passphrase cannot be recovered. Test restore procedures with non-client data before production use."
                ),
                margin(0, 7)
        );
        page.addView(warning, margin(0, 18));
        setContent(Ui.scrollPage(this, page));
    }

    private void requestBackupPassphrase() {
        LinearLayout form = Ui.page(this);
        EditText passphrase = passwordInput("At least 10 characters");
        EditText confirmation = passwordInput("Repeat passphrase");
        Ui.addField(this, form, "Backup passphrase", passphrase);
        Ui.addField(this, form, "Confirm passphrase", confirmation);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Protect backup")
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    char[] first = passphrase.getText().toString().toCharArray();
                    char[] second = confirmation.getText().toString().toCharArray();
                    try {
                        if (first.length < 10) {
                            passphrase.setError("Use at least 10 characters.");
                            return;
                        }
                        if (!Arrays.equals(first, second)) {
                            confirmation.setError("Passphrases do not match.");
                            return;
                        }
                        clearBytes(pendingExportBytes);
                        pendingExportBytes = BackupCodec.encrypt(database.exportJson(), first);
                        dialog.dismiss();
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/octet-stream");
                        intent.putExtra(
                                Intent.EXTRA_TITLE,
                                "CRM-Backup-"
                                        + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date())
                                        + ".tcrm"
                        );
                        startActivityForResult(intent, REQUEST_CREATE_BACKUP);
                    } catch (RuntimeException exception) {
                        toast(messageOf(exception));
                    } finally {
                        Arrays.fill(first, '\0');
                        Arrays.fill(second, '\0');
                    }
                }));
        dialog.show();
    }

    private void writePendingBackup(Uri destination) {
        if (pendingExportBytes == null) {
            toast("The backup is no longer available. Try exporting again.");
            return;
        }
        try (OutputStream stream = getContentResolver().openOutputStream(destination, "w")) {
            if (stream == null) {
                throw new IllegalStateException("The selected destination could not be opened.");
            }
            stream.write(pendingExportBytes);
            stream.flush();
            toast("Encrypted backup saved.");
        } catch (Exception exception) {
            toast("Backup was not saved: " + messageOf(exception));
        } finally {
            clearBytes(pendingExportBytes);
            pendingExportBytes = null;
        }
    }

    private void chooseBackupFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_OPEN_BACKUP);
    }

    private void loadBackupForImport(Uri source) {
        try (InputStream input = getContentResolver().openInputStream(source);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) {
                throw new IllegalStateException("The selected backup could not be opened.");
            }
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = input.read(buffer)) != -1) {
                total += count;
                if (total > MAX_BACKUP_BYTES) {
                    throw new IllegalArgumentException("The selected file is too large.");
                }
                output.write(buffer, 0, count);
            }
            clearBytes(pendingImportBytes);
            pendingImportBytes = output.toByteArray();
            requestImportPassphrase();
        } catch (Exception exception) {
            clearBytes(pendingImportBytes);
            pendingImportBytes = null;
            toast("Backup could not be read: " + messageOf(exception));
        }
    }

    private void requestImportPassphrase() {
        EditText passphrase = passwordInput("Backup passphrase");
        LinearLayout form = Ui.page(this);
        Ui.addField(this, form, "Passphrase", passphrase);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Open encrypted backup")
                .setMessage("The file will be verified before any current data is changed.")
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", (ignored, which) -> {
                    clearBytes(pendingImportBytes);
                    pendingImportBytes = null;
                })
                .setPositiveButton("Verify", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    char[] secret = passphrase.getText().toString().toCharArray();
                    try {
                        JSONObject restored = BackupCodec.decrypt(pendingImportBytes, secret);
                        dialog.dismiss();
                        confirmRestore(restored);
                    } catch (RuntimeException exception) {
                        passphrase.setError(messageOf(exception));
                    } finally {
                        Arrays.fill(secret, '\0');
                    }
                }));
        dialog.setOnCancelListener(ignored -> {
            clearBytes(pendingImportBytes);
            pendingImportBytes = null;
        });
        dialog.show();
    }

    private void confirmRestore(JSONObject restored) {
        int contacts = restored.optJSONArray("contacts") == null
                ? 0
                : restored.optJSONArray("contacts").length();
        new AlertDialog.Builder(this)
                .setTitle("Replace current CRM data?")
                .setMessage(
                        "Verified backup contains " + contacts
                                + " contacts. Restoring replaces all current contacts, notes, tasks, consultations, inquiries, and activity."
                )
                .setNegativeButton("Cancel", (dialog, which) -> {
                    clearBytes(pendingImportBytes);
                    pendingImportBytes = null;
                })
                .setPositiveButton("Restore", (dialog, which) -> {
                    try {
                        database.importJson(restored);
                        toast("CRM backup restored.");
                        showScreen(Screen.DASHBOARD);
                    } catch (RuntimeException exception) {
                        toast("Restore failed: " + messageOf(exception));
                    } finally {
                        clearBytes(pendingImportBytes);
                        pendingImportBytes = null;
                    }
                })
                .setOnCancelListener(dialog -> {
                    clearBytes(pendingImportBytes);
                    pendingImportBytes = null;
                })
                .show();
    }

    private void showSettings() {
        LinearLayout page = Ui.page(this);
        page.addView(Ui.heading(this, "Settings"), Ui.match());

        LinearLayout developerCard = Ui.card(this);
        developerCard.setClickable(false);
        developerCard.addView(Ui.section(this, "Developer & license"), Ui.match());
        developerCard.addView(
                Ui.muted(
                        this,
                        "Open the developer’s Company & Booking page or read the complete offline GNU AGPLv3 license."
                ),
                margin(0, 7)
        );
        Button companyBooking = Ui.secondaryButton(this, "Company & Booking");
        companyBooking.setOnClickListener(view -> showScreen(Screen.COMPANY));
        developerCard.addView(companyBooking, margin(0, 14));
        Button license = Ui.primaryButton(this, "License");
        license.setOnClickListener(view -> showScreen(Screen.LICENSE));
        developerCard.addView(license, margin(0, 9));
        page.addView(developerCard, margin(0, 12));

        LinearLayout workspaceCard = Ui.card(this);
        workspaceCard.setClickable(false);
        workspaceCard.addView(Ui.section(this, "Workspace"), Ui.match());
        Spinner autoLock = Ui.spinner(this, new String[]{
                "1 minute", "5 minutes", "15 minutes", "30 minutes"
        });
        int currentMinutes = settings.getInt("auto_lock_minutes", 5);
        Ui.select(autoLock, currentMinutes + (currentMinutes == 1 ? " minute" : " minutes"));
        Ui.addField(this, workspaceCard, "Auto-lock after inactivity", autoLock);
        Button save = Ui.primaryButton(this, "Save workspace setting");
        workspaceCard.addView(save, margin(0, 14));
        save.setOnClickListener(view -> {
            int minutes = parseLeadingInt(selected(autoLock), 5);
            settings.edit()
                    .putInt("auto_lock_minutes", minutes)
                    .apply();
            toast("Settings saved.");
        });
        page.addView(workspaceCard, margin(0, 2));

        LinearLayout accessCard = Ui.card(this);
        accessCard.setClickable(false);
        accessCard.addView(Ui.section(this, "Local access"), Ui.match());
        accessCard.addView(
                Ui.muted(
                        this,
                        "The app PIN gates this local workspace. Five failed attempts trigger a short lockout."
                ),
                margin(0, 7)
        );
        Button changePin = Ui.secondaryButton(this, "Change six-digit PIN");
        changePin.setOnClickListener(view -> showChangePinDialog());
        accessCard.addView(changePin, margin(0, 14));
        page.addView(accessCard, margin(0, 12));

        LinearLayout demoCard = Ui.card(this);
        demoCard.setClickable(false);
        demoCard.addView(Ui.section(this, "Demonstration data"), Ui.match());
        demoCard.addView(
                Ui.muted(
                        this,
                        "Add clearly fictitious records to explore the workflow. This works only while the CRM has no contacts."
                ),
                margin(0, 7)
        );
        Button sample = Ui.secondaryButton(this, "Add fictitious sample records");
        sample.setOnClickListener(view -> confirmSampleData());
        demoCard.addView(sample, margin(0, 14));
        page.addView(demoCard, margin(0, 12));

        LinearLayout dangerCard = Ui.card(this);
        dangerCard.setClickable(false);
        dangerCard.addView(Ui.section(this, "Erase local CRM"), Ui.match());
        dangerCard.addView(
                Ui.muted(
                        this,
                        "Permanently removes every record, the local encryption key, settings, and app PIN from this device."
                ),
                margin(0, 7)
        );
        Button wipe = Ui.dangerButton(this, "Erase all local CRM data");
        wipe.setOnClickListener(view -> showWipeDialog());
        dangerCard.addView(wipe, margin(0, 14));
        page.addView(dangerCard, margin(0, 12));

        LinearLayout security = Ui.card(this);
        security.setClickable(false);
        security.addView(Ui.smallLabel(this, "SECURITY NOTES"), Ui.match());
        security.addView(
                Ui.body(
                        this,
                        "Sensitive database fields use an AES key held by Android Keystore. Screenshots and screen recording are permitted. Android backup is disabled. No Internet permission is requested."
                ),
                margin(0, 7)
        );
        security.addView(
                Ui.muted(
                        this,
                        "Before real customer use, the organization must review device management, access control, record retention, backups, incident response, privacy, and applicable business obligations."
                ),
                margin(0, 8)
        );
        page.addView(security, margin(0, 8));
        setContent(Ui.scrollPage(this, page));
    }

    private void showChangePinDialog() {
        LinearLayout form = Ui.page(this);
        EditText current = pinInput("Current PIN");
        EditText replacement = pinInput("New six-digit PIN");
        EditText confirmation = pinInput("Repeat new PIN");
        Ui.addField(this, form, "Current PIN", current);
        Ui.addField(this, form, "New PIN", replacement);
        Ui.addField(this, form, "Confirm new PIN", confirmation);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Change CRM PIN")
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Change PIN", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    char[] oldPin = current.getText().toString().toCharArray();
                    char[] newPin = replacement.getText().toString().toCharArray();
                    char[] repeated = confirmation.getText().toString().toCharArray();
                    try {
                        PinManager pinManager = new PinManager(this);
                        if (!pinManager.verify(oldPin)) {
                            current.setText("");
                            current.setError(
                                    pinManager.isLockedOut()
                                            ? "Too many attempts. Lock the app and try again later."
                                            : "Current PIN is incorrect."
                            );
                            return;
                        }
                        if (!Arrays.equals(newPin, repeated)) {
                            confirmation.setError("PINs do not match.");
                            return;
                        }
                        pinManager.createOrChangePin(newPin);
                        dialog.dismiss();
                        toast("PIN changed.");
                    } catch (IllegalArgumentException exception) {
                        replacement.setError(messageOf(exception));
                    } finally {
                        Arrays.fill(oldPin, '\0');
                        Arrays.fill(newPin, '\0');
                        Arrays.fill(repeated, '\0');
                    }
                }));
        dialog.show();
    }

    private void confirmSampleData() {
        new AlertDialog.Builder(this)
                .setTitle("Add fictitious sample records?")
                .setMessage("The sample names and contact details are for demonstration only.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add sample", (dialog, which) -> {
                    try {
                        database.addSampleData();
                        toast("Fictitious sample records added.");
                        showScreen(Screen.DASHBOARD);
                    } catch (RuntimeException exception) {
                        toast(messageOf(exception));
                    }
                })
                .show();
    }

    private void showWipeDialog() {
        LinearLayout form = Ui.page(this);
        form.addView(
                Ui.body(
                        this,
                        "This cannot be undone. Export a verified encrypted backup first if any record may be needed."
                ),
                Ui.match()
        );
        EditText confirmation = Ui.input(this, "Type ERASE");
        confirmation.setAllCaps(true);
        Ui.addField(this, form, "Confirmation", confirmation);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Erase all local CRM data?")
                .setView(Ui.scrollPage(this, form))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Erase permanently", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positive.setTextColor(getColor(R.color.danger));
            positive.setOnClickListener(view -> {
                if (!"ERASE".equals(confirmation.getText().toString().trim().toUpperCase(Locale.US))) {
                    confirmation.setError("Type ERASE to confirm.");
                    return;
                }
                try {
                    database.wipeAllData();
                    database.deleteEncryptionKeyAfterWipe();
                    settings.edit().clear().apply();
                    new PinManager(this).removePin();
                    SessionGuard.lock();
                    dialog.dismiss();
                    routeToLock();
                } catch (RuntimeException exception) {
                    toast("Data could not be erased: " + messageOf(exception));
                }
            });
        });
        dialog.show();
    }

    private Spinner contactSpinner(Context context, long selectedContactId) {
        List<Contact> contacts = database.getContacts("", false);
        List<String> labels = new ArrayList<>();
        labels.add("No linked contact");
        for (Contact contact : contacts) {
            labels.add(contact.displayName());
        }
        Spinner spinner = Ui.spinner(context, labels.toArray(new String[0]));
        spinner.setTag(R.id.spinner_contact_ids, contactIds(contacts));
        if (selectedContactId > 0) {
            long[] ids = (long[]) spinner.getTag(R.id.spinner_contact_ids);
            for (int index = 0; index < ids.length; index++) {
                if (ids[index] == selectedContactId) {
                    spinner.setSelection(index + 1);
                    break;
                }
            }
        }
        return spinner;
    }

    private long[] contactIds(List<Contact> contacts) {
        long[] ids = new long[contacts.size()];
        for (int index = 0; index < contacts.size(); index++) {
            ids[index] = contacts.get(index).id;
        }
        return ids;
    }

    private long selectedContactId(Spinner spinner) {
        int position = spinner.getSelectedItemPosition();
        if (position <= 0) {
            return 0;
        }
        Object tag = spinner.getTag(R.id.spinner_contact_ids);
        if (!(tag instanceof long[])) {
            return 0;
        }
        long[] ids = (long[]) tag;
        int index = position - 1;
        return index >= 0 && index < ids.length ? ids[index] : 0;
    }

    private EditText dateInput(String hint, String value) {
        EditText input = Ui.input(this, hint + " (optional)");
        input.setFocusable(false);
        input.setClickable(true);
        input.setText(value == null ? "" : value);
        input.setOnClickListener(view -> pickDate(input));
        input.setOnLongClickListener(view -> {
            input.setText("");
            toast("Date cleared.");
            return true;
        });
        return input;
    }

    private void pickDate(EditText target) {
        Calendar calendar = Calendar.getInstance();
        String current = target.getText().toString().trim();
        if (!current.isEmpty()) {
            try {
                Date parsed = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(current);
                if (parsed != null) {
                    calendar.setTime(parsed);
                }
            } catch (ParseException ignored) {
                // Start from today when legacy text cannot be parsed.
            }
        }
        new DatePickerDialog(
                this,
                (view, year, month, day) -> target.setText(String.format(
                        Locale.US,
                        "%04d-%02d-%02d",
                        year,
                        month + 1,
                        day
                )),
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void pickDateTime(EditText target, long[] value) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(value[0]);
        new DatePickerDialog(
                this,
                (dateView, year, month, day) -> {
                    Calendar selected = Calendar.getInstance();
                    selected.setTimeInMillis(value[0]);
                    selected.set(Calendar.YEAR, year);
                    selected.set(Calendar.MONTH, month);
                    selected.set(Calendar.DAY_OF_MONTH, day);
                    new TimePickerDialog(
                            this,
                            (timeView, hour, minute) -> {
                                selected.set(Calendar.HOUR_OF_DAY, hour);
                                selected.set(Calendar.MINUTE, minute);
                                selected.set(Calendar.SECOND, 0);
                                selected.set(Calendar.MILLISECOND, 0);
                                value[0] = selected.getTimeInMillis();
                                target.setText(AppDate.formatDateTime(value[0]));
                            },
                            selected.get(Calendar.HOUR_OF_DAY),
                            selected.get(Calendar.MINUTE),
                            false
                    ).show();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private EditText passwordInput(String hint) {
        EditText input = Ui.input(this, hint);
        input.setInputType(
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            input.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        }
        return input;
    }

    private EditText pinInput(String hint) {
        EditText input = Ui.input(this, hint);
        input.setInputType(
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD
        );
        input.setMaxLines(1);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            input.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        }
        android.text.InputFilter[] filters = {
                new android.text.InputFilter.LengthFilter(6)
        };
        input.setFilters(filters);
        return input;
    }

    private void dial(String phone) {
        try {
            startActivity(new Intent(
                    Intent.ACTION_DIAL,
                    Uri.fromParts("tel", phone, null)
            ));
        } catch (ActivityNotFoundException exception) {
            toast("No phone app is available.");
        }
    }

    private void email(String recipient, String subject) {
        Intent intent = new Intent(
                Intent.ACTION_SENDTO,
                Uri.fromParts("mailto", recipient, null)
        );
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException exception) {
            toast("No email app is available.");
        }
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException exception) {
            toast("No browser is available.");
        }
    }

    private String readRawResource(int resourceId) {
        try (InputStream input = getResources().openRawResource(resourceId);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception exception) {
            return "The offline license text could not be loaded.";
        }
    }

    private LinearLayout.LayoutParams margin(int left, int top) {
        LinearLayout.LayoutParams params = Ui.match();
        params.leftMargin = Ui.dp(this, left);
        params.topMargin = Ui.dp(this, top);
        return params;
    }

    private LinearLayout.LayoutParams weightedMargin(
            float weight,
            int left,
            int right,
            int top,
            int bottom
    ) {
        LinearLayout.LayoutParams params = Ui.weight(weight);
        params.leftMargin = Ui.dp(this, left);
        params.rightMargin = Ui.dp(this, right);
        params.topMargin = Ui.dp(this, top);
        params.bottomMargin = Ui.dp(this, bottom);
        return params;
    }

    private String selected(Spinner spinner) {
        Object value = spinner.getSelectedItem();
        return value == null ? "" : String.valueOf(value);
    }

    private String[] withBlank(String blank, String[] values) {
        String[] result = new String[values.length + 1];
        result[0] = blank;
        System.arraycopy(values, 0, result, 1, values.length);
        return result;
    }

    private int indexOf(String[] values, String needle) {
        for (int index = 0; index < values.length; index++) {
            if (values[index].equalsIgnoreCase(needle == null ? "" : needle)) {
                return index;
            }
        }
        return 0;
    }

    private int parseLeadingInt(String value, int fallback) {
        if (value == null) {
            return fallback;
        }
        String[] parts = value.trim().split("\\s+");
        try {
            return Integer.parseInt(parts[0]);
        } catch (RuntimeException exception) {
            return fallback;
        }
    }

    private String readableStamp(String stamp) {
        if (stamp == null || stamp.isEmpty()) {
            return "";
        }
        try {
            Date parsed = new SimpleDateFormat(
                    "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
                    Locale.US
            ).parse(stamp);
            return parsed == null
                    ? stamp
                    : new SimpleDateFormat("MMM d, yyyy · h:mm a", Locale.US).format(parsed);
        } catch (ParseException exception) {
            return stamp;
        }
    }

    private String firstNonEmpty(String... values) {
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value;
            }
        }
        return "";
    }

    private String joinNonEmpty(String first, String second, String separator) {
        String left = first == null ? "" : first.trim();
        String right = second == null ? "" : second.trim();
        if (left.isEmpty()) {
            return right;
        }
        if (right.isEmpty()) {
            return left;
        }
        return left + separator + right;
    }

    private String valueOrBlank(String value, String blankLabel) {
        return blankLabel.equals(value) ? "" : value;
    }

    private String blankAsDash(String value) {
        return value == null || value.trim().isEmpty() ? "—" : value;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private String messageOf(Throwable throwable) {
        String message = throwable == null ? "" : throwable.getMessage();
        return message == null || message.trim().isEmpty()
                ? "The operation could not be completed."
                : message;
    }

    private static void clearBytes(byte[] value) {
        if (value != null) {
            Arrays.fill(value, (byte) 0);
        }
    }

    private TaskItem copyTask(TaskItem source) {
        TaskItem result = new TaskItem();
        result.id = source.id;
        result.contactId = source.contactId;
        result.title = source.title;
        result.dueDate = source.dueDate;
        result.priority = source.priority;
        result.status = source.status;
        result.assignee = source.assignee;
        result.details = source.details;
        result.createdAt = source.createdAt;
        result.updatedAt = source.updatedAt;
        return result;
    }

    private Appointment copyAppointment(Appointment source) {
        Appointment result = new Appointment();
        result.id = source.id;
        result.contactId = source.contactId;
        result.title = source.title;
        result.startTime = source.startTime;
        result.durationMinutes = source.durationMinutes;
        result.meetingType = source.meetingType;
        result.status = source.status;
        result.details = source.details;
        result.createdAt = source.createdAt;
        result.updatedAt = source.updatedAt;
        return result;
    }

    private Inquiry copyInquiry(Inquiry source) {
        Inquiry result = new Inquiry();
        result.id = source.id;
        result.name = source.name;
        result.email = source.email;
        result.phone = source.phone;
        result.type = source.type;
        result.service = source.service;
        result.message = source.message;
        result.status = source.status;
        result.consent = source.consent;
        result.receivedAt = source.receivedAt;
        result.updatedAt = source.updatedAt;
        return result;
    }

    private static final class SimpleWatcher implements TextWatcher {
        private final Runnable action;

        SimpleWatcher(Runnable action) {
            this.action = action;
        }

        @Override
        public void beforeTextChanged(
                CharSequence value,
                int start,
                int count,
                int after
        ) {
        }

        @Override
        public void onTextChanged(
                CharSequence value,
                int start,
                int before,
                int count
        ) {
            action.run();
        }

        @Override
        public void afterTextChanged(Editable value) {
        }
    }
}
