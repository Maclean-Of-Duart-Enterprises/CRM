package com.macleanofduartenterprises.crm;

public final class AppConstants {
    public static final String COMPANY_NAME = "Maclean Of Duart Enterprises";
    public static final String PHONE = "717-500-6202";
    public static final String EMAIL = "office@macleanofduartenterprises.com";
    public static final String WEBSITE = "https://macleanofduartenterprises.com";
    public static final String SCHEDULING_URL =
            "https://cal.com/macleanofduartenterprises";

    public static final String[] SERVICES = {
            "General inquiry",
            "Sales opportunity",
            "Client onboarding",
            "Account management",
            "Customer support",
            "Consultation",
            "Project or engagement",
            "Renewal",
            "Other"
    };

    public static final String[] INQUIRY_TYPES = {
            "Contact form",
            "Live chat",
            "Phone",
            "Email",
            "Referral",
            "Other"
    };

    public static final String[] INQUIRY_STATUSES = {
            "New", "Contacted", "Qualified", "Closed", "Converted"
    };

    public static final String[] MEETING_TYPES = {
            "Office", "Phone", "Video", "Client location"
    };

    public static final String[] APPOINTMENT_STATUSES = {
            "Tentative", "Confirmed", "Completed", "Cancelled"
    };

    private AppConstants() {
    }
}
