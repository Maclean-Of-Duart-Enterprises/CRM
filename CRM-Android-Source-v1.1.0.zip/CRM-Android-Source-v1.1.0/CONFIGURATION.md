# Configuration

## Identity

The canonical application identity is configured in `app/build.gradle`:

- `applicationId`: `com.macleanofduartenterprises.crm`
- `versionName`: `1.1.0`
- `versionCode`: `2`

The public app name and motto are in
`app/src/main/res/values/strings.xml`.

## Developer contact

Developer contact and booking values are intentionally isolated in
`AppConstants.java` and displayed through **Settings > Company & Booking**.
The transparent developer logo is stored as
`app/src/main/res/drawable-nodpi/maclean_logo.png`.

## License

- Source copy: `LICENSE.txt`
- Offline Android resource: `app/src/main/res/raw/agpl_3_0.txt`
- Application notice: `NOTICE.txt`

The Settings button and the persistent footer both open the offline license
screen.

## Data and security

The app stores local records in SQLite. Selected personal fields are encrypted
with AES-GCM using a non-exportable key held by Android Keystore. PIN settings,
auto-lock settings, and backup passphrases are separate; backup passphrases are
never stored.

## Release signing

See `signature/README.md`. Never publish or commit a private `.keystore` file.

## VCF interchange

`contacts/VCardCodec.java` implements local vCard encoding and parsing without
third-party libraries or network access. It reads common vCard 2.1, 3.0, and
4.0 text fields, including quoted-printable UTF-8 values, and writes vCard 3.0.
CRM-specific pipeline fields are written as `X-CRM-*` properties while standard
name, organization, email, phone, and category fields remain interoperable.

`contacts/VCardProvider.java` is declared as a non-exported provider with the
authority `${applicationId}.vcards`. It serves only temporary read-only files
created by a user-initiated Share action, and the receiving app receives a
temporary URI grant. Imports and document exports use Android's system document
picker and therefore do not require storage permissions.
