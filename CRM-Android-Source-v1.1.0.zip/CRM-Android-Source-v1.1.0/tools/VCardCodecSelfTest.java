import com.macleanofduartenterprises.crm.contacts.VCardCodec;
import com.macleanofduartenterprises.crm.model.Contact;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

/** Host-side regression checks for VCF encoding and parsing; no Android runtime is required. */
public final class VCardCodecSelfTest {
    private VCardCodecSelfTest() {
    }

    public static void main(String[] args) {
        roundTripsSelectedContacts();
        importsQuotedPrintableAndAlternateFields();
        importsFormattedNameOnly();
        enforcesContactLimit();
        rejectsEmptyInput();
        System.out.println("VCardCodecSelfTest: all checks passed");
    }

    private static void roundTripsSelectedContacts() {
        Contact first = new Contact();
        first.firstName = "Zoë; Ann";
        first.lastName = "O'Connor, Jr.";
        first.household = "North; Star Consulting";
        first.email = "zoe@example.com";
        first.phone = "+1 717 555 0101";
        first.stage = "Proposal";
        first.service = "Relationship management";
        first.source = "Referral";
        first.advisor = "A. Representative — Regional Client Relationship and Follow-up Team";
        first.estimatedValue = 12500.75;
        first.nextAction = "2026-09-30";
        first.consent = true;
        first.status = "Active";

        Contact second = new Contact();
        second.firstName = "李";
        second.lastName = "明";
        second.email = "li@example.net";

        byte[] encoded = VCardCodec.encode(Arrays.asList(first, second));
        String encodedText = new String(encoded, StandardCharsets.UTF_8);
        contains(encodedText, "\r\n ");
        for (String physicalLine : encodedText.split("\r\n", -1)) {
            if (physicalLine.getBytes(StandardCharsets.UTF_8).length > 75) {
                throw new AssertionError("encoded vCard line exceeds 75 UTF-8 octets");
            }
        }
        List<VCardCodec.ImportedContact> decoded = VCardCodec.decode(encoded);
        equal(2, decoded.size(), "two selected contacts round trip");
        Contact actual = decoded.get(0).contact;
        equal(first.firstName, actual.firstName, "escaped first name");
        equal(first.lastName, actual.lastName, "escaped last name");
        equal(first.household, actual.household, "escaped organization");
        equal(first.email, actual.email, "email");
        equal(first.phone, actual.phone, "phone");
        equal(first.stage, actual.stage, "CRM stage");
        equal(first.service, actual.service, "CRM service");
        equal(first.advisor, actual.advisor, "CRM representative");
        equal(first.nextAction, actual.nextAction, "next action");
        equal(true, actual.consent, "consent");
        close(first.estimatedValue, actual.estimatedValue, "opportunity value");
        equal(second.firstName, decoded.get(1).contact.firstName, "Unicode first name");
        equal(second.lastName, decoded.get(1).contact.lastName, "Unicode last name");
    }

    private static void importsQuotedPrintableAndAlternateFields() {
        String card = "BEGIN:VCARD\r\n"
                + "VERSION:2.1\r\n"
                + "N;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:Doe;Jos=C3=A9;;;\r\n"
                + "FN;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:Jos=C3=A9 Doe\r\n"
                + "ORG;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:Cr=C3=A8me\\; North;Client Services\r\n"
                + "EMAIL:jose@example.com\r\n"
                + "EMAIL:jose.alternate@example.net\r\n"
                + "TEL:+17175550102\r\n"
                + "ADR;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:;;123 Rue;Montr=C3=A9al;;;Canada\r\n"
                + "NOTE:Requested a follow-up\\nPrefers email\r\n"
                + "END:VCARD\r\n";
        List<VCardCodec.ImportedContact> decoded = VCardCodec.decode(
                card.getBytes(StandardCharsets.UTF_8)
        );
        equal(1, decoded.size(), "quoted-printable card parsed");
        Contact actual = decoded.get(0).contact;
        equal("José", actual.firstName, "quoted-printable first name");
        equal("Doe", actual.lastName, "quoted-printable last name");
        equal(
                "Crème; North / Client Services",
                actual.household,
                "quoted-printable organization"
        );
        contains(decoded.get(0).importedNote, "Alternate email: jose.alternate@example.net");
        contains(decoded.get(0).importedNote, "Montréal");
        contains(decoded.get(0).importedNote, "Prefers email");
    }

    private static void importsFormattedNameOnly() {
        String card = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Single Name\r\nEND:VCARD\r\n";
        List<VCardCodec.ImportedContact> decoded = VCardCodec.decode(
                card.getBytes(StandardCharsets.UTF_8)
        );
        equal(1, decoded.size(), "FN-only card parsed");
        equal("Single", decoded.get(0).contact.firstName, "FN first name fallback");
        equal("Name", decoded.get(0).contact.lastName, "FN last name fallback");
    }

    private static void rejectsEmptyInput() {
        equal(0, VCardCodec.decode(new byte[0]).size(), "empty VCF contains no contacts");
    }

    private static void enforcesContactLimit() {
        StringBuilder cards = new StringBuilder();
        for (int index = 0; index < 1001; index++) {
            cards.append("BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Contact ")
                    .append(index)
                    .append("\r\nEND:VCARD\r\n");
        }
        try {
            VCardCodec.decode(cards.toString().getBytes(StandardCharsets.UTF_8));
            throw new AssertionError("VCF contact limit was not enforced");
        } catch (IllegalArgumentException expected) {
            contains(expected.getMessage(), "maximum of 1000");
        }
    }

    private static void equal(Object expected, Object actual, String label) {
        if (!expected.equals(actual)) {
            throw new AssertionError(label + ": expected " + expected + ", got " + actual);
        }
    }

    private static void close(double expected, double actual, String label) {
        if (Math.abs(expected - actual) > 0.0001) {
            throw new AssertionError(label + ": expected " + expected + ", got " + actual);
        }
    }

    private static void contains(String value, String expected) {
        if (!value.contains(expected)) {
            throw new AssertionError("expected imported note to contain: " + expected);
        }
    }
}
