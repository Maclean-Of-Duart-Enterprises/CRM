# CRM 1.1.0 build verification

Validated August 29, 2026 (UTC).

## Build

- JDK 17
- Gradle 8.10.2
- Android Gradle Plugin 8.7.3
- Compile and target API 35
- Build Tools 35.0.1
- `clean lintRelease assembleRelease`: successful
- Android Lint: zero errors
- Host-side `VCardCodecSelfTest`: all checks passed

## Identity

- Application label: `CRM`
- Package: `com.macleanofduartenterprises.crm`
- Version: `1.1.0` / version code `2`
- Minimum API: 23
- Launcher: `com.macleanofduartenterprises.crm.LockActivity`
- Requested permissions: none
- Private VCF provider: `com.macleanofduartenterprises.crm.vcards`
- Provider exported: false; temporary URI grants enabled

## Upgrade identity

- Compared release: CRM `1.0.0` / version code `1`
- New release: CRM `1.1.0` / version code `2`
- Both APKs use package `com.macleanofduartenterprises.crm`
- Both APKs have the same publisher certificate SHA-256
- Android's package, signer, and monotonically increasing version-code requirements for an in-place update are satisfied

## Release APK

- File: `CRM-v1.1.0.apk`
- Size: 641,953 bytes
- ZIP alignment: verified with 16 KiB page-alignment checking
- Signature schemes: v1, v2, and v3 verified
- Signer certificate SHA-256:
  `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- APK SHA-256:
  `c3ae1db4782f815ca4d5d8e8d95baa17b4f2eb5c93e94bd9fc5e33b313386f97`

## Offline license

- `LICENSE.txt`: 34,082 bytes
- GNU AGPLv3 sections 0 through 17 and application instructions are present
- APK-embedded license bytes match `LICENSE.txt` exactly
- License SHA-256:
  `80c0bc7925f08bdbbbb276369b738ab880a63087d011b4c375a813ff9bd845f7`

## Remaining device checks

Installation over a device containing CRM 1.0.0, PIN entry, external
dial/email/browser/calendar/share/document handlers, and the complete manual
merge/delete/import touch workflows should be confirmed on the target Android
device using `TEST-CHECKLIST.md`.
