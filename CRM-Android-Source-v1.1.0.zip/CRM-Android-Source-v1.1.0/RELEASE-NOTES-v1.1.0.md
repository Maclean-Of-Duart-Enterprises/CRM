# CRM 1.1.0 release notes

CRM 1.1.0 adds single-record and manually selected bulk contact management.
The app identity remains `com.macleanofduartenterprises.crm`, and version code
2 allows this release to install over CRM 1.0.0 while preserving its local
database, PIN, encryption key, settings, and backups.

## New contact tools

- Merge one or multiple manually chosen source contacts into an explicit primary contact.
- Permanently delete one contact or a manually selected contact set after confirmation.
- Share one or multiple selected contacts as a standard VCF file.
- Export one or multiple selected contacts to a user-chosen VCF destination.
- Import one or more VCF files and manually check only the contacts to add.

Merge and delete operations are transactional. A merge retains the primary
contact ID and populated fields, moves related notes, tasks, and consultations,
and preserves differing source details in an encrypted note before deleting
source records. A permanent delete removes contact notes and contact/note
activity history but preserves tasks and consultations as unlinked records.

VCF sharing uses a non-exported, read-only temporary content provider with a
one-time Android URI grant. Import and export use Android's document picker.
The app continues to request no Android permissions and performs no network
communication.

Before installing an update on important data, create and verify an encrypted
CRM backup. This APK must be signed by the same publisher key as CRM 1.0.0 to
be accepted as an in-place update.
