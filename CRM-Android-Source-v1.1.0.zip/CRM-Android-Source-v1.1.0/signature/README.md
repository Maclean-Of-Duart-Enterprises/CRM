# Release signing

Place the private publishing key at `signature/release.keystore` only in a
trusted local build environment. Do not commit or distribute the keystore.

The release build reads these environment variables:

- `CRM_KEYSTORE_PASSWORD`
- `CRM_KEY_PASSWORD`
- `CRM_KEY_ALIAS` (defaults to `macleanphonerelease`)

The supplied private publishing key is intentionally excluded from the public
source archive.
