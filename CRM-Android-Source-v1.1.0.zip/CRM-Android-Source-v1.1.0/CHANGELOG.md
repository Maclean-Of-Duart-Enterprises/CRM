# Changelog

## 1.1.0

- Added stable manual contact multi-selection that remains active while searching.
- Added single-contact and bulk permanent delete with explicit confirmation.
- Added single-contact and bulk manual merge with a user-selected primary record.
- Preserved linked notes, tasks, consultations, and differing source details during merges.
- Added single-contact and bulk VCF sharing through a private, temporary content provider.
- Added single-contact and bulk VCF export through Android's document picker.
- Added multi-file VCF import with an unchecked manual review list before records are added.
- Added vCard 2.1 quoted-printable and vCard 3.0 parsing with Unicode support.
- Kept the package ID and publisher identity unchanged and advanced the version code for an in-place update.

## 1.0.0

- Renamed the application to CRM.
- Set the package identity to `com.macleanofduartenterprises.crm`.
- Added the motto “A client relations management application.”
- Replaced the company-branded header, lock screen, dashboard, categories, and backup names with neutral CRM equivalents.
- Retained developer contact and booking information in Settings > Company & Booking.
- Added the complete GNU AGPLv3 license offline under Settings > License.
- Added the linked AGPLv3 attribution footer.
- Signed the production APK with the supplied publishing identity.
