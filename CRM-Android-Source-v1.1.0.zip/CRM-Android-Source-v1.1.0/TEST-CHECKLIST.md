# CRM 1.1.0 test checklist

## Identity and navigation

- [ ] Launcher label is `CRM`.
- [ ] Package is `com.macleanofduartenterprises.crm`.
- [ ] Version is `1.1.0` / code 2.
- [ ] Header always shows `CRM` and `A client relations management application`.
- [ ] No company phone, email, website, logo, or tartan appears outside Company & Booking, the license notice, or footer attribution.
- [ ] Footer text opens the offline License screen.

## Settings and attribution

- [ ] Settings includes `Company & Booking` and `License` buttons.
- [ ] Company & Booking shows the developer logo, phone, email, website, and Cal.com action.
- [ ] Phone, email, web, and booking actions open the correct external handler.
- [ ] License displays the complete GNU AGPLv3 text without a network connection.

## CRM workflows

- [ ] Create, edit, archive, search, and reopen contacts.
- [ ] Single-contact Share sends one readable VCF through the Android chooser.
- [ ] Single-contact Export VCF saves one readable file through the document picker.
- [ ] Single-contact Delete permanently requires confirmation and removes the contact, notes, and contact/note history.
- [ ] Single-contact Merge requires manually choosing at least one source and confirming the primary.
- [ ] Enter bulk selection, manually choose records across multiple searches, and verify selections persist.
- [ ] Select visible adds only contacts matching the current search/archive filters; Clear removes the set.
- [ ] Bulk Share and Export VCF contain only the manually selected contacts.
- [ ] Bulk Delete removes only selected contacts and their notes/history, and leaves tasks/consultations unlinked.
- [ ] Bulk Merge requires two or more selected contacts and an explicit primary record.
- [ ] Merge retains the primary ID and fields, fills blanks, moves relationships, and saves alternate details in a Merge note.
- [ ] Import one and multiple VCF files, select a subset in the unchecked review list, and verify only that subset is added.
- [ ] VCF import handles Unicode, folded lines, quoted-printable vCard 2.1 text, extra email/phone values, and malformed cards.
- [ ] VCF import never automatically changes or merges an existing CRM record.
- [ ] Move contacts across all five pipeline stages.
- [ ] Add and complete tasks.
- [ ] Add and edit consultations and calendar handoff.
- [ ] Add, update, and convert inquiries.
- [ ] Create, verify, and restore an encrypted backup.
- [ ] Add fictitious sample data only to an empty CRM.
- [ ] Erase removes records, PIN, settings, and the local encryption key.

## Security and device behavior

- [ ] PIN setup, unlock, lockout, change, and inactivity lock work.
- [ ] Screenshots and screen recording work throughout the app.
- [ ] The manifest contains no `INTERNET` permission.
- [ ] Android backup remains disabled.

## Release package

- [ ] Release APK passes Android Lint.
- [ ] APK is 16 KiB page aligned.
- [ ] APK verifies with v1, v2, and v3 signature schemes.
- [ ] Signer certificate matches the approved publisher certificate.
- [ ] APK-embedded AGPLv3 bytes match `LICENSE.txt`.
- [ ] Upgrade installs over CRM 1.0.0 without clearing the existing database or PIN.
- [ ] `com.macleanofduartenterprises.macleancrm` remains independently installed and unchanged.
