# App Builder II setup

This is a native Java/XML Android project. Use App Builder II's Java App
workflow rather than its HTML/WebView workflow.

1. Create or import a Java App project.
2. Set the app name to `CRM`.
3. Set the package ID to `com.macleanofduartenterprises.crm`.
4. Set the version name to `1.1.0` and version code to `2`.
5. Copy `app/src/main/java/` into the Java source tree.
6. Copy `app/src/main/res/` into the Android resources tree.
7. Merge `app/src/main/AndroidManifest.xml`.
8. Compile with Android API 35 or later.

The launcher activity is:

`com.macleanofduartenterprises.crm.LockActivity`

The project does not need AndroidX, third-party libraries, HTML, WebView, or
an Internet permission. If the builder cannot preserve raw resources, ensure
that `agpl_3_0.txt` remains packaged and that `R.raw.agpl_3_0` resolves before
publishing.

The manifest's non-exported `.contacts.VCardProvider` declaration and its
`${applicationId}.vcards` authority are required for safe contact sharing. The
builder must preserve the manifest placeholder or replace it with
`com.macleanofduartenterprises.crm.vcards`.

For production signing, import the publisher-controlled key using the
builder's secure signing interface. Do not place the private key or its
passwords in public source.
